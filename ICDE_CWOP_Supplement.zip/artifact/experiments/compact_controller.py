"""Vectorized eligible-edge implementation of exactly the analyzed x updates.

Equal candidate counts per request type are required by this implementation, not theory.
No slate enumeration, dense creator-gradient array or hidden changed geometry is used.
"""
import time
import numpy as np
from legacy_controller import policy_metrics


def solve(env,target,iterations,floor=1e-7,primal_rate=.75,dual_rate=1.25,
          dual_bound=100.,use_global=True,use_local=True,record_every=100):
    counts=env.candidate_mask.sum(1)
    assert (counts==counts[0]).all()
    u,c=env.users,env.creators; k=int(counts[0])
    indices=np.where(env.candidate_mask)[1].reshape(u,k)
    reward=env.utility[np.arange(u)[:,None],indices]
    q=env.request_prob[:,None]
    x=np.full((u,k),1/k); avg=np.zeros_like(x)
    hd=0.; cd=np.zeros(c); ed=np.zeros(u); history=[]
    begin=time.perf_counter()
    for t in range(1,iterations+1):
        rho=np.bincount(indices.ravel(),weights=(q*x).ravel(),minlength=c)
        entropy=-np.sum(x*np.log(x),axis=1)
        gh=rho@rho-target.hhi; gc=rho-target.cap; ge=target.entropy-entropy
        grad=q*reward
        if use_global:
            grad-=q*(2*hd*rho[indices]+cd[indices])
        if use_local:
            grad+=ed[:,None]*(-np.log(x)-1)
        avg+=(x-avg)/t
        v=x+primal_rate/np.sqrt(t)*grad-floor
        sorted_v=np.sort(v,axis=1)[:,::-1]
        shifted_sum=np.cumsum(sorted_v,axis=1)-(1-k*floor)
        active=(sorted_v-shifted_sum/np.arange(1,k+1)>0).sum(1)
        threshold=shifted_sum[np.arange(u),active-1]/active
        x=np.maximum(v-threshold[:,None],0)+floor
        step=dual_rate/np.sqrt(t)
        if use_global:
            hd=float(np.clip(hd+step*gh,0,dual_bound))
            cd=np.clip(cd+step*gc,0,dual_bound)
        if use_local:
            ed=np.clip(ed+step*ge,0,dual_bound)
        if t==1 or t%record_every==0 or t==iterations:
            full=np.zeros_like(env.utility); full[np.arange(u)[:,None],indices]=avg
            history.append(dict(iteration=t,**policy_metrics(env,full,target),
                                hhi_dual=hd,max_cap_dual=float(cd.max()),max_entropy_dual=float(ed.max())))
    elapsed=time.perf_counter()-begin
    full=np.zeros_like(env.utility); full[np.arange(u)[:,None],indices]=avg
    return full,history,dict(solver_seconds=elapsed,milliseconds_per_iteration=1000*elapsed/iterations,
                             hhi_dual=hd,max_cap_dual=float(cd.max()),max_entropy_dual=float(ed.max()),
                             stored_policy_entries=u*k,eligible_edges=u*k,
                             main_working_arrays_bytes=int(sum(a.nbytes for a in (indices,reward,q,x,avg,cd,ed))))
