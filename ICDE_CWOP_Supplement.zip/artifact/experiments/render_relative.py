"""Regenerate ICDE relative tables and figures from locally generated experiment inputs."""
import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import zipfile

os.environ.setdefault('MPLCONFIGDIR', '/tmp/cwop-relative-matplotlib')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import NullFormatter, ScalarFormatter
from scipy.stats import binom

ROOT = Path(__file__).resolve().parents[1]
ART = ROOT
parser = argparse.ArgumentParser()
parser.add_argument('--recomputed', action='store_true', help='Render newly rerun results without requiring the original-output hashes; record new hashes.')
args = parser.parse_args()
manifest_path = ROOT/'INPUT_SHA256.json'
if not args.recomputed and not manifest_path.exists():
    parser.error('No saved data are bundled. Run the experiments first, then use --recomputed.')
MANIFEST = json.loads(manifest_path.read_text()) if manifest_path.exists() else {}
if not (ROOT/'results/unified_summary.json').exists():
    parser.error('Generate experiment results and summaries first; see README.txt.')
for name in ('generated', 'latex', 'build'):
    (ROOT/name).mkdir(exist_ok=True)
CHECKED = {}
MACROS = {}


def source(name):
    content = (ART / name).read_bytes()
    digest = hashlib.sha256(content).hexdigest()
    if not args.recomputed:
        assert MANIFEST[name] == digest, f'Input changed: {name}; use --recomputed only for intentionally rerun outputs.'
    CHECKED[name] = digest
    return content.decode()


def read(name):
    return json.loads(source('results/' + name + '.json'))


def csvrows(name):
    return list(csv.DictReader(source('legacy/data/' + name + '.csv').splitlines()))


def num(x, digits=3):
    if abs(x) < .5 * 10**(-digits):
        x = 0.
    return f'${x:.{digits}f}$'


def pct(x, digits=1):
    return f'${100*x:.{digits}f}\\%$'


def macro(name, value):
    MACROS[name] = str(value)


def sci(value):
    coefficient, exponent = f'{value:.1e}'.split('e')
    return coefficient + r'\times10^{' + str(int(exponent)) + '}'


def table(name, caption, label, headers, rows):
    rows = [list(row) for row in rows]
    start = 0
    while start < len(rows):
        end = start + 1
        while end < len(rows) and rows[end][0] == rows[start][0]:
            end += 1
        if end - start > 1:
            label_text = rows[start][0]
            rows[start][0] = r'\multirow{' + str(end-start) + r'}{*}{' + label_text + '}'
            for i in range(start+1,end):
                rows[i][0] = ''
        start = end
    text = ('\\begin{table}[t]\\centering\\small\n'
            '\\caption{' + caption + '}\n\\label{' + label + '}\n'
            '\\begin{adjustbox}{max width=\\linewidth}\n'
            '\\begin{tabular}{l' + 'r' * (len(headers)-1) + '}\n\\toprule\n'
            + ' & '.join(headers) + r' \\' + '\n\\midrule\n'
            + '\n'.join(' & '.join(r) + r' \\' for r in rows)
            + '\n\\bottomrule\n\\end{tabular}\n\\end{adjustbox}\n\\end{table}\n')
    (ROOT / 'latex' / (name + '.tex')).write_text(text)


def save(fig, name):
    fig.savefig(ROOT / 'generated' / (name + '.pdf'), metadata={
        'Creator': 'Scientific plotting', 'Author': 'Anonymous authors',
        'CreationDate': None, 'ModDate': None})
    fig.savefig(ROOT / 'build' / (name + '.png'), dpi=160)
    plt.close(fig)


plt.rcParams.update({'font.size': 8, 'axes.titlesize': 8, 'axes.labelsize': 8, 'xtick.labelsize': 7, 'ytick.labelsize': 7, 'axes.spines.top': False,
                     'axes.spines.right': False, 'pdf.fonttype': 42})
st = read('static'); base = st['instances'][0]
wg = base['policies']['greedy']['metrics']['welfare']
wr = base['oracle']['metrics']['welfare']
w0 = base['witness']['witness_welfare']
cost = wg - wr
gain = wr - w0
loss = lambda w: (wg-w)/cost
relative_gain = lambda w: (w-w0)/gain
gap = lambda w: (wr-w)/cost

rows=[]
for label, w in [('Unconstrained greedy', wg), ('Conic reference', wr),
                 ('PD, repaired', base['policies']['joint_repaired']['metrics']['welfare'])]:
    rows.append([label, num(loss(w),4)])
table('table_static_main',
      r'Base static benchmark. Relative loss $L_{\rm rel}$ uses the greedy-to-conic target cost as one unit '
      r'(Section~\ref{app:relative-reporting}); $L_{\rm rel}<1$ does not imply feasibility.',
      'tab:static-main', ['Policy', 'Relative loss $L_{\rm rel}$'], rows)

def residual(m, eta=.055, kappa=.08):
    return max(0., m['hhi']/eta-1, m['max_share']/kappa-1,
               (0.65-m['min_norm_entropy'])/0.65)

rows=[]
for label, m in [(label,base['policies'][key]['metrics']) for key,label in [
        ('greedy','Greedy'),('softmax_0.30','Softmax 0.30'),('global_pd','Global-only PD'),
        ('local_pd','Local-only PD'),('joint_pd','PD raw'),('joint_repaired','PD repaired')]] + [
        ('Feasible softmax mixture',base['best_feasible_softmax']),('Conic reference',base['oracle']['metrics'])]:
    rows.append([label,num(loss(m['welfare']),4),num(m['hhi']/.055,4),num(m['max_share']/.08,4),
                 num(m['min_norm_entropy'],4),f"$ {residual(m):.2g} $".replace(' 0 ', ' 0 ')])
table('table_static_details',
      r'Base synthetic outcomes in relative units. $L_{\rm rel}$ is defined in Table~\ref{tab:static-main}; '
      r'$V=\max\{0,\HHI/\eta-1,\max_cR_c/\kappa-1,(h_0-\min_uH(S_u))/h_0\}$. '
      r'Entropy is divided by $\log K$. Numerical feasibility is checked with tolerance $10^{-10}$.',
      'tab:cwop-benchmark',['Policy','$L_{\rm rel}$',r'HHI/$\eta$',r'Share/$\kappa$',r'$H/\log K$','$V$'],rows)

gaps=[]; certs=[]; exploration=[]
for a in st['instances']:
    cg=a['policies']['greedy']['metrics']['welfare']-a['oracle']['metrics']['welfare']
    gaps.append(a['policies']['joint_repaired']['oracle_gap']/cg)
    certs.append(a['oracle']['certified_gap']/cg)
    exploration.append(a['witness']['exploration_gap_upper']/cg)
macro('RelativeBaseGap',f'{gaps[0]:.4f}')
macro('RelativeGraphGaps',f'{min(gaps[:5]):.4f}$--${max(gaps[:5]):.4f}')
macro('RelativeLargeGap',f'{gaps[5]:.4f}')
macro('RelativeCertificateGap',sci(max(certs)))
macro('RelativeExplorationGap',sci(max(exploration)))

lf=read('lastfm'); rows=[]; lf_gaps=[]
for i,a in enumerate(lf['instances'],1):
    ref=a['oracle']['metrics']['welfare']; pg=(ref-a['repaired']['welfare'])/ref
    lf_gaps.append(pg)
    rows.append([f'Split {i}',num(a['greedy']['welfare']/ref),
                 pct(pg,2),num(a['pd']['diagnostics']['solver_seconds']/a['oracle']['seconds'],2)])
table('table_lastfm',
      r'Public artist-listening test splits. Greedy utility and PD gaps are relative to the conic reference '
      r'within each split. Time is PD/conic solver time, excluding preference fitting.',
      'tab:lastfm',['Split','Greedy/ref.','PD gap/ref.','Time ratio'],rows)
macro('RelativeLastfmGaps',f'{100*min(lf_gaps):.2f}\\%$--${100*max(lf_gaps):.2f}\\%')

summary=read('unified_summary')
datasets={d:read('unified_feedback_'+d) for d in ('synthetic','lastfm')}
names={'temperature':'Temperature','logshare':'Log-share','fairco_batch':'FairCo-style batch',
       'fw_penalty':'Two-sided batch FW','conic':'Conic reference, no margin','certified':'Certified CWOP (conic)'}
order=list(names)
rows=[]
for method in order:
    row=[names[method]]
    for d in datasets:
        s=summary[d][method]; ref=summary[d]['conic']['utility']
        mean = f"{s['utility']/ref:.3f}"
        value = '$'+mean+f"\\pm{s['utility_sd']/ref:.3f}$"
        if method == 'certified':
            value = r'\textbf{' + mean + '}' + f"$\\pm{s['utility_sd']/ref:.3f}$"
        row += [value,pct(s['failures']/s['windows'])]
    rows.append(row)
table('table_feedback_main',
      r'Matched feedback: 20 windows per trajectory, 20k requests on five synthetic graphs and 100k on '
      r'three Last.fm splits. Utility $U_{\rm eval}/U_{\rm ref}$ and its SD use the mean no-margin conic utility '
      r'on the same dataset as a fixed denominator. Failure rates are percentages of windows. '
      r'Baselines are tuned on disjoint instances at matching window sizes. Bold marks the highest utility among methods with zero observed window violations.',
      'tab:feedback',['Method','Synthetic ratio','Failures','Last.fm ratio','Failures'],rows)
for d,tag in [('synthetic','Synthetic'),('lastfm','Lastfm')]:
    ratio=summary[d]['certified']['utility']/summary[d]['conic']['utility']
    macro('Unified'+tag+'Certified',f'{ratio:.3f}')
    macro('Unified'+tag+'Cost',f'{100*(1-ratio):.1f}\\%')
macro('RelativeFWUtility',f"{summary['synthetic']['fw_penalty']['utility']/summary['synthetic']['conic']['utility']:.3f}")

rows=[]
for d in datasets:
    prior=read('refined_feedback_'+d)
    ts=[t for t in prior['trials'] if t['method']=='conic_certified']
    u=np.mean([t['rows'][-1]['pooled']['welfare'] for t in ts])
    ref=summary[d]['conic']['utility']
    current=summary[d]['certified']
    for label,utility,frozen in [('Witness segment',u,0),('Reoptimized',current['utility'],current['frozen_failures'])]:
        rows.append(['Synthetic' if d=='synthetic' else 'Last.fm',label,num(utility/ref),pct(frozen/40000,4)])
    if d=='synthetic':macro('RelativeSegmentUtility',f'{u/ref:.3f}')
table('table_certified_feedback',
      r'Construction ablation under the matched protocol. Utility uses the dataset-specific '
      r'no-margin conic reference from Table~\ref{tab:feedback}. Both constructions use the same '
      r'probability certificate and have zero observed window failures. Frozen-policy failures '
      r'are percentages. These compare separate feedback trajectories, not the fixed-history score bound.',
      'tab:certified-feedback',['Data','Construction','Utility ratio','Frozen fail.'],rows)

rows=[]; dualrows=[]
for d,data in datasets.items():
    for method in order:
        ts=[t for t in data['test'] if t['method']==method]
        vals=np.array([[t['rows'][-1]['pooled']['hhi']/t['targets']['hhi'],
                        t['rows'][-1]['pooled']['max_share']/t['targets']['cap'],
                        t['rows'][-1]['pooled']['min_norm_entropy'],
                        t['rows'][-1]['min_consumption_entropy']] for t in ts]).mean(0)
        parameter=ts[0]['parameter']
        rows.append(['Synthetic' if d=='synthetic' else 'Last.fm',names[method],
                     '---' if parameter is None else f'${parameter:g}$']+[num(v) for v in vals])
        if method in ('conic','certified'):
            hhi=[];cap=[];ent=[];global_f=[];local_f=[]
            for t in ts:
                for r in t['rows']:
                    m=r['empirical'];hhi.append(m['hhi']/t['targets']['hhi']);cap.append(m['max_share']/t['targets']['cap']);ent.append(m['min_norm_entropy'])
                    global_f.append(max(m['hhi_violation'],m['cap_violation'])>1e-6)
                    local_f.append(m['entropy_violation']>1e-6)
            dualrows.append(['Synthetic' if d=='synthetic' else 'Last.fm',
                             'No margin' if method=='conic' else 'Certified',num(max(hhi)),num(max(cap)),num(min(ent)),
                             pct(np.mean(global_f)),pct(np.mean(local_f))])
table('table_matched_details',
      r'Matched-window policies. Concentration ratios are computed using each graph\textquotesingle s '
      r'targets before averaging pooled outcomes across trajectories. Exposure and clicked-item entropies '
      r'are divided by $\log K$. Parameters are selected on training instances.',
      'tab:matched-details',['Data','Method','Parameter',r'HHI/$\eta$',r'Share/$\kappa$','Exposure $H$','Clicked $H$'],rows)
table('table_dual_outcomes',
      r'Joint target control. Concentration ratios are maxima across test windows; entropy is the '
      r'minimum over types and windows. Targets are ratios $\le1$ and normalized entropy $\ge0.65$. '
      r'Global and local columns give the percentages of windows violating either concentration '
      r'ceiling or any entropy floor, respectively (raw tolerance $10^{-6}$); they may overlap.',
      'tab:dual-outcomes',['Data','Policy',r'HHI/$\eta$',r'Share/$\kappa$',r'$H/\log K$','Global','Local'],dualrows)

fb=read('feedback'); sens=read('feedback_sensitivity'); review=read('review_summary')
labels={'feedback':'Uncontrolled','temperature':'Temperature','logshare':'Log-share','cwop':'PD, no margin',
        'cwop_safe':'PD + margins','oracle':'Conic reference, no margin','fw_penalty':'Two-sided batch FW'}
rows=[]
for chi in (0,.15,.3):
    data=fb['trials'] if chi==.15 else sens['trials']
    ref=np.mean([t['rows'][-1]['pooled']['welfare'] for t in data if t['method']=='feedback' and t['alpha']==chi])
    for method in ('feedback','temperature','logshare','cwop'):
        tr=[t for t in data if t['method']==method and t['alpha']==chi]
        m={k:np.mean([t['rows'][-1]['pooled'][k] for t in tr]) for k in ['welfare','hhi','max_share','min_norm_entropy']}
        rows.append([f'${chi:.2f}$',labels[method],num(m['welfare']/ref),num(m['hhi']/.055),num(m['max_share']/.08),num(m['min_norm_entropy'])])
table('table_sensitivity',
      r'Feedback sensitivity at 10k requests per window. Utility is divided by uncontrolled utility '
      r'at the same $\chi$; concentration uses the target as denominator. Means are over five graphs. '
      r'Parameters are selected only at $\chi=0.15$.',
      'tab:feedback-sensitivity',[r'$\chi$','Method','Utility ratio',r'HHI/$\eta$',r'Share/$\kappa$',r'$H/\log18$'],rows)
rows=[]
for r in review['margin_sweep']:
    ref=review['methods'][r['method']]['welfare']
    theta=r.get('theta_range',[0])[0]
    rows.append(['PD' if r['method']=='cwop' else 'Conic reference',num(r['strength'],1),num(r['welfare']/ref),pct(r['window_violations']/100,0),num(theta)])
table('table_review_margins',
      r'Empirical-margin ablation at 10k requests. Multiplier $t$ scales $(0.005,0.01,0.07\log18)$. '
      r'Utility is relative to the same solver without margins; $\vartheta$ is the sufficient witness '
      r'mixing fraction in Corollary~\ref{cor:safety-cost}. These settings have no analytic sampling certificate.',
      'tab:review-margins',['Method','$t$','Utility ratio','Window fail.',r'$\vartheta$'],rows)
rows=[]
for key,label in [('feedback','Uncontrolled'),('temperature','Temperature'),('logshare','Log-share'),
                  ('fairco_batch','FairCo-style batch'),('fw_penalty','Two-sided batch FW'),('cwop','PD, no margin'),
                  ('oracle','Conic reference, no margin'),('cwop_margin','PD + margins'),('oracle_margin','Conic reference + margins')]:
    r=review['methods'][key]
    rows.append([label,num(r['click_entropy']),pct(r['window_violations']/100,0)])
table('table_review_diagnostics',
      r'Diagnostics at $N=10$k requests per window over five 20-window runs. Failure rates count '
      r'windows violating any exposure target (100 windows per method). Minimum clicked-item entropy is divided by $\log18$ and averaged across runs.',
      'tab:review-diagnostics',['Method',r'Min clicked $H/\log18$','Violating windows'],rows)

curves=read('refined_curves'); rows=[]
for r in curves['synthetic']['rows']:
    if r['N'] in (12338,20000,50000,100000):
        rows.append([num(r['N']/20000,3),num(r['uniform_budget']['theta'])]+
                    ['---' if r[k] is None else num(relative_gain(r[k])) for k in ('common_score','per_type_score','policy_specific_score')])
table('table_sample_size',
      r'Base synthetic safety cost. Window size is relative to $N_0=20$k. '
      r'$Q=(W-W_0)/(W_{\rm ref}-W_0)$ measures score gain above the uniform witness, with no-margin '
      r'conic gain equal to one. $\vartheta$ uses policy-independent per-type margins. '
      r'Policy-dependent values are feasible constructions, not certified optima.',
      'tab:sample-size',[r'$N/N_0$',r'$\vartheta$','Common $Q$','Per-type $Q$','Policy-dep. $Q$'],rows)
for n,key in [(5082,'ThresholdGain'),(20000,'ReoptimizedGain')]:
    r=next(r for r in curves['synthetic']['rows'] if r['N']==n)
    macro('Relative'+key,f"{relative_gain(r['policy_specific_score']):.3f}")
lfc=curves['lastfm'];lfg=lfc['conic_score']-lfc['witness_score']
for n,key in [(50000,'LastfmFiftyGain'),(100000,'LastfmHundredGain')]:
    r=next(r for r in lfc['rows'] if r['N']==n)
    macro('Relative'+key,f"{(r['policy_specific_score']-lfc['witness_score'])/lfg:.3f}")

scale=read('refined_scale'); sg=scale['conic']['metrics']['welfare']-scale['pd']['history'][0]['welfare']
macro('RelativeStressGap',f"{(scale['conic']['metrics']['welfare']-scale['repaired']['welfare'])/sg:.3f}")
macro('RelativeStressCertificate',sci(scale['conic']['certified_gap']/sg))
bounds=read('review_bounds')
macro('RelativeWorstBound',sci(bounds['optimization_bound']['epsilon_T']/cost))
same=read('review_same_state')
same_gaps=[r['same_state_oracle_gap']/(r['oracle_diagnostics']['metrics']['welfare']-r['safety_cost_budget']['witness_score'])
           for t in same['trials'] for r in t['rows']]
macro('RelativeSameStateMean',f'{np.mean(same_gaps):.3f}')
macro('RelativeSameStateMin',f'{min(same_gaps):.3f}')
macro('RelativeSameStateMax',f'{max(same_gaps):.3f}')

# Regenerate paper figures from public/synthetic outputs.
fig,ax=plt.subplots(figsize=(3.5,1.9),layout='constrained')
N=10000; cap=.08;k=np.arange(630,900)
for p,color,label in [(cap,'#D55E00','Plan at the cap'),(.074,'#0072B2','Plan with a safety margin')]:
    x=k/N/cap;y=binom.pmf(k,N,p)*N*cap
    ax.plot(x,y,color=color,label=label);ax.fill_between(x,0,y,where=x>1,color=color,alpha=.25)
    ax.axvline(p/cap,color=color,ls=':',lw=1)
ax.axvline(1,color='black',ls='--',lw=1)
ax.annotate('',xy=(.074/cap,10),xytext=(1,10),arrowprops={'arrowstyle':'<->'})
ax.text(.963,10.6,'Safety margin',ha='center',fontsize=8)
ax.set(xlabel='Realized share / cap',ylabel='Scaled probability\ndensity',xlim=(.7875,1.125),ylim=(0,12.8))
handles,labs=ax.get_legend_handles_labels();fig.legend(handles,labs,loc='outside upper center',ncol=2,fontsize=6.5,handlelength=1.5,columnspacing=1.0);save(fig,'planned_realized_sampling')

fig,axs=plt.subplots(1,2,figsize=(5.2,1.85),layout='constrained')
colors=['#0072B2','#E69F00','#777777','#CC79A7','#D55E00','#009E73']
for ax,d in zip(axs,datasets):
    for method,color,marker in zip(order,colors,['o','v','s','D','x','*']):
        s=summary[d][method]
        ax.scatter(100*s['failures']/s['windows'],s['utility']/summary[d]['conic']['utility'],color=color,
                   marker=marker,s=55 if method=='certified' else 25,label=names[method],zorder=3)
    ax.set(xlabel='Violating windows (%)',ylabel='Utility / conic\nreference',xlim=(-5,105),
           title='Synthetic, N = 20k' if d=='synthetic' else 'Last.fm, N = 100k')
handles,labs=axs[0].get_legend_handles_labels();fig.legend(handles,labs,loc='outside lower center',ncol=3,fontsize=6.7)
save(fig,'review_tradeoffs')

for d,data in curves.items():
    fig,axs=plt.subplots(1,2,figsize=(5.2,1.95),layout='constrained');rs=data['rows'];N0=20000 if d=='synthetic' else 100000
    x=np.array([r['N']/N0 for r in rs]);theta=[r['uniform_budget']['theta'] for r in rs]
    if d=='synthetic':
        replicates=read('sample_size_replicates')
        assert replicates['status']=='complete' and len(replicates['trials'])==5
        summary_rows=replicates['summary'];x=np.array([r['N']/N0 for r in summary_rows])
        theta=np.array([r['theta']['mean'] for r in summary_rows]);theta_sd=np.array([r['theta']['sd'] for r in summary_rows])
        axs[0].errorbar(x,theta,yerr=theta_sd,fmt='o-',color='#0072B2',ms=2.5,capsize=3,elinewidth=.9,capthick=.9,ecolor='#333333',mfc='white')
        upper=max(theta+theta_sd)
    else:
        axs[0].plot(x,theta,'o-',color='#0072B2',ms=3)
        upper=max(theta)
    axs[0].axhline(1,color='.4',ls='--',lw=1,label='Witness slack exhausted')
    axs[0].set(ylabel=r'Mixing fraction $\vartheta$',ylim=(0,upper*1.06));axs[0].legend(fontsize=6.5)
    for key,label,col in [('common_score','Common entropy margin','#E69F00'),('per_type_score','Per-type entropy margin','#009E73'),('policy_specific_score','Policy-dependent certificate','#0072B2')]:
        vals=[np.nan if r[key] is None else (r[key]-data['witness_score'])/(data['conic_score']-data['witness_score']) for r in rs]
        if d=='synthetic':
            method=key.removesuffix('_score')
            vals=[r['methods'][method]['mean'] if r['methods'][method]['plotted'] else np.nan for r in summary_rows]
            sd=[r['methods'][method]['sd'] if r['methods'][method]['plotted'] else np.nan for r in summary_rows]
            axs[1].errorbar(x,vals,yerr=sd,fmt='o-',ms=3,color=col,label=label,capsize=3,elinewidth=.9,capthick=.9,ecolor='#333333',mfc='white')
        else:
            axs[1].plot(x,vals,'o-',ms=3,color=col,label=label)
    axs[1].axhline(1,color='.3',ls='--',lw=1,label='Conic reference, no margin')
    axs[1].axhline(0,color='.6',ls=':',lw=1,label='Uniform witness');axs[1].set_ylabel('Relative score gain Q')
    for ax in axs:
        ax.set_xscale('log');ax.set_xlabel(r'Window size $N/N_0$')
        ticks=[.25,.5,1,2.5,5,10] if d=='synthetic' else [.25,.5,1,2]
        ax.set_xticks(ticks,[f'{v:g}' for v in ticks]);ax.xaxis.set_minor_formatter(NullFormatter());ax.tick_params(axis='x',labelsize=8)
    handles,labs=axs[1].get_legend_handles_labels();fig.legend(handles,labs,loc='outside lower center',ncol=3,fontsize=6);save(fig,'sample_size_'+d)

fig,axs=plt.subplots(1,2,figsize=(5.2,2.05),layout='constrained')
front=base['frontier'];axs[0].plot([r['entropy_floor'] for r in front],[loss(r['metrics']['welfare']) for r in front],
                              'o-',color='#247B91',label='Conic reference')
axs[0].axhline(0,ls='--',color='.45',label='Unconstrained greedy')
py=loss(base['policies']['joint_repaired']['metrics']['welfare'])
axs[0].scatter([.65],[py],marker='x',s=85,linewidths=2.3,color='#B2182B',zorder=10,label='PD, repaired')
axs[0].annotate('PD',xy=(.65,py),xytext=(.70,py-.25),color='#B2182B',fontsize=8,arrowprops={'arrowstyle':'->','color':'#B2182B','lw':.8})
axs[0].set(xlabel='Required normalized entropy',ylabel='Relative loss L',ylim=(-.07,1.5));handles,labs=axs[0].get_legend_handles_labels();fig.legend(handles,labs,loc='outside lower center',ncol=3,fontsize=6.5)
h=base['policies']['joint_pd']['history'];x=np.array([r['iteration'] for r in h]);y=np.array([residual(r) for r in h])
axs[1].plot(x,y,color='#0072B2',lw=1.2,label='Raw PD average')
axs[1].scatter(x[y==0],y[y==0],s=19,facecolors='white',edgecolors='#0072B2',zorder=4,label='Feasible checkpoint')
axs[1].plot(x[1:],y[-1]*np.sqrt(x[-1]/x[1:]),ls=':',color='.4',label=r'$T^{-1/2}$ slope')
axs[1].set_yscale('symlog',linthresh=1e-3);axs[1].set(xlabel='Iterations T',ylabel='Normalized excess V',ylim=(0,max(y)*1.2))
axs[1].legend(fontsize=6.5,loc='upper right');save(fig,'fig6_cwop_benchmark')

fig,axs=plt.subplots(1,3,figsize=(6.0,1.8),layout='constrained')
fref=np.mean([t['rows'][-1]['pooled']['welfare'] for t in fb['trials'] if t['method']=='oracle'])
for method,color in zip(['feedback','logshare','fw_penalty','cwop','cwop_safe'],['#777777','#0072B2','#CC79A7','#D55E00','#009E73']):
    tr=[t for t in fb['trials'] if t['method']==method]
    for ax,key,denom in zip(axs,['welfare','hhi','min_norm_entropy'],[fref,.055,1]):
        v=np.array([[r['pooled'][key]/denom for r in t['rows']] for t in tr]);mean=v.mean(0);sd=v.std(0,ddof=1)
        ax.plot(np.arange(1,21),mean,color=color,label=labels[method],lw=1.3);ax.fill_between(np.arange(1,21),mean-sd,mean+sd,color=color,alpha=.12)
for ax,title in zip(axs,['Utility / conic reference',r'HHI / $\eta$',r'Minimum $H/\log K$']):ax.set(xlabel='Serving window',title=title);ax.tick_params(labelsize=8)
axs[1].axhline(1,color='black',ls=':',lw=.8);axs[1].set_yscale('log');axs[2].axhline(.65,color='black',ls=':',lw=.8)
handles,labs=axs[0].get_legend_handles_labels();fig.legend(handles,labs,loc='outside lower center',ncol=3,fontsize=7);save(fig,'fig7_feedback')

fig,axs=plt.subplots(1,2,figsize=(5.2,1.75),layout='constrained')
for d,col in [('synthetic','#0072B2'),('lastfm','#D55E00')]:
    data=read('refined_calibration_checked_'+d);rs=data['rows'];label='Synthetic' if d=='synthetic' else 'Last.fm';ref=rs[0]['utility']
    axs[0].plot([r['multiplier'] for r in rs],[100*r['rate'] for r in rs],'o-',color=col,label=label)
    axs[1].plot([r['multiplier'] for r in rs],[r['utility']/ref for r in rs],'o-',color=col,label=label)
axs[0].set(xlabel='Analytic margin multiplier c',ylabel='Frozen-window\nviolations (%)')
axs[1].set(xlabel='Analytic margin multiplier c',ylabel='Utility / no-margin utility')
for ax in axs:ax.legend(fontsize=7)
save(fig,'frozen_calibration')

supply=csvrows('supply_threshold_sweep');demand=csvrows('demand_entropy_sweep')
fig,axs=plt.subplots(1,2,figsize=(5.2,1.85),layout='constrained')
for T,col in zip([50000,200000,1000000],['#0072B2','#D55E00','#009E73']):
    rs=sorted([r for r in supply if int(r['steps'])==T],key=lambda r:float(r['lambda_over_star']))
    x=np.array([float(r['lambda_over_star']) for r in rs]);y=np.array([float(r['collapse_fraction_top1_05']) for r in rs]);lo=np.array([float(r['collapse_top1_05_wilson_low']) for r in rs]);hi=np.array([float(r['collapse_top1_05_wilson_high']) for r in rs])
    axs[0].errorbar(x,y,yerr=[y-lo,hi-y],label=f'{T//1000}k steps',color=col,marker='o',ms=3,lw=1,capsize=2)
    rs=sorted([r for r in demand if int(r['steps'])==T//10],key=lambda r:float(r['lambda_over_star']))
    x=[float(r['lambda_over_star']) for r in rs];y=[float(r['normalized_entropy_mean']) for r in rs];err=[1.96*float(r['normalized_entropy_sd'])/np.sqrt(float(r['seeds'])) for r in rs]
    axs[1].errorbar(x,y,yerr=err,label=f'{T//10000}k steps',color=col,marker='o',ms=3,lw=1,capsize=2)
for ax in axs:ax.axvline(1,ls='--',color='.4',lw=.8);ax.set_xlabel(r'Penalty ratio $\lambda/\lambda^\star$');ax.legend(fontsize=7)
axs[0].set(ylabel='Supply collapse fraction',ylim=(-.03,1.03));axs[1].set(ylabel='Normalized exposure\nentropy',ylim=(0,1));save(fig,'fig5_threshold_supply_demand')

rows=[]
for T,lamb in [(50000,0),(200000,0),(1000000,0),(1000000,.2),(1000000,.3),(1000000,.4),(1000000,.5),(1000000,1)]:
    r=next(r for r in supply if int(r['steps'])==T and float(r['lambda_over_star'])==lamb)
    rows.append([f'${T//1000}$k',num(lamb,2),num(float(r['hhi_mean'])*int(r['creators']),2),num(float(r['top1_mean'])),num(float(r['collapse_fraction_top1_05'])),f"$[{float(r['collapse_top1_05_wilson_low']):.3f},{float(r['collapse_top1_05_wilson_high']):.3f}]$"])
table('table_relative_urn',
      r'Two-state sweep: HHI is divided by the uniform floor $1/K$; top-1 and collapse are fractions. '
      r'Intervals are Wilson 95\% intervals over 60 seeds. The 200k zero-penalty cell uses different '
      r'seeds from Table~\ref{tab:twostate}.',
      'tab:tsweep',['$T$',r'$\lambda/\lambda^\star$',r'HHI/$(1/K)$','Top-1 share','Collapse','95\% CI'],rows)
(ROOT/'latex/unified_numbers.tex').write_text('% Derived relative outcomes; all denominators are defined in the text.\n'+
    '\n'.join('\\newcommand{\\'+k+'}{'+v+'}' for k,v in MACROS.items())+'\n')
(ROOT/'build/normalization_checks.json').write_text(json.dumps({'checked_inputs':CHECKED,'macros':MACROS,'baseline_hashes_required':not args.recomputed},indent=2))
print(f'Generated relative tables, eight PDF figures, and {len(MACROS)} numeric macros from {len(CHECKED)} hash-verified inputs.')
