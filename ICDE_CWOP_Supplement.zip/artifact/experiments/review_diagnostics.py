"""Frozen-state comparisons separate optimizer gaps from feedback trajectory changes."""
from evaluation import save_json,RESULTS
from run_feedback import trial

rows=[]
for seed in range(20260910,20260915):
    rows.append(trial(seed,'cwop_diagnostic',None,20,10000,10000))
    save_json(RESULTS/'review_same_state.json',dict(trials=rows))
    print(seed,'same-state comparison complete',flush=True)
