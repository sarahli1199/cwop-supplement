"""Compute whether the simultaneous adaptive-window bound admits the uniform witness."""
import numpy as np
from legacy_controller import make_environment,Targets
from evaluation import uniform,RESULTS,save_json

env=make_environment(); x=uniform(env); rho=env.request_prob@x
J=20; delta=.05; C=env.creators; U=env.users; K=env.candidate_mask.sum(1)

def check(n):
    a=np.sqrt(np.log(6*J*C/delta)/(2*n))
    b=np.minimum(1.,K/2*np.sqrt(np.log(6*J*K.sum()/delta)/(n*env.request_prob)))
    h2=-(b*np.log(np.maximum(b,1e-300))+(1-b)*np.log(np.maximum(1-b,1e-300)))
    omega=np.where(b<=1-1/K,b*np.log(K-1)+h2,np.log(K))
    count_ok=bool(np.all(n*env.request_prob>=8*np.log(3*J*U/delta)))
    margins=dict(hhi=.055-2*a-float(rho@rho),cap=.08-a-float(rho.max()),
                 entropy=float(np.min(np.log(K)-.65*np.log(18)-omega)))
    return dict(requests=n,a=float(a),max_entropy_margin=float(omega.max()),
                witness_slack=margins,feasible=count_ok and min(margins.values())>=0)

lo,hi=1,100000000
assert check(hi)['feasible']
while hi-lo>1:
    mid=(hi+lo)//2
    if check(mid)['feasible']: hi=mid
    else: lo=mid
save_json(RESULTS/'safety_margins.json',dict(windows=J,delta=delta,
          experiment_window=check(10000),minimum_uniform_witness_requests=check(hi)))
print(check(10000)); print(check(hi))
