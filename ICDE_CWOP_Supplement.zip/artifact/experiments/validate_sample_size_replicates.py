"""Independently validate saved policies and Figure 4's means/sample deviations."""
import hashlib,json
import numpy as np
from legacy_controller import Environment,Targets,policy_metrics
from evaluation import RESULTS,uniform,residuals
from plan_safety import margins,witness_cost,certificate

def validate():
    data=json.loads((RESULTS/'sample_size_replicates.json').read_text())
    original=json.loads((RESULTS/'refined_curves.json').read_text())['synthetic']
    target=Targets(.055,.08,.65*np.log(18));methods=['common','per_type','policy_specific']
    assert data['status']=='complete' and [t['seed'] for t in data['trials']]==list(range(20260722,20260727))
    checked=0;independent={}
    for trial in data['trials']:
        assert hashlib.sha256((RESULTS/trial['source_file']).read_bytes()).hexdigest()==trial['source_sha256']
        with np.load(RESULTS/trial['policies']) as arrays, np.load(RESULTS/trial['source_file']) as source:
            for name in ['request_prob','candidate_mask','utility']:np.testing.assert_array_equal(arrays[name],source[name])
            env=Environment(arrays['request_prob'],arrays['candidate_mask'],arrays['utility']);x0=uniform(env)
            w0=policy_metrics(env,x0,target)['welfare'];wref=policy_metrics(env,arrays['reference'],target)['welfare']
            assert residuals(env,arrays['reference'],target).max()<1e-8
            assert abs(w0-trial['witness_score'])<1e-12 and abs(wref-trial['reference_score'])<1e-12
            for i,row in enumerate(trial['rows']):
                N=row['N'];m=margins(env,x0,N,policy_specific=False,cap=target.cap)
                theta=witness_cost(env,target,m)['theta'];assert abs(theta-row['theta'])<1e-12
                independent.setdefault(N,{'theta':[],'common':[],'per_type':[],'policy_specific':[]})['theta'].append(theta)
                for method in methods:
                    result=row['methods'][method]
                    if not result['available']:continue
                    x=arrays[f'{method}_{N}'];assert np.min(x)>=0
                    np.testing.assert_allclose(x.sum(1),1,atol=1e-10)
                    assert not np.any(x[~env.candidate_mask])
                    if method=='policy_specific':assert certificate(env,x,target,N)['valid']
                    else:
                        ent=max(m['entropy']) if method=='common' else np.array(m['entropy'])
                        tight=Targets(target.hhi-m['hhi'],target.cap-max(m['cap']),target.entropy+ent)
                        assert residuals(env,x,tight).max()<1e-8
                    score=policy_metrics(env,x,target)['welfare'];Q=(score-w0)/(wref-w0)
                    assert abs(score-result['score'])<1e-12 and abs(Q-result['Q'])<1e-12
                    independent[N][method].append(Q);checked+=1
                    if trial['seed']==20260722:
                        assert row['N']==original['rows'][i]['N']
                        assert abs(score-original['rows'][i][method+'_score'])<1e-8
    for row in data['summary']:
        values=independent[row['N']]
        for method in ['theta']+methods:
            result=row['theta'] if method=='theta' else row['methods'][method]
            v=values[method];assert result['n']==len(v)
            if len(v)!=5:
                assert result['plotted'] is False and result['mean'] is None and result['sd'] is None
                continue
            assert abs(result['mean']-np.mean(v))<1e-12
            assert abs(result['sd']-np.std(v,ddof=1))<1e-12
    report={'status':'PASS','graphs':5,'sample_sizes':7,'checked_policies':checked,
        'original_base_graph_scores_reproduced':True,
        'means_and_sample_standard_deviations_independently_verified':True,
        'partial_graph_subsets_excluded_from_plotted_means':True,
        'all_plotted_policies_pass_their_applicable_constraint_or_certificate_checks':True}
    path=RESULTS.parent/'verification/sample_size_replicates.json'
    path.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':validate()
