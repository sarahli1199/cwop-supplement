#!/usr/bin/env python3
"""Controlled evaluation of a projected primal--dual CWOP controller.

The benchmark is intentionally synthetic: it supplies known request probabilities,
candidate sets, and utilities, so welfare and constraint violations are observable without
claiming an offline causal estimate from the production log.  The implemented action is a
single creator, which is the length-one special case of the manuscript's finite-slate
occupancy model.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np


@dataclass(frozen=True)
class Environment:
    request_prob: np.ndarray
    candidate_mask: np.ndarray
    utility: np.ndarray

    @property
    def users(self) -> int:
        return int(self.utility.shape[0])

    @property
    def creators(self) -> int:
        return int(self.utility.shape[1])


@dataclass(frozen=True)
class Targets:
    hhi: float
    cap: float
    entropy: float


def make_environment(
    seed: int = 20260722,
    users: int = 24,
    creators: int = 36,
    candidates: int = 18,
    groups: int = 6,
    head_count: int = 6,
) -> Environment:
    """Create a reproducible candidate graph at either baseline or stress-test scale."""
    rng = np.random.default_rng(seed)
    if min(users, creators, candidates, groups, head_count) <= 0:
        raise ValueError("environment dimensions must be positive")
    if head_count >= creators or candidates > creators or groups > creators - head_count:
        raise ValueError("incompatible creator, candidate, group, or head dimensions")
    grouped_creators = [
        np.asarray(block, dtype=int)
        for block in np.array_split(np.arange(head_count, creators), groups)
    ]
    if any(head_count + block.size > candidates for block in grouped_creators):
        raise ValueError("candidate count is too small for shared head and group creators")

    request_prob = rng.uniform(0.65, 1.35, size=users)
    request_prob /= request_prob.sum()
    candidate_mask = np.zeros((users, creators), dtype=bool)

    for user in range(users):
        group = user % groups
        selected = set(range(head_count))
        selected.update(int(c) for c in grouped_creators[group])
        remaining = [c for c in range(head_count, creators) if c not in selected]
        fill = rng.choice(remaining, size=candidates - len(selected), replace=False)
        selected.update(int(c) for c in fill)
        candidate_mask[user, list(selected)] = True

    creator_quality = rng.normal(0.0, 0.12, size=creators)
    creator_quality[:head_count] += np.linspace(1.35, 0.90, head_count)
    utility = np.full((users, creators), -np.inf, dtype=float)
    for user in range(users):
        group = user % groups
        row = creator_quality.copy()
        row[grouped_creators[group]] += 0.85
        row += rng.normal(0.0, 0.10, size=creators)
        utility[user, candidate_mask[user]] = row[candidate_mask[user]]

    return Environment(request_prob=request_prob, candidate_mask=candidate_mask, utility=utility)


def project_simplex_with_floor(values: np.ndarray, floor: float) -> np.ndarray:
    """Euclidean projection onto {x: sum x=1, x_i>=floor}."""
    count = values.size
    remaining = 1.0 - count * floor
    if remaining <= 0:
        raise ValueError("floor is too large for the simplex dimension")
    shifted = values - floor
    ordered = np.sort(shifted)[::-1]
    cumulative = np.cumsum(ordered)
    condition = ordered - (cumulative - remaining) / np.arange(1, count + 1) > 0
    rho = int(np.nonzero(condition)[0][-1])
    theta = (cumulative[rho] - remaining) / float(rho + 1)
    return np.maximum(shifted - theta, 0.0) + floor


def project_rows(values: np.ndarray, mask: np.ndarray, floor: float) -> np.ndarray:
    projected = np.zeros_like(values)
    for user in range(values.shape[0]):
        active = mask[user]
        projected[user, active] = project_simplex_with_floor(values[user, active], floor)
    return projected


def entropy_rows(policy: np.ndarray, mask: np.ndarray) -> np.ndarray:
    result = np.zeros(policy.shape[0], dtype=float)
    for user in range(policy.shape[0]):
        probabilities = policy[user, mask[user]]
        positive = probabilities > 0
        result[user] = -float(np.sum(probabilities[positive] * np.log(probabilities[positive])))
    return result


def policy_metrics(env: Environment, policy: np.ndarray, targets: Targets) -> Dict[str, float]:
    rho = env.request_prob @ policy
    entropies = entropy_rows(policy, env.candidate_mask)
    max_entropies = np.log(env.candidate_mask.sum(axis=1))
    welfare = float(np.sum(env.request_prob[:, None] * policy * np.where(env.candidate_mask, env.utility, 0.0)))
    hhi = float(np.dot(rho, rho))
    cap = float(np.max(rho))
    hhi_violation = max(0.0, hhi - targets.hhi)
    cap_violation = max(0.0, cap - targets.cap)
    entropy_violation = float(np.max(np.maximum(0.0, targets.entropy - entropies)))
    return {
        "welfare": welfare,
        "hhi": hhi,
        "max_share": cap,
        "min_norm_entropy": float(np.min(entropies / max_entropies)),
        "mean_norm_entropy": float(np.mean(entropies / max_entropies)),
        "hhi_violation": hhi_violation,
        "cap_violation": cap_violation,
        "entropy_violation": entropy_violation,
        "max_violation": max(hhi_violation, cap_violation, entropy_violation),
    }


def greedy_policy(env: Environment, floor: float) -> np.ndarray:
    policy = np.zeros_like(env.utility)
    for user in range(env.users):
        active = np.flatnonzero(env.candidate_mask[user])
        mass = 1.0 - floor * active.size
        policy[user, active] = floor
        best = active[int(np.argmax(env.utility[user, active]))]
        policy[user, best] += mass
    return policy


def softmax_policy(env: Environment, temperature: float, floor: float) -> np.ndarray:
    policy = np.zeros_like(env.utility)
    for user in range(env.users):
        active = env.candidate_mask[user]
        scores = env.utility[user, active] / temperature
        scores -= np.max(scores)
        probabilities = np.exp(scores)
        probabilities /= probabilities.sum()
        probabilities = (1.0 - floor * probabilities.size) * probabilities + floor
        policy[user, active] = probabilities
    return policy


def constraint_vector(
    env: Environment,
    policy: np.ndarray,
    targets: Targets,
) -> Tuple[float, np.ndarray, np.ndarray]:
    rho = env.request_prob @ policy
    return (
        float(np.dot(rho, rho) - targets.hhi),
        rho - targets.cap,
        targets.entropy - entropy_rows(policy, env.candidate_mask),
    )


def primal_dual_cwop(
    env: Environment,
    targets: Targets,
    iterations: int,
    floor: float,
    primal_rate: float,
    dual_rate: float,
    dual_bound: float,
    use_global: bool,
    use_local: bool,
    record_every: int = 100,
) -> Tuple[np.ndarray, List[Dict[str, float]], Dict[str, float]]:
    """Projected gradient ascent/descent for the finite contextual saddle problem."""
    policy = np.zeros_like(env.utility)
    for user in range(env.users):
        policy[user, env.candidate_mask[user]] = 1.0 / env.candidate_mask[user].sum()
    average = np.zeros_like(policy)

    hhi_dual = 0.0
    cap_dual = np.zeros(env.creators, dtype=float)
    entropy_dual = np.zeros(env.users, dtype=float)
    history: List[Dict[str, float]] = []
    started = time.perf_counter()

    for step_index in range(1, iterations + 1):
        rho = env.request_prob @ policy
        g_hhi, g_cap, g_entropy = constraint_vector(env, policy, targets)
        safe_policy = np.maximum(policy, floor)
        gradient = env.request_prob[:, None] * np.where(env.candidate_mask, env.utility, 0.0)

        if use_global:
            gradient -= env.request_prob[:, None] * (
                2.0 * hhi_dual * rho[None, :] + cap_dual[None, :]
            )
        if use_local:
            entropy_gradient = -(np.log(safe_policy) + 1.0)
            gradient += entropy_dual[:, None] * entropy_gradient
        gradient[~env.candidate_mask] = 0.0

        average += (policy - average) / float(step_index)
        step_primal = primal_rate / math.sqrt(step_index)
        policy = project_rows(policy + step_primal * gradient, env.candidate_mask, floor)

        step_dual = dual_rate / math.sqrt(step_index)
        if use_global:
            hhi_dual = float(np.clip(hhi_dual + step_dual * g_hhi, 0.0, dual_bound))
            cap_dual = np.clip(cap_dual + step_dual * g_cap, 0.0, dual_bound)
        if use_local:
            entropy_dual = np.clip(entropy_dual + step_dual * g_entropy, 0.0, dual_bound)

        if step_index == 1 or step_index % record_every == 0 or step_index == iterations:
            row = {"iteration": float(step_index)}
            row.update(policy_metrics(env, average, targets))
            row.update(
                {
                    "hhi_dual": hhi_dual,
                    "max_cap_dual": float(np.max(cap_dual)),
                    "max_entropy_dual": float(np.max(entropy_dual)),
                }
            )
            history.append(row)

    elapsed = time.perf_counter() - started
    diagnostics = {
        "solver_seconds": elapsed,
        "milliseconds_per_iteration": 1000.0 * elapsed / iterations,
        "hhi_dual": hhi_dual,
        "max_cap_dual": float(np.max(cap_dual)),
        "max_entropy_dual": float(np.max(entropy_dual)),
    }
    return average, history, diagnostics


def tracking_experiment(
    env: Environment,
    policy: np.ndarray,
    targets: Targets,
    requests: int,
    seeds: Iterable[int],
) -> Dict[str, float]:
    target_rho = env.request_prob @ policy
    values: List[Dict[str, float]] = []
    for seed in seeds:
        rng = np.random.default_rng(seed)
        user_counts = rng.multinomial(requests, env.request_prob)
        creator_counts = np.zeros(env.creators, dtype=np.int64)
        empirical_policy = np.zeros_like(policy)
        for user, count in enumerate(user_counts):
            if count == 0:
                continue
            draws = rng.multinomial(int(count), policy[user])
            creator_counts += draws
            empirical_policy[user] = draws / float(count)
        empirical_rho = creator_counts / float(requests)
        max_user_tv = 0.0
        for user, count in enumerate(user_counts):
            if count > 0:
                max_user_tv = max(
                    max_user_tv,
                    0.5 * float(np.sum(np.abs(empirical_policy[user] - policy[user]))),
                )
        empirical_entropies = entropy_rows(empirical_policy, env.candidate_mask)
        empirical_max_violation = max(
            max(0.0, float(np.dot(empirical_rho, empirical_rho)) - targets.hhi),
            max(0.0, float(np.max(empirical_rho)) - targets.cap),
            float(np.max(np.maximum(0.0, targets.entropy - empirical_entropies))),
        )
        values.append(
            {
                "max_creator_error": float(np.max(np.abs(empirical_rho - target_rho))),
                "max_user_tv": max_user_tv,
                "empirical_max_violation": empirical_max_violation,
            }
        )

    output: Dict[str, float] = {}
    for key in values[0]:
        array = np.array([row[key] for row in values], dtype=float)
        output[f"{key}_mean"] = float(array.mean())
        output[f"{key}_max"] = float(array.max())
    return output


def save_csv(path: Path, rows: List[Dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = list(rows[0].keys())
    known = set(fieldnames)
    for row in rows[1:]:
        for key in row:
            if key not in known:
                fieldnames.append(key)
                known.add(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out-dir", type=Path, default=Path(__file__).resolve().parents[1] / "data")
    parser.add_argument("--iterations", type=int, default=30000)
    parser.add_argument("--tracking-requests", type=int, default=200000)
    parser.add_argument("--tracking-seeds", type=int, default=20)
    parser.add_argument("--seed", type=int, default=20260722)
    args = parser.parse_args()

    env = make_environment(args.seed)
    candidate_count = int(env.candidate_mask.sum(axis=1)[0])
    targets = Targets(
        hhi=0.055,
        cap=0.080,
        entropy=0.65 * math.log(candidate_count),
    )
    floor = 1e-7

    policies: Dict[str, np.ndarray] = {
        "Unconstrained greedy": greedy_policy(env, floor),
        "Entropy-regularized": softmax_policy(env, temperature=0.30, floor=floor),
    }
    diagnostics: Dict[str, Dict[str, float]] = {
        name: {"solver_seconds": 0.0, "milliseconds_per_iteration": 0.0}
        for name in policies
    }
    convergence_rows: List[Dict[str, object]] = []

    solver_configs = [
        ("Global-only PD", True, False, 5.00),
        ("Local-only PD", False, True, 1.25),
        ("CWOP joint PD", True, True, 1.25),
    ]
    for name, use_global, use_local, configured_dual_rate in solver_configs:
        policy, history, diag = primal_dual_cwop(
            env=env,
            targets=targets,
            iterations=args.iterations,
            floor=floor,
            primal_rate=0.75,
            dual_rate=configured_dual_rate,
            dual_bound=100.0,
            use_global=use_global,
            use_local=use_local,
        )
        policies[name] = policy
        diagnostics[name] = diag
        for row in history:
            convergence_rows.append({"policy": name, **row})

    greedy_welfare = policy_metrics(env, policies["Unconstrained greedy"], targets)["welfare"]
    summary_rows: List[Dict[str, object]] = []
    tracking_seeds = range(args.seed + 1000, args.seed + 1000 + args.tracking_seeds)
    for name, policy in policies.items():
        row: Dict[str, object] = {"policy": name}
        metrics = policy_metrics(env, policy, targets)
        row.update(metrics)
        row["normalized_welfare"] = metrics["welfare"] / greedy_welfare
        row.update(diagnostics[name])
        row.update(
            tracking_experiment(
                env,
                policy,
                targets,
                requests=args.tracking_requests,
                seeds=tracking_seeds,
            )
        )
        summary_rows.append(row)

    # A controlled welfare--diversity sweep using the joint controller.
    frontier_rows: List[Dict[str, object]] = []
    for ratio in (0.30, 0.45, 0.55, 0.65, 0.75):
        sweep_targets = Targets(hhi=targets.hhi, cap=targets.cap, entropy=ratio * math.log(candidate_count))
        policy, _, diag = primal_dual_cwop(
            env=env,
            targets=sweep_targets,
            iterations=args.iterations,
            floor=floor,
            primal_rate=0.75,
            dual_rate=1.25,
            dual_bound=100.0,
            use_global=True,
            use_local=True,
            record_every=args.iterations,
        )
        metrics = policy_metrics(env, policy, sweep_targets)
        frontier_rows.append(
            {
                "entropy_floor_ratio": ratio,
                "normalized_welfare": metrics["welfare"] / greedy_welfare,
                **metrics,
                **diag,
            }
        )

    save_csv(args.out_dir / "cwop_benchmark_summary.csv", summary_rows)
    save_csv(args.out_dir / "cwop_benchmark_convergence.csv", convergence_rows)
    save_csv(args.out_dir / "cwop_benchmark_frontier.csv", frontier_rows)
    metadata = {
        "benchmark": "synthetic finite contextual single-item request model",
        "seed": args.seed,
        "users": env.users,
        "creators": env.creators,
        "candidates_per_user": candidate_count,
        "iterations": args.iterations,
        "tracking_requests": args.tracking_requests,
        "tracking_seeds": args.tracking_seeds,
        "targets": {
            "hhi": targets.hhi,
            "cap": targets.cap,
            "entropy": targets.entropy,
            "entropy_ratio": targets.entropy / math.log(candidate_count),
        },
        "solver_config": {
            "primal_rate": 0.75,
            "dual_rates": {
                name: configured_dual_rate
                for name, _, _, configured_dual_rate in solver_configs
            },
            "dual_bound": 100.0,
        },
        "floor": floor,
        "summary": summary_rows,
        "frontier": frontier_rows,
    }
    (args.out_dir / "cwop_benchmark.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()
