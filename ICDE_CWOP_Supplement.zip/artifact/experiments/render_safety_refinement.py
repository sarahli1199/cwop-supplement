"""Render new safety evidence directly from saved computed results."""
import json
import numpy as np
from scipy.stats import binom
from render_review import PAPER,ROOT,RESULTS,read,table,plt
from matplotlib.ticker import NullFormatter
from evaluation import save_json

def savefig(fig,name):
    for directory in {PAPER/'generated',ROOT/'generated'}:
        directory.mkdir(exist_ok=True)
        fig.savefig(directory/(name+'.pdf'));fig.savefig(directory/(name+'.png'),dpi=180)
    plt.close(fig)

def main():
    plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
    # An exact binomial illustration, not a measured experiment.
    fig,ax=plt.subplots(figsize=(6.5,1.75),layout='constrained')
    N=10000;cap=.08;safe=.074;k=np.arange(630,900)
    for p,col,label in [(cap,'#D55E00','Plan at the cap'),(safe,'#0072B2','Plan with a safety margin')]:
        density=binom.pmf(k,N,p)*N
        ax.plot(k/N,density,color=col,label=label)
        ax.fill_between(k/N,0,density,where=k/N>cap,color=col,alpha=.25)
        ax.axvline(p,color=col,ls=':',lw=1)
    ax.axvline(cap,color='black',ls='--',lw=1)
    ax.annotate('',xy=(safe,125),xytext=(cap,125),arrowprops={'arrowstyle':'<->','color':'black'})
    ax.text((safe+cap)/2,133,'Safety margin',ha='center',fontsize=8)
    ax.set(xlabel='Realized creator share',ylabel='Binomial density',xlim=(.063,.090),ylim=(0,160))
    ax.legend(fontsize=7,loc='upper right');savefig(fig,'planned_realized_sampling')
    curves=read('refined_curves.json')
    for name,data in curves.items():
        fig,ax=plt.subplots(1,2,figsize=(6.5,2.2),layout='constrained');rows=data['rows']
        Ns=np.array([r['N'] for r in rows]);theta=np.array([r['uniform_budget']['theta'] for r in rows])
        ax[0].plot(Ns,theta,'o-',color='#0072B2',ms=3)
        ax[0].axhline(1,color='.4',ls='--',lw=1,label='Witness slack exhausted')
        ax[0].set(xscale='log',xlabel='Requests per window, N',ylabel=r'Mixing fraction $\vartheta$',ylim=(0,max(theta)*1.06))
        ax[0].legend(fontsize=6.5)
        for key,label,col in [('common_score','Common entropy margin','#E69F00'),('per_type_score','Per-type entropy margin','#009E73'),('policy_specific_score','Policy-dependent certificate','#0072B2')]:
            vals=np.array([np.nan if r[key] is None else r[key] for r in rows])
            ax[1].plot(Ns,vals,'o-',ms=3,color=col,label=label)
        ax[1].axhline(data['conic_score'],color='.3',ls='--',lw=1,label='Conic reference, no margin')
        ax[1].axhline(data['witness_score'],color='.6',ls=':',lw=1,label='Uniform witness')
        ax[1].set(xscale='log',xlabel='Requests per window, N',ylabel='Expected score')
        for a in ax:
            a.set_xticks([10000,50000,100000,200000],['10k','50k','100k','200k'])
            a.xaxis.set_minor_formatter(NullFormatter())
            a.tick_params(axis='x',labelsize=8)
        ax[1].legend(fontsize=6,loc='best');savefig(fig,'sample_size_'+name)
    summary={};rows=[]
    for name in ('synthetic','lastfm'):
        data=read('refined_feedback_'+name+'.json');summary[name]={}
        for method in ('conic','conic_certified'):
            ts=[t for t in data['trials'] if t['method']==method]
            rs=[r for t in ts for r in t['rows']]
            cal=[c for c in data['calibration'] if c['method']==method]
            s=dict(utility=float(np.mean([t['rows'][-1]['pooled']['welfare'] for t in ts])),
                   utility_sd=float(np.std([t['rows'][-1]['pooled']['welfare'] for t in ts],ddof=1)),
                   window_failures=sum(r['empirical']['max_violation']>1e-6 for r in rs),windows=len(rs),
                   frozen_failures=sum(c['failures'] for c in cal),frozen_replications=sum(c['repetitions'] for c in cal),
                   max_window_upper95=max(c['one_sided_95_upper'] for c in cal),
                   N=ts[0]['N'],minimum_uniform_n=[t['minimum_uniform_n'] for t in ts])
            if method=='conic_certified':
                s['max_certified_excess']=max(r['safety']['certificate']['max_certified_excess'] for r in rs)
                s['mixture_range']=[min(r['safety']['theta'] for r in rs),max(r['safety']['theta'] for r in rs)]
            summary[name][method]=s
            rows.append([name.capitalize() if name!='lastfm' else 'Last.fm',
                'Conic + certificate' if method=='conic_certified' else 'Conic, no margin',
                f"${s['N']//1000}$k",f"${s['utility']:.3f}\\pm{s['utility_sd']:.3f}$",
                f"${s['window_failures']}/{s['windows']}$",f"${s['frozen_failures']}/{s['frozen_replications']}$"])
    table('table_certified_feedback.tex',r'Analytic safety with feedback. Five synthetic graphs and three Last.fm splits each have 20 windows. Frozen tests independently resample each of 20 saved plans on the first graph/split 2,000 times; they assess conditional window risk, not 40,000 independent adaptive trajectories. Last.fm responses are simulated from clipped learned proxies.',
          'tab:certified-feedback',['Data','Policy','$N$','Utility','Window failures','Frozen failures'],rows)
    rows=[]
    for r in curves['synthetic']['rows']:
        if r['N'] in (12338,20000,50000,100000):
            fmt=lambda v:'---' if v is None else f'${v:.3f}$'
            rows.append([f"${r['N']:,}$",f"${r['uniform_budget']['theta']:.3f}$",fmt(r['common_score']),fmt(r['per_type_score']),fmt(r['policy_specific_score'])])
    table('table_sample_size.tex',r'Base synthetic graph: safety cost versus window size. The coefficient is for policy-independent per-type margins. Scores retain their specified synthetic zero. Policy-dependent scores are feasible constructions, not certified optimal values of a chance-constrained problem.',
          'tab:sample-size',['Requests',r'$\vartheta$','Common floor','Per-type floors','Policy-dependent'],rows)
    fig,ax=plt.subplots(1,2,figsize=(6.5,2.25),layout='constrained')
    for name,col in [('synthetic','#0072B2'),('lastfm','#D55E00')]:
        data=read('refined_calibration_checked_'+name+'.json');r=data['rows']
        label='Synthetic' if name=='synthetic' else 'Last.fm'
        ax[0].plot([v['multiplier'] for v in r],[100*v['rate'] for v in r],'o-',color=col,label=label)
        ax[1].plot([v['multiplier'] for v in r],[v['utility'] for v in r],'o-',color=col,label=label)
    ax[0].set(xlabel='Analytic margin multiplier, c',ylabel='Frozen-window violations (%)')
    ax[1].set(xlabel='Analytic margin multiplier, c',ylabel='Expected response probability')
    for a in ax:a.legend(fontsize=7)
    savefig(fig,'frozen_calibration')
    save_json(RESULTS/'refined_summary.json',summary)
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
