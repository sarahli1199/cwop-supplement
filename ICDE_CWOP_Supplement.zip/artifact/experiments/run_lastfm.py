"""Public artist-listening-derived benchmark; NOT logged-slate policy evaluation.

Only user_artists.dat is read. A rank-16 truncated SVD of training log counts produces
nonnegative preference proxies. Unobserved entries are zero in this explicit surrogate,
not asserted to be negative preferences. Retrieval is constructed, not a recovered slate.
"""
import hashlib
import io
import json
import zipfile
import numpy as np
from legacy_controller import Environment, Targets, entropy_rows, policy_metrics, greedy_policy, softmax_policy
from evaluation import ROOT, RESULTS, Oracle, run_pd, repair, uniform, save_json, best_uniform_mixture
from compact_controller import solve
from evaluation import witness_certificate


def load_matrix():
    archive=ROOT/'external/hetrec2011-lastfm-2k.zip'
    with zipfile.ZipFile(archive) as z:
        rows=np.loadtxt(io.BytesIO(z.read('user_artists.dat')),skiprows=1,dtype=np.int64)
    users=np.unique(rows[:,0]); artists,frequency=np.unique(rows[:,1],return_counts=True)
    chosen=artists[np.lexsort((artists,-frequency))[:256]]
    user_map={int(x):i for i,x in enumerate(users)}
    artist_map={int(x):i for i,x in enumerate(chosen)}
    matrix=np.zeros((len(users),256))
    for u,c,w in rows:
        if c in artist_map:
            matrix[user_map[int(u)],artist_map[int(c)]]=np.log1p(w)
    eligible=np.flatnonzero((matrix>0).sum(1)>=20)
    selected=np.random.default_rng(20260918).choice(eligible,128,replace=False)
    return matrix,selected,hashlib.sha256(archive.read_bytes()).hexdigest(),len(rows)


def build(seed,matrix,selected):
    rng=np.random.default_rng(seed)
    train=matrix.copy(); test=np.zeros_like(matrix,dtype=bool)
    for u in range(len(matrix)):
        positive=np.flatnonzero(matrix[u]>0)
        if len(positive)>=5:
            held=rng.choice(positive,max(1,len(positive)//5),replace=False)
            test[u,held]=True; train[u,held]=0
    left,singular,right=np.linalg.svd(train,full_matrices=False)
    pred=np.maximum((left[:,:16]*singular[:16])@right[:16],0)
    # Evaluate withheld recorded positives, not offline utility or missing negatives.
    recalls=[]; poprecalls=[]
    popularity=(train>0).sum(0)
    for u in selected:
        held=np.flatnonzero(test[u]); assert len(held)>0
        rank=np.argsort(np.where(train[u]>0,-np.inf,pred[u]))[-20:]
        prank=np.argsort(np.where(train[u]>0,-np.inf,popularity))[-20:]
        recalls.append(np.isin(held,rank).mean()); poprecalls.append(np.isin(held,prank).mean())
    scores=pred[selected]
    scale=float(train.max())
    scores=scores/scale
    mask=np.zeros_like(scores,dtype=bool)
    for u in range(128):
        top=np.argsort(scores[u])[-32:]
        mask[u,top]=True
        rest=np.flatnonzero(~mask[u]); mask[u,rng.choice(rest,32,replace=False)]=True
    env=Environment(np.full(128,1/128),mask,np.where(mask,scores,-np.inf))
    x0=uniform(env); rho=env.request_prob@x0
    target=Targets(1.5*float(rho@rho),1.5*float(rho.max()),.65*np.log(64))
    return env,target,dict(heldout_recall20=float(np.mean(recalls)),
                          popularity_recall20=float(np.mean(poprecalls)),
                          utility_scale=scale,rank=16,users=128,artists=256,candidates=64,
                          targets=dict(hhi=target.hhi,cap=target.cap,entropy=target.entropy))


def main():
    matrix,selected,sha,nrows=load_matrix()
    output=dict(source_url='https://files.grouplens.org/datasets/hetrec2011/hetrec2011-lastfm-2k.zip',
                source_sha256=sha,raw_listening_rows=nrows,protocol='positive-entry holdout, rank-16 SVD, constructed retrieval',instances=[])
    rates=json.loads((RESULTS/'lastfm_tuning.json').read_text())['selected']
    output['selected_rates']=rates
    for seed in (20260920,20260921,20260922):
        env,target,meta=build(seed,matrix,selected)
        xo,od=Oracle(env,target).solve()
        cert=witness_certificate(env,target)
        bound=float(np.ceil(cert['dual_l1_upper']/100)*100)
        xp,history,diag=solve(env,target,30000,dual_bound=bound,**rates)
        pd=dict(history=history,diagnostics=diag,witness=cert,dual_bound=bound,**rates)
        xr,theta=repair(env,xp,target)
        mixtures=[]
        for temp in [.01,.03,.1,.3,1.]:
            xm,mix=best_uniform_mixture(env,softmax_policy(env,temp,1e-7),target)
            mixtures.append(dict(temperature=temp,mix=mix,**policy_metrics(env,xm,target)))
        row=dict(seed=seed,**meta,oracle=od,pd=pd,
                 greedy=policy_metrics(env,greedy_policy(env,0.),target),
                 raw=policy_metrics(env,xp,target),repaired=policy_metrics(env,xr,target),repair_theta=theta,
                 best_feasible_softmax=max(mixtures,key=lambda r:r['welfare']),mixtures=mixtures)
        output['instances'].append(row)
        np.savez_compressed(RESULTS/f'lastfm_{seed}.npz',request_prob=env.request_prob,
                            candidate_mask=env.candidate_mask,utility=env.utility,oracle=xo,raw=xp,repaired=xr)
        save_json(RESULTS/'lastfm.json',output)
        print(seed,'oracle',od['metrics']['welfare'],'PD',row['repaired']['welfare'],
              'recall',meta['heldout_recall20'],'pop',meta['popularity_recall20'],flush=True)


if __name__=='__main__':
    main()
