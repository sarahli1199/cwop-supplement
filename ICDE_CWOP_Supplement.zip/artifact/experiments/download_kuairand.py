"""Download the public KuaiRand-Pure archive and verify the publisher checksum."""
from pathlib import Path
import argparse
import hashlib
import shutil
import tarfile
from urllib.request import urlopen

URL='https://zenodo.org/records/10439422/files/KuaiRand-Pure.tar.gz'
MD5='0820331067a3784d9691136f772b35a7'
FILES={'video_features_basic_pure.csv','log_standard_4_08_to_4_21_pure.csv',
       'log_random_4_22_to_5_08_pure.csv'}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    a.output.mkdir(parents=True,exist_ok=True);archive=a.output/'KuaiRand-Pure.tar.gz'
    if not archive.exists():
        with urlopen(URL,timeout=120) as source,archive.open('wb') as dest:
            shutil.copyfileobj(source,dest)
    assert hashlib.md5(archive.read_bytes()).hexdigest()==MD5,'Archive checksum mismatch'
    extracted=set()
    with tarfile.open(archive) as tar:
        for member in tar.getmembers():
            name=Path(member.name).name
            if member.isfile() and name in FILES:
                assert name not in extracted
                with tar.extractfile(member) as source,(a.output/name).open('wb') as dest:
                    shutil.copyfileobj(source,dest)
                extracted.add(name)
    assert extracted==FILES
    print('Verified public archive; extracted required files to',a.output)


if __name__=='__main__':main()
