"""Cross-check new tables, selection, repeated samples, and final certificates."""
import json
import numpy as np
from evaluation import RESULTS
from legacy_controller import Environment,Targets
from plan_safety import frozen_test
from run_safety_refinement import lastfm,BASE
from test_plan_safety import main as test_certificates

def read(name):return json.loads((RESULTS/name).read_text())

def main():
    test_certificates()
    b=read('refined_baselines.json')
    assert len(b['training'])==10 and len(b['test'])==20 and len(b['test_grid'])==25
    assert all(t['fw_iterations']==10000 for t in b['training']+b['test_grid'])
    for method,chosen in b['selection'].items():
        choices=[o for o in b['options'] if o['method']==method]
        eligible=[o for o in choices if o['rate']<=.05]
        expected=max(eligible,key=lambda o:o['utility']) if eligible else min(choices,key=lambda o:(o['rate'],o['normalized_excess'],-o['utility']))
        assert chosen==expected['parameter']
    assert b['selection']['fairco_batch']==.001
    for dataset in ('synthetic','lastfm'):
        data=read('refined_feedback_'+dataset+'.json')
        assert len(data['trials'])==(10 if dataset=='synthetic' else 6)
        assert len(data['calibration'])==40
        for t in data['trials']:assert len(t['rows'])==20
        curve=read('refined_calibration_checked_'+dataset+'.json')
        assert len(curve['rows'])==11
        endpoint=curve['rows'][-1]
        assert endpoint['multiplier']==1 and endpoint['certificate']['valid']
        assert endpoint['certificate']['max_certified_excess']<0
        assert all(r['scaled_excess']<=-1e-10 for r in curve['rows'])
        # Reproduce one entire frozen-plan binomial experiment for each dataset.
        trial=next(t for t in data['trials'] if t['method']=='conic_certified')
        a=np.load(RESULTS/trial['plans']);env=Environment(a['q'],a['mask'],a['utility'])
        target=BASE if dataset=='synthetic' else lastfm(trial['seed'])[1]
        saved=next(c for c in data['calibration'] if c['method']=='conic_certified' and c['window']==1)
        fresh=frozen_test(env,a['plans'][0],target,trial['N'],saved['repetitions'],saved['seed'])
        for key,value in fresh.items():assert saved[key]==value,(dataset,key)
    scale=read('refined_scale.json')
    assert scale['edges']==32768 and scale['conic']['certified_gap']<6e-8
    assert abs(scale['conic']['metrics']['welfare']-scale['repaired']['welfare']-.1847855701269713)<1e-10
    print('PASS: final-policy margin endpoints, 320 feedback windows, 160000 frozen replications, 22 multiplier settings, training-only selection, FW 10000 steps, scale result; two frozen tests rerun exactly.')

if __name__=='__main__':main()
