"""Display overlapping estimates and exact zero residuals without moving the data."""
import numpy as np
import matplotlib.patheffects as pe

def repaired_marker(ax,x,y,label='Repaired PD'):
    point=ax.scatter([x],[y],marker='x',s=100,linewidths=2.3,color='#C62828',
                     zorder=10,label=label)
    point.set_path_effects([pe.withStroke(linewidth=4.6,foreground='white'),pe.Normal()])
    ax.annotate('Repaired PD',xy=(x,y),xytext=(x+.10,y+.065),fontsize=7,
                color='#A51D1D',ha='center',va='bottom',zorder=11,
                arrowprops=dict(arrowstyle='->',color='#A51D1D',lw=.8,
                                shrinkA=2,shrinkB=6))
    return point

def residual_trace(ax,history,reference=True):
    t=np.asarray([r['iteration'] for r in history])
    residual=np.asarray([r['max_violation'] for r in history])
    assert np.all(residual>=0) and np.all(np.diff(t)>0)
    ax.set_xscale('log')
    # Linear near zero, logarithmic above the threshold: no artificial 1e-10 floor.
    ax.set_yscale('symlog',linthresh=1e-4,linscale=.8)
    line,=ax.plot(t,residual,color='#C85C32',lw=1.5,label='Raw average residual')
    if reference:
        slope=residual[-1]*np.sqrt(t[-1]/t)
        selected=t>=100
        ax.plot(t[selected],slope[selected],':',color='.4',lw=1.2,
                label=r'$T^{-1/2}$ reference slope')
    zeros=residual==0
    ax.scatter(t[zeros],residual[zeros],s=26,marker='o',facecolors='white',
               edgecolors='#C85C32',linewidths=1.3,zorder=8,clip_on=False)
    checkpoint=np.flatnonzero(zeros & (t>1))
    if checkpoint.size:
        index=checkpoint[0]
        ax.annotate('Zero violation',xy=(t[index],0),xycoords='data',
                    xytext=(.30,.29),textcoords='axes fraction',fontsize=7,
                    color='#865029',ha='center',
                    arrowprops=dict(arrowstyle='->',color='#865029',lw=.8,
                                    shrinkA=2,shrinkB=4))
    ax.set_ylim(0,1e-2)
    ax.set_yticks([0,1e-4,1e-3,1e-2])
    ax.set_yticklabels(['0',r'$10^{-4}$',r'$10^{-3}$',r'$10^{-2}$'])
    ax.set(xlabel='Iterations',ylabel='Maximum constraint violation')
    ax.legend(fontsize=6.5,loc='upper right')
    return line
