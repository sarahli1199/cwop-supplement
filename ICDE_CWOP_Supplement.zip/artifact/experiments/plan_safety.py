"""Analytic, history-conditional single-item certificates and frozen-plan tests.

No observed serving outcomes enter a certificate. Probability allocations cover
six event families. Methods of types supplies the entropy KL remainder bound.
"""
import numpy as np
from scipy.stats import beta
from legacy_controller import Targets, Environment, entropy_rows, policy_metrics, greedy_policy
from evaluation import uniform, residuals, Oracle


def margins(env, x, requests, windows=20, delta=.05, policy_specific=True, cap=None):
    N=int(requests); U,C=env.users,env.creators
    K=env.candidate_mask.sum(1)
    families=6 if policy_specific else 5
    lc,lh,lu=np.log(families*windows*np.array([C,1,U])/delta)
    mean=N*env.request_prob
    n=np.floor(mean-np.sqrt(2*mean*lu)).astype(int)
    ns=np.maximum(n,3)
    rho=env.request_prob@x
    h=float(rho@rho)
    bounded=np.log1p((K-1)/ns)+(np.log(ns)+1)*np.sqrt(lu/(2*ns))
    if policy_specific:
        mc=np.sqrt(2*rho*(1-rho)*lc/N)+2*lc/(3*N)
        variance=max(0.,float(np.sum(rho**3)-h*h))
        mh=2*np.sqrt(2*variance*lh/N)+4*np.ptp(rho)*lh/(3*N)+(1+np.sqrt(lh))**2/N
        ent=[]; linear=[]; kl=[]
        for u in range(U):
            p=x[u,env.candidate_mask[u]]
            if np.any(p<=0):
                # Only the log-probability branch needs full support.
                linear.append(None); kl.append(None)
                ent.append(min(np.log(K[u]),bounded[u]))
                continue
            logp=np.log(p); mu=p@logp
            variance=float(p@(logp-mu)**2)
            lin=np.sqrt(2*variance*lu/ns[u])+2*np.ptp(logp)*lu/(3*ns[u])
            rem=((K[u]-1)*np.log(ns[u]+1)+lu)/ns[u]
            linear.append(lin); kl.append(rem)
            ent.append(min(np.log(K[u]),bounded[u],lin+rem))
    else:
        if cap is None: raise ValueError('target cap required')
        mc=np.full(C,np.sqrt(2*cap*lc/N)+2*lc/(3*N))
        mh=cap*np.sqrt(2*lh/N)+(1+np.sqrt(lh))**2/N
        ent=np.minimum(np.log(K),bounded);linear=kl=None
    return dict(hhi=float(mh),cap=np.asarray(mc).tolist(),entropy=np.asarray(ent).tolist(),
                lower_counts=n.tolist(),count_condition=bool(n.min()>=3),
                entropy_linear=linear,entropy_kl=kl,entropy_bounded=bounded.tolist(),
                requests=N,windows=windows,delta=delta,policy_specific=policy_specific)


def certificate(env,x,target,N,J=20,delta=.05,policy_specific=True):
    m=margins(env,x,N,J,delta,policy_specific,target.cap)
    rho=env.request_prob@x
    excess=np.r_[rho@rho+m['hhi']-target.hhi,
                 rho+np.array(m['cap'])-target.cap,
                 target.entropy+np.array(m['entropy'])-entropy_rows(x,env.candidate_mask)]
    return dict(**m,max_certified_excess=float(excess.max()),
                valid=bool(m['count_condition'] and excess.max()<=1e-10))


def witness_cost(env,target,m):
    slack=-residuals(env,uniform(env),target)
    reserve=np.r_[m['hhi'],m['cap'],m['entropy']]
    theta=float(np.max(reserve/slack))
    w0=policy_metrics(env,uniform(env),target)['welfare']
    wg=policy_metrics(env,greedy_policy(env,0),target)['welfare']
    return dict(theta=theta,score_cost_upper=float(theta*(wg-w0)),witness_score=float(w0))


def certified_mix(env,x,target,N,J=20,delta=.05):
    """Check a segment to uniform; no monotonicity claim for nonlinear certificate.

    Coarse grid locates a valid interval, then refines it. Every returned plan is
    checked again. This constructs a feasible plan, not a chance-constrained optimum.
    """
    x0=uniform(env)
    if certificate(env,x,target,N,J,delta)['valid']:
        return x,dict(theta=0.,certificate=certificate(env,x,target,N,J,delta))
    previous=0.
    for theta in np.linspace(0,1,65)[1:]:
        z=(1-theta)*x+theta*x0
        cert=certificate(env,z,target,N,J,delta)
        if cert['valid']:
            lo,hi=previous,float(theta)
            for _ in range(30):
                mid=(lo+hi)/2
                if certificate(env,(1-mid)*x+mid*x0,target,N,J,delta)['valid']: hi=mid
                else: lo=mid
            z=(1-hi)*x+hi*x0
            cert=certificate(env,z,target,N,J,delta)
            assert cert['valid']
            return z,dict(theta=hi,certificate=cert)
        previous=float(theta)
    return None,dict(theta=None,certificate=certificate(env,x0,target,N,J,delta))


def uniform_envelope(env,target,N,J=20,delta=.05):
    """Six-family policy-free envelope of the policy-dependent certificate.

    Valid for every base-feasible policy with aggregate shares <= target.cap.
    The variance of R_I in [0,kappa] is at most kappa^2/4.
    """
    C,U=env.creators,env.users
    lc,lh,lu=np.log(6*J*np.array([C,1,U])/delta)
    mean=N*env.request_prob
    n=np.floor(mean-np.sqrt(2*mean*lu)).astype(int)
    ns=np.maximum(n,3);K=env.candidate_mask.sum(1);k=target.cap
    return dict(hhi=float(k*np.sqrt(2*lh/N)+4*k*lh/(3*N)+(1+np.sqrt(lh))**2/N),
                cap=np.full(C,np.sqrt(2*k*lc/N)+2*lc/(3*N)).tolist(),
                entropy=np.minimum(np.log(K),np.log1p((K-1)/ns)+(np.log(ns)+1)*np.sqrt(lu/(2*ns))).tolist(),
                count_condition=bool(n.min()>=3),lower_counts=n.tolist())


def optimized_certificate(env,target,N,J=20,delta=.05,base=None):
    """Conic starting plan, then checked policy-specific refinement.

    Solve using previous plan's margins, and post-check resulting policy. If a
    tightened problem has no strict uniform witness, retain segment construction.
    Per-type entropy floors are used; a common max cap margin keeps this conic.
    """
    if base is None: base,_=Oracle(env,target).solve()
    best,detail=certified_mix(env,base,target,N,J,delta)
    if best is None: return None,detail
    initial_score=policy_metrics(env,best,target)['welfare']
    attempts=[]
    envelope=uniform_envelope(env,target,N,J,delta)
    budget=witness_cost(env,target,envelope)
    if envelope['count_condition'] and budget['theta']<=1:
        theta=budget['theta']
        candidate=(1-theta)*base+theta*uniform(env)
        cert=certificate(env,candidate,target,N,J,delta)
        assert cert['valid']
        if policy_metrics(env,candidate,target)['welfare']>initial_score:
            best=candidate
            detail=dict(theta=theta,certificate=cert)
    for _ in range(3):
        m=certificate(env,best,target,N,J,delta)
        tight=Targets(target.hhi-m['hhi'],target.cap-max(m['cap']),
                      target.entropy+np.array(m['entropy']))
        if residuals(env,uniform(env),tight).max()>=-1e-8: break
        try:
            candidate,_=Oracle(env,tight).solve()
        except Exception as error:
            attempts.append(dict(error=str(error)))
            break
        candidate,di=certified_mix(env,candidate,target,N,J,delta)
        attempts.append(dict(score=None if candidate is None else policy_metrics(env,candidate,target)['welfare'],
                             certified=candidate is not None))
        if candidate is not None and policy_metrics(env,candidate,target)['welfare']>policy_metrics(env,best,target)['welfare']:
            best,detail=candidate,di
        else: break
    detail['metrics']=policy_metrics(env,best,target)
    detail['witness_cost']=witness_cost(env,target,detail['certificate'])
    detail['segment_score']=initial_score
    detail['refinement_attempts']=attempts
    detail['uniform_envelope_budget']=budget
    detail['uniform_envelope_lower_bound']=(
        (1-budget['theta'])*policy_metrics(env,base,target)['welfare']+
        budget['theta']*policy_metrics(env,uniform(env),target)['welfare']
        if envelope['count_condition'] and budget['theta']<=1 else None)
    return best,detail


def scaled_margin_mix(env,x,target,N,multiplier,J=20,delta=.05):
    """Segment search with c times each final policy's own analytic margin.

    c<1 is a conservatism diagnostic, not a full probability certificate.
    Every returned point passes its scaled inequalities with a numerical cushion.
    """
    def check(z):
        m=certificate(env,z,target,N,J,delta)
        extra=np.r_[m['hhi'],m['cap'],m['entropy']]
        excess=float(np.max(residuals(env,z,target)+multiplier*extra))
        return m,excess,m['count_condition'] and excess<=-1e-10
    x0=uniform(env);lo=0.
    for hi in np.linspace(0,1,65):
        z=(1-hi)*x+hi*x0;m,excess,valid=check(z)
        if valid:
            for _ in range(35):
                mid=(lo+hi)/2
                if check((1-mid)*x+mid*x0)[2]:hi=mid
                else:lo=mid
            z=(1-hi)*x+hi*x0;m,excess,valid=check(z)
            assert valid
            if multiplier==1:assert m['valid'] and m['max_certified_excess']<0
            return z,dict(theta=float(hi),certificate=m,scaled_excess=excess)
        lo=float(hi)
    raise ValueError('No scaled-margin witness found')


def minimum_uniform_n(env,target,J=20,delta=.05,policy_specific=True):
    x0=uniform(env);lo,hi=1,20000000
    if not certificate(env,x0,target,hi,J,delta,policy_specific)['valid']: return None
    while hi-lo>1:
        mid=(lo+hi)//2
        if certificate(env,x0,target,mid,J,delta,policy_specific)['valid']:hi=mid
        else:lo=mid
    return hi


def frozen_test(env,x,target,N,repetitions=2000,seed=941,delta=.05):
    """Exact multinomial serving distribution; independent repeated fixed plans.

    Drawing types then item multinomials equals iid request/item sampling. The
    confidence interval concerns this frozen window, not adaptive trajectories.
    """
    rng=np.random.default_rng(seed)
    sizes=rng.multinomial(N,env.request_prob,size=repetitions)
    aggregate=np.zeros((repetitions,env.creators),dtype=np.int64)
    min_entropy=np.full(repetitions,np.inf)
    for u in range(env.users):
        ix=np.flatnonzero(env.candidate_mask[u]);p=x[u,ix];p=p/p.sum()
        counts=rng.multinomial(sizes[:,u],p,size=repetitions)
        aggregate[:,ix]+=counts
        rates=counts/np.maximum(sizes[:,u,None],1)
        ent=-np.sum(rates*np.log(np.maximum(rates,1e-300)),axis=1)
        floor=np.broadcast_to(target.entropy,(env.users,))[u]
        min_entropy=np.minimum(min_entropy,ent-floor)
    rho=aggregate/N
    failures=np.c_[np.sum(rho*rho,axis=1)>target.hhi+1e-6,
                   np.max(rho,axis=1)>target.cap+1e-6,min_entropy < -1e-6]
    anyfail=failures.any(1); k=int(anyfail.sum())
    # One-sided Clopper--Pearson, including exact k=0 formula.
    upper=float(beta.ppf(1-delta,k+1,repetitions-k)) if k<repetitions else 1.
    return dict(repetitions=repetitions,failures=k,rate=k/repetitions,
                one_sided_95_upper=upper,by_constraint=failures.sum(0).tolist(),
                count_zero_rate=float(np.mean(np.any(sizes==0,axis=1))),seed=seed)
