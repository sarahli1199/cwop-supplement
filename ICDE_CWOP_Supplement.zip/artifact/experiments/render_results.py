"""Generate vector plots and LaTeX numeric tables from saved experiment outputs."""
import json
import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/cwop-revision-matplotlib')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from evaluation import ROOT,RESULTS
from plot_readability import repaired_marker,residual_trace

def load(n):return json.loads((RESULTS/n).read_text())
def table(name,caption,label,columns,header,rows):
    body='\n'.join(' & '.join(r)+r' \\' for r in rows)
    text=(r'\begin{table}[t]'+'\n'+r'\centering\small'+'\n'+
          '\\caption{'+caption+'}\n\\label{'+label+'}\n'+
          '\\begin{adjustbox}{max width=\\linewidth}\n\\begin{tabular}{'+columns+'}\n\\toprule\n'+
          ' & '.join(header)+r' \\'+'\n\\midrule\n'+body+
          '\n\\bottomrule\n\\end{tabular}\n\\end{adjustbox}\n\\end{table}\n')
    (ROOT/'latex'/name).write_text(text.replace('-0.0000','0.0000').replace(r'\alpha',r'\chi'))

def main():
    s=load('summary.json'); st=load('static.json'); f=load('feedback.json'); lf=load('lastfm.json')
    labels={'feedback':'Uncontrolled feedback','temperature':'Temperature','logshare':'Log-share',
            'fairco_batch':'FairCo-style batch','fw_penalty':'Two-sided batch FW','global_pd':'Global-only PD',
            'local_pd':'Local-only PD','cwop':'PD (no safety margin)','cwop_safe':'PD + margins',
            'oracle':'Conic reference'}
    methods=['feedback','temperature','logshare','fairco_batch','fw_penalty','cwop','cwop_safe','oracle']
    def row(m,detail=False):
        r=s['feedback'][m]
        return [labels[m],f"${r['welfare']['mean']:.3f}\\pm{r['welfare']['sd']:.3f}$",
                f"${r['hhi']['mean']:.4f}$",f"${r['max_share']['mean']:.4f}$",
                f"${r['min_norm_entropy']['mean']:.3f}$",f"${100*r['window_violation_rate']['mean']:.0f}\\%$"]+(
                  [f"${r['seconds']['mean']:.2f}$"] if detail else [])
    table('table_feedback_main.tex',
          r'Repeated feedback: final pooled exposure and intrinsic utility (mean $\pm$ SD across five graphs). '
          r'Last column: fraction of individual windows exceeding any target. Caps/entropy are exposure metrics, not consumption.',
          'tab:feedback','lrrrrr',['Controller','Utility','HHI','Max share',r'Min $H/\log18$','Window viol.'],[row(m) for m in methods])
    table('table_feedback_details.tex',
          r'Full repeated-feedback results, including one-sided ablations. Runtime is seconds per complete 20-window run on the local CPU, not a compute-matched production test.',
          'tab:feedback-full','lrrrrrr',['Controller','Utility','HHI','Max share','Min entropy','Window viol.','Seconds'],
          [row(m,True) for m in list(labels)])
    base=st['instances'][0]; rows=[]
    for name,label in [('greedy','Greedy'),('softmax_0.30','Softmax 0.30'),('global_pd','Global-only PD'),
                       ('local_pd','Local-only PD'),('joint_pd','PD raw'),('joint_repaired','PD repaired')]:
        m=base['policies'][name]['metrics']
        rows.append([label,f"${m['welfare']:.6f}$",f"${m['hhi']:.6f}$",f"${m['max_share']:.6f}$",
                     f"${m['min_norm_entropy']:.4f}$",f"\\num{{{m['max_violation']:.2g}}}"])
    for label,m in [('Best feasible softmax mixture',base['best_feasible_softmax']),('Conic reference',base['oracle']['metrics'])]:
        rows.append([label,f"${m['welfare']:.6f}$",f"${m['hhi']:.6f}$",f"${m['max_share']:.6f}$",f"${m['min_norm_entropy']:.4f}$",f"\\num{{{m['max_violation']:.2g}}}"])
    table('table_static_details.tex',r'Base static instance in absolute synthetic utility units. Raw positive residuals are not exact feasibility; repaired policies are checked to tolerance $10^{-10}$.',
          'tab:cwop-benchmark','lrrrrr',['Policy','$W$','HHI','Max share','Min norm. entropy','Max residual'],rows)
    rows=[]
    for r in lf['instances']:
        rows.append([str(r['seed']),f"${r['greedy']['welfare']:.5f}$",f"${r['oracle']['metrics']['welfare']:.5f}$",
                     f"${r['repaired']['welfare']:.5f}$",f"${r['oracle']['metrics']['welfare']-r['repaired']['welfare']:.5f}$",
                     f"${r['targets']['hhi']:.5f}$",f"${r['pd']['diagnostics']['solver_seconds']:.2f}$"])
    table('table_lastfm.tex',r'Artist-listening-derived test splits. Utility is a learned preference proxy. Targets use the candidate-graph witness; times exclude SVD training and oracle solution.',
          'tab:lastfm','lrrrrrr',['Split','Greedy','Conic ref.','PD','Gap',r'HHI target','Seconds'],rows)
    sens=load('feedback_sensitivity.json')['trials']; assert len(sens)==40
    rows=[]
    for alpha in (0.,.15,.3):
        for method in ('feedback','temperature','logshare','cwop'):
            trials=[r for r in (f['trials'] if alpha==.15 else sens) if r['method']==method and r['alpha']==alpha]
            assert len(trials)==5
            rows.append([f'${alpha:.2f}$',labels[method]]+
                        [f"${np.mean([r['rows'][-1]['pooled'][k] for r in trials]):.4f}$" for k in ('welfare','hhi','max_share','min_norm_entropy')])
    table('table_sensitivity.tex',r'Feedback-strength sensitivity with weights selected only at $\alpha=0.15$. Means over the same five held-out graphs. These do not identify a production feedback exponent.',
          'tab:feedback-sensitivity','rlrrrr',[r'$\alpha$','Controller','Utility','HHI','Max share','Min norm. entropy'],rows)
    # Publication vector figures, driven solely by stored numerical output.
    plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,
                         'pdf.fonttype':42,'ps.fonttype':42})
    fig,axs=plt.subplots(1,2,figsize=(6.6,2.45),layout='constrained')
    front=base['frontier']; x=[r['entropy_floor'] for r in front]
    y=[r['metrics']['welfare'] for r in front]
    axs[0].plot(x,y,'o-',color='#247B91',label='Conic reference')
    axs[0].axhline(base['witness']['greedy_welfare'],ls='--',color='0.45',label='Unconstrained greedy')
    repaired_marker(axs[0],.65,base['policies']['joint_repaired']['metrics']['welfare'],label='Repaired PD')
    axs[0].set(xlabel='Required minimum normalized entropy',ylabel='Absolute synthetic utility',ylim=(.9,1.5))
    axs[0].legend(fontsize=7,loc='upper right')
    hist=base['policies']['joint_pd']['history']
    residual_trace(axs[1],hist)
    fig.savefig(ROOT/'generated/fig6_cwop_benchmark.pdf'); fig.savefig(ROOT/'generated/fig6_cwop_benchmark.png',dpi=170); plt.close(fig)
    fig,axs=plt.subplots(1,3,figsize=(6.6,2.45),layout='constrained')
    shown=['feedback','logshare','fw_penalty','cwop','cwop_safe']
    colors=['#777777','#0072B2','#CC79A7','#D55E00','#009E73']
    for method,color in zip(shown,colors):
        tr=[r for r in f['trials'] if r['method']==method]
        for ax,key in zip(axs,['welfare','hhi','min_norm_entropy']):
            values=np.array([[v['pooled'][key] for v in r['rows']] for r in tr])
            mean=values.mean(0);sd=values.std(0,ddof=1)
            ax.plot(np.arange(1,21),mean,color=color,label=labels[method],lw=1.3)
            ax.fill_between(np.arange(1,21),mean-sd,mean+sd,color=color,alpha=.12)
    for ax,title in zip(axs,['Intrinsic utility','Aggregate HHI','Min. exposure entropy']):
        ax.set(xlabel='Serving window',title=title);ax.tick_params(labelsize=8)
    axs[1].axhline(.055,color='black',ls=':',lw=.8);axs[1].set_yscale('log')
    axs[2].axhline(.65,color='black',ls=':',lw=.8)
    handles,legend=axs[0].get_legend_handles_labels()
    fig.legend(handles,legend,loc='outside lower center',ncol=3,fontsize=7)
    fig.savefig(ROOT/'generated/fig7_feedback.pdf');fig.savefig(ROOT/'generated/fig7_feedback.png',dpi=170);plt.close(fig)

if __name__=='__main__':main()
