"""Build a creator-exposure benchmark from the public KuaiRand-Pure release.

Download the official archive separately and verify its published MD5:
0820331067a3784d9691136f772b35a7. Only public video-to-author mappings and
pre-intervention interactions fit the proxy. Later randomized interactions are
used solely for prediction diagnostics. This is not sequential replay or OPE.
No data or fitted arrays are distributed with this script.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import numpy as np
from scipy.linalg import svd
from scipy.special import expit, logit
from scipy.stats import rankdata


def interactions(path):
    out = []
    with path.open(newline='') as f:
        for row in csv.DictReader(f):
            out.append((int(row['user_id']), int(row['video_id']),
                        int(row['is_click']), int(row['date'])))
    return np.asarray(out, dtype=np.int64)


def diagnostic(labels, predictions, baseline):
    n = len(labels)
    pos = int(labels.sum()); neg = n-pos
    auc = ((rankdata(predictions)[labels == 1].sum()-pos*(pos+1)/2)/(pos*neg)
           if pos and neg else None)
    return dict(records=n, positives=pos, auc=auc,
                brier=float(np.mean((predictions-labels)**2)) if n else None,
                baseline_brier=float(np.mean((baseline-labels)**2)) if n else None)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args(); a.output.mkdir(parents=True, exist_ok=True)
    mapping = {}
    meta = a.data/'video_features_basic_pure.csv'
    with meta.open(newline='') as f:
        for row in csv.DictReader(f):
            creator = int(row['author_id'])
            if creator >= 0:
                mapping[int(row['video_id'])] = creator
    trainfile = a.data/'log_standard_4_08_to_4_21_pure.csv'
    laterfile = a.data/'log_random_4_22_to_5_08_pure.csv'
    raw = interactions(trainfile)
    assert np.all((raw[:, 3] >= 20220408) & (raw[:, 3] <= 20220421))
    author = np.array([mapping.get(int(v), -1) for v in raw[:, 1]])
    valid = author >= 0; raw, author = raw[valid], author[valid]
    # Select creators by distinct pre-period users, independent of feedback labels.
    pairs = np.unique(np.c_[raw[:, 0], author], axis=0)
    ids, counts = np.unique(pairs[:, 1], return_counts=True)
    creators = ids[np.lexsort((ids, -counts))[:256]]
    assert len(creators) == 256
    creator_index = {int(c): i for i, c in enumerate(creators)}
    keep = np.isin(author, creators); raw, author = raw[keep], author[keep]
    users = np.unique(raw[:, 0]); user_index = {int(u): i for i, u in enumerate(users)}
    ui = np.array([user_index[int(u)] for u in raw[:, 0]])
    ci = np.array([creator_index[int(c)] for c in author])
    exposure = np.zeros((len(users), 256)); response = np.zeros_like(exposure)
    np.add.at(exposure, (ui, ci), 1); np.add.at(response, (ui, ci), raw[:, 2])
    global_rate = float(response.sum()/exposure.sum())
    creator_rate = (response.sum(0)+20*global_rate)/(exposure.sum(0)+20)
    user_rate = (response.sum(1)+20*global_rate)/(exposure.sum(1)+20)
    base = logit(user_rate)[:, None]+logit(creator_rate)[None, :]-logit(global_rate)
    prior = expit(base)
    smooth = (response+5*prior)/(exposure+5)
    residual = logit(np.clip(smooth, 1e-8, 1-1e-8))-base
    left, singular, right = svd(residual, full_matrices=False, check_finite=False)
    proxy = expit(base+(left[:, :16]*singular[:16])@right[:16])
    eligible = np.flatnonzero((exposure > 0).sum(1) >= 5)
    assert len(eligible) >= 640, len(eligible)
    chosen = np.random.default_rng(20261112).choice(eligible, 640, replace=False)
    later = interactions(laterfile)
    assert np.all((later[:, 3] >= 20220422) & (later[:, 3] <= 20220508))
    later_author = np.array([mapping.get(int(v), -1) for v in later[:, 1]])
    source = {f.name: hashlib.sha256(f.read_bytes()).hexdigest()
              for f in [meta, trainfile, laterfile]}
    report = dict(dataset='KuaiRand-Pure', source_sha256=source,
                  protocol='Pre-period rank-16 smoothed-logit response proxy; fixed creator retrieval graph.',
                  fit_users=len(users), fit_records=len(raw), creators=256,
                  eligible_users=len(eligible), group_users=128,
                  global_rate=global_rate, groups=[])
    for group, seed in enumerate([20261110, 20261111, 20261120, 20261121, 20261122]):
        selected = chosen[group*128:(group+1)*128]
        values = proxy[selected]
        mask = np.zeros_like(values, dtype=bool)
        rng = np.random.default_rng(seed)
        for u in range(128):
            best = np.argsort(-values[u], kind='stable')[:32]
            rest = np.setdiff1d(np.arange(256), best)
            mask[u, np.r_[best, rng.choice(rest, 32, replace=False)]] = True
        selected_ids = set(map(int, users[selected]))
        ix = [i for i, (row, c) in enumerate(zip(later, later_author))
              if int(row[0]) in selected_ids and int(c) in creator_index]
        rows = later[ix]; ca = later_author[ix]
        yu = np.array([user_index[int(u)] for u in rows[:, 0]])
        yc = np.array([creator_index[int(c)] for c in ca])
        diag = diagnostic(rows[:, 2], proxy[yu, yc], creator_rate[yc])
        np.savez_compressed(a.output/f'kuairand_{seed}.npz',
                            q=np.full(128, 1/128), mask=mask,
                            utility=np.where(mask, values, -np.inf),
                            public_user_ids=users[selected], public_creator_ids=creators)
        report['groups'].append(dict(seed=seed, role='train' if group<2 else 'test',
                                     heldout_random=diag))
    (a.output/'kuairand_preparation.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
