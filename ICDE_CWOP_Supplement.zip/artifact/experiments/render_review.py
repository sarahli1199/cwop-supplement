"""Render revised comparisons from saved trials; never substitute target values."""
import json
import os
from pathlib import Path
os.environ.setdefault('MPLCONFIGDIR','/tmp/cwop-review-matplotlib')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from evaluation import ROOT,RESULTS,save_json
from run_review_experiments import violation
from plot_readability import repaired_marker,residual_trace

PAPER=ROOT.parent if (ROOT.parent/'ICLR2027_CWOP.tex').exists() else ROOT
def read(name):return json.loads((RESULTS/name).read_text())
def summary(trials):
    assert len(trials)==5
    metrics={k:float(np.mean([t['rows'][-1]['pooled'][k] for t in trials]))
             for k in ('welfare','hhi','max_share','min_norm_entropy')}
    metrics['welfare_sd']=float(np.std([t['rows'][-1]['pooled']['welfare'] for t in trials],ddof=1))
    metrics['window_violations']=sum(violation(r) for t in trials for r in t['rows'])
    metrics['trajectory_violations']=sum(any(violation(r) for r in t['rows']) for t in trials)
    metrics['click_entropy']=float(np.mean([t['rows'][-1]['min_consumption_entropy'] for t in trials]))
    metrics['seconds']=float(np.mean([t['seconds'] for t in trials]))
    metrics['max_planned_violation']=max(r['planned']['max_violation'] for t in trials for r in t['rows'])
    budgets=[r['safety_cost_budget'] for t in trials for r in t['rows'] if 'safety_cost_budget' in r]
    if budgets:
        metrics['theta_range']=[min(r['theta'] for r in budgets),max(r['theta'] for r in budgets)]
        metrics['mean_score_cost_upper']=float(np.mean([r['score_cost_upper'] for r in budgets]))
        metrics['max_score_cost_upper']=max(r['score_cost_upper'] for r in budgets)
    return metrics

def table(name,caption,label,header,rows):
    columns='l'+'r'*(len(header)-1)
    text=(r'\begin{table}[t]\centering\small'+'\n'+r'\caption{'+caption+'}\n'+
          r'\label{'+label+'}\n'+r'\begin{adjustbox}{max width=\linewidth}'+'\n'+
          r'\begin{tabular}{'+columns+'}\n\\toprule\n'+ ' & '.join(header)+r' \\'+'\n\\midrule\n'+
          '\n'.join(' & '.join(row)+r' \\' for row in rows)+
          '\n\\bottomrule\n\\end{tabular}\n\\end{adjustbox}\n\\end{table}\n')
    for directory in {PAPER/'latex',ROOT/'latex'}:
        directory.mkdir(parents=True,exist_ok=True)
        (directory/name).write_text(text)

def main():
    original=read('feedback.json')['trials']; baselines=read('review_baselines.json')['trials']
    margins=read('review_margins.json')['trials']; selected=read('review_tuning.json')['selection']
    assert len(baselines)==115 and len(margins)==40
    if (RESULTS/'refined_baselines.json').exists():
        refined=read('refined_baselines.json');selected=refined['selection']
        baselines=[t for t in baselines if t['method']!='fw_penalty']+refined['test_grid']
    groups={}
    for method in ('feedback','cwop','oracle'):
        groups[method]=[t for t in original if t['method']==method]
    for method,param in selected.items():
        groups[method]=[t for t in baselines if t['method']==method and t['parameter']==param]
    for method in ('cwop_margin','oracle_margin'):
        groups[method]=[t for t in margins if t['method']==method and t['parameter']==1.]
    for method in ('cwop_certified','oracle_certified'):
        groups[method]=[t for t in margins if t['method']==method]
    labels={'feedback':'Uncontrolled','temperature':'Temperature','logshare':'Log-share',
            'fairco_batch':'FairCo-style batch','fw_penalty':'Two-sided batch FW',
            'cwop':'PD, no margin','oracle':'Conic reference, no margin',
            'cwop_margin':'PD + margins','oracle_margin':'Conic reference + margins',
            'cwop_certified':'PD, certified','oracle_certified':'Conic reference, certified'}
    summaries={m:summary(ts) for m,ts in groups.items()}
    order=['feedback','temperature','logshare','fairco_batch','fw_penalty','cwop','oracle','cwop_margin','oracle_margin']
    rows=[]
    for m in order:
        s=summaries[m]
        rows.append([labels[m],f"${s['welfare']:.3f}\\pm{s['welfare_sd']:.3f}$",f"${s['hhi']:.4f}$",
                     f"${s['max_share']:.4f}$",f"${s['min_norm_entropy']:.3f}$",f"${s['window_violations']}\\%$"])
    table('table_feedback_main.tex',r'Feedback at $N=10{,}000$ requests per window and $\chi=0.15$. Utility and pooled exposure are means over five graphs; utility has across-graph SD. Violations count individual windows. Baselines share the training window criterion; FW uses $10{,}000$ steps.',
          'tab:feedback',['Method','Utility','HHI','Max share',r'Min $H/\log18$','Window viol.'],rows)
    detailed=[]
    for m in order:
        s=summaries[m]
        detailed.append([labels[m],f"${50000 if 'certified' in m else 10000}$",
            f"${s['click_entropy']:.3f}$",f"${s['trajectory_violations']}/5$"])
    table('table_review_diagnostics.tex',r'Clicked-item entropy and trajectory failures. A trajectory fails if any of its 20 windows violates. Runtime is omitted because these runs used different contention conditions.',
          'tab:review-diagnostics',['Method','$N$','Min clicked entropy','Violating runs'],detailed)
    sweep=[]; sweep_summary=[]
    for method in ('cwop','oracle'):
        for strength in (0.,.5,1.,1.5):
            ts=groups[method] if strength==0 else [t for t in margins if t['method']==method+'_margin' and t['parameter']==strength]
            s=summary(ts);sweep_summary.append(dict(method=method,strength=strength,**s))
            sweep.append([labels[method].split(',')[0],f'${strength:.1f}$',r'$10$k',f"${s['welfare']:.3f}$",
                f"${s['window_violations']}\\%$",f"${s.get('mean_score_cost_upper',0):.3f}$"])
    table('table_review_margins.tex',r'Empirical-margin ablation at 10k requests: margins scale $(0.005,0.01,0.07\log18)$ by the stated multiplier. These settings have no analytic sampling certificate. The budget bounds the cost in the current window score (Corollary~\ref{cor:safety-cost}).',
          'tab:review-margins',['Method','Margin','$N$','Utility','Window viol.','Score budget'],sweep)
    # Audit individual constraints and windows for the held-out, frozen log-share weight.
    diagnostics={}
    for method in ('logshare','cwop','oracle'):
        by_type={k:[] for k in ('hhi','cap','entropy')}
        for t in groups[method]:
            for r in t['rows']:
                m=r['empirical']; flags={'hhi':m['hhi']-.055>1e-6,'cap':m['max_share']-.08>1e-6,
                    'entropy':(.65-m['min_norm_entropy'])*np.log(18)>1e-6}
                for k,yes in flags.items():
                    if yes:by_type[k].append([t['seed'],r['window']])
        diagnostics[method]=by_type
    # Last.fm: report both saved optimizer times; split IDs are display labels only.
    rows=[]
    for i,r in enumerate(read('lastfm.json')['instances'],1):
        rows.append([f'Split {i}',f"${r['greedy']['welfare']:.5f}$",f"${r['oracle']['metrics']['welfare']:.5f}$",
            f"${r['repaired']['welfare']:.5f}$",f"${r['oracle']['metrics']['welfare']-r['repaired']['welfare']:.5f}$",
            f"${r['pd']['diagnostics']['solver_seconds']:.2f}$",f"${r['oracle']['seconds']:.2f}$"])
    table('table_lastfm.tex',r'Last.fm-derived test splits. Utility is a learned preference proxy. Optimizer times (seconds) exclude SVD fitting; the reference time includes conic canonicalization/solve but not segment repair or certificate evaluation.',
          'tab:lastfm',['Split','Greedy','Conic ref.','PD','Gap','PD s','Conic s'],rows)
    plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
    fig,axs=plt.subplots(1,2,figsize=(6.6,2.55),layout='constrained')
    colors={'temperature':'#0072B2','logshare':'#E69F00','fairco_batch':'#777777','fw_penalty':'#CC79A7'}
    points={}
    for method,color in colors.items():
        values=[]
        for param in sorted({t['parameter'] for t in baselines if t['method']==method}):
            s=summary([t for t in baselines if t['method']==method and t['parameter']==param])
            values.append((s['window_violations'],s['welfare'],param))
        points[method]=values
        axs[0].scatter([v[0] for v in values],[v[1] for v in values],s=15,color=color,alpha=.4)
        front=[v for v in values if not any(w[0]<=v[0] and w[1]>=v[1] and (w[0]<v[0] or w[1]>v[1]) for w in values)]
        front.sort()
        axs[0].plot([v[0] for v in front],[v[1] for v in front],'o-',ms=3,color=color,label=labels[method])
    for method,color in [('cwop','#009E73'),('oracle','#D55E00')]:
        vals=[s for s in sweep_summary if s['method']==method]
        axs[0].plot([s['window_violations'] for s in vals],[s['welfare'] for s in vals],'s--',ms=3,color=color,label=labels[method].split(',')[0])
        axs[1].plot([s['strength'] for s in vals],[s['welfare'] for s in vals],'o-',color=color,label=labels[method].split(',')[0])
    axs[0].set(xlabel='Violating windows (%)',ylabel='Intrinsic utility',xlim=(-3,103))
    axs[0].legend(fontsize=6.5,loc='lower right')
    axs[1].set(xlabel='Empirical margin multiplier (10k)',ylabel='Intrinsic utility')
    axs[1].legend(fontsize=6.5,loc='best')
    for directory in {ROOT/'generated',PAPER/'generated'}:
        directory.mkdir(parents=True,exist_ok=True)
        fig.savefig(directory/'review_tradeoffs.pdf');fig.savefig(directory/'review_tradeoffs.png',dpi=170)
    plt.close(fig)
    # Same original convergence data; add a descriptive reference slope, not a fitted guarantee.
    base=read('static.json')['instances'][0];front=base['frontier'];hist=base['policies']['joint_pd']['history']
    fig,axs=plt.subplots(1,2,figsize=(6.6,2.45),layout='constrained')
    axs[0].plot([r['entropy_floor'] for r in front],[r['metrics']['welfare'] for r in front],'o-',label='Conic reference')
    axs[0].axhline(base['witness']['greedy_welfare'],ls='--',color='.5',label='Greedy')
    repaired_marker(axs[0],.65,base['policies']['joint_repaired']['metrics']['welfare'])
    axs[0].set(xlabel='Minimum normalized entropy',ylabel='Absolute synthetic utility');axs[0].legend(fontsize=7)
    residual_trace(axs[1],hist)
    for directory in {ROOT/'generated',PAPER/'generated'}:
        fig.savefig(directory/'fig6_cwop_benchmark.pdf')
        fig.savefig(directory/'fig6_cwop_benchmark.png',dpi=170)
    plt.close(fig)
    # Current held-out choices, including the complete 10000-step FW rerun.
    fig,axs=plt.subplots(1,3,figsize=(6.6,2.45),layout='constrained')
    shown=['feedback','logshare','fw_penalty','cwop','cwop_margin','oracle_margin']
    colors=['#777777','#0072B2','#CC79A7','#D55E00','#009E73','#E69F00']
    for method,color in zip(shown,colors):
        for ax,key in zip(axs,['welfare','hhi','min_norm_entropy']):
            values=np.array([[r['pooled'][key] for r in t['rows']] for t in groups[method]])
            mean=values.mean(0);sd=values.std(0,ddof=1)
            ax.plot(np.arange(1,21),mean,color=color,label=labels[method],lw=1.3)
            ax.fill_between(np.arange(1,21),mean-sd,mean+sd,color=color,alpha=.12)
    for ax,title in zip(axs,['Intrinsic utility','Aggregate HHI','Min. exposure entropy']):
        ax.set(xlabel='Serving window',title=title);ax.tick_params(labelsize=8)
    axs[1].axhline(.055,color='black',ls=':',lw=.8);axs[1].set_yscale('log')
    axs[2].axhline(.65,color='black',ls=':',lw=.8)
    handles,legend=axs[0].get_legend_handles_labels()
    fig.legend(handles,legend,loc='outside lower center',ncol=3,fontsize=6.5)
    for directory in {ROOT/'generated',PAPER/'generated'}:
        fig.savefig(directory/'fig7_feedback.pdf');fig.savefig(directory/'fig7_feedback.png',dpi=170)
    plt.close(fig)
    out=dict(selected=selected,methods=summaries,margin_sweep=sweep_summary,baseline_grid=points,
             constraint_diagnostics=diagnostics,zero_in_five_trajectory_upper95=1-.05**(1/5))
    path=RESULTS/'review_same_state.json'
    if path.exists():
        tr=read('review_same_state.json')['trials']
        if len(tr)==5:
            gaps=[r['same_state_oracle_gap'] for t in tr for r in t['rows']]
            out['same_state_gap']=dict(mean=float(np.mean(gaps)),maximum=float(max(gaps)),minimum=float(min(gaps)))
    save_json(RESULTS/'review_summary.json',out)
    print(json.dumps({k:v for k,v in out.items() if k not in ('constraint_diagnostics','baseline_grid','margin_sweep')},indent=2))
    print('Log-share counts:',{k:len(v) for k,v in diagnostics['logshare'].items()})

if __name__=='__main__':main()
