"""Render the additional FairCo and frozen-history diagnostics from local outputs."""
from pathlib import Path
import argparse
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def summarize(results, diagnostics):
    hybrid = json.loads((diagnostics/'hybrid.json').read_text())['rows']
    frozen = []
    for path in sorted(diagnostics.glob('frozen_*.json')):
        data = json.loads(path.read_text())
        if data.get('phase') == 'frozen':
            frozen.extend(data['rows'])
    assert len(hybrid) == 8 and len(frozen) == 45
    assert len({(r['seed'],r['window'],r['factor'],r['entropy_fraction']) for r in frozen}) == 45
    out = {'matched': {}, 'sweep': []}
    for dataset in ['synthetic', 'lastfm']:
        old = json.loads((results/f'unified_feedback_{dataset}.json').read_text())
        denom = np.mean([t['rows'][-1]['pooled']['welfare'] for t in old['test'] if t['method']=='conic'])
        summary = {}
        for method in ['temperature', 'logshare', 'fairco_batch', 'fw_penalty', 'conic', 'certified']:
            ts = [t for t in old['test'] if t['method']==method]
            us = np.array([t['rows'][-1]['pooled']['welfare'] for t in ts])/denom
            rows = [row for t in ts for row in t['rows']]
            summary[method] = dict(utility=float(us.mean()), sd=float(us.std(ddof=1)),
                failures=sum(row['empirical']['max_violation']>1e-6 for row in rows), windows=len(rows))
        ts = [t for t in hybrid if t['dataset']==dataset]
        us = np.array([t['pooled']['welfare'] for t in ts])/denom
        rows = [row for t in ts for row in t['rows']]
        summary['fairco_certified'] = dict(utility=float(us.mean()), sd=float(us.std(ddof=1)),
            failures=sum(row['empirical']['max_violation']>1e-6 for row in rows), windows=len(rows))
        out['matched'][dataset] = summary
    for a,b in [(1.5,.65),(1.5,.50),(2.,.65),(2.,.50),(2.5,.35)]:
        rows = [r for r in frozen if r['factor']==a and r['entropy_fraction']==b]
        assert len(rows)==9 and all(r['certificate']['valid'] for r in rows)
        item = {'factor':a, 'entropy_fraction':b}
        for key in ['target_cost_fraction','certification_cost_fraction','certified_score_ratio','intrinsic_utility_ratio']:
            per_split = [np.mean([r[key] for r in rows if r['seed']==s]) for s in [20260920,20260921,20260922]]
            item[key] = float(np.mean(per_split));item[key+'_sd'] = float(np.std(per_split,ddof=1))
        item['resampled_failures'] = sum(r['frozen_test']['failures'] for r in rows)
        item['resampled_windows'] = sum(r['frozen_test']['repetitions'] for r in rows)
        out['sweep'].append(item)
    out['largest_relative_conic_gap'] = max(r['optimization']['certified_gap']/r['greedy_score'] for r in frozen)
    return out


def render(summary, output):
    output.mkdir(parents=True, exist_ok=True)
    (output/'fairco_tradeoff_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    table = [r'\begin{table}[t]\centering\small',
        r'\caption{Last.fm target sweep on identical histories (three splits; windows 1, 10, 20). Ceilings are $a$ times uniform-witness HHI/share; entropy is $b\log64$. Cost columns are percentages of the same-history greedy score $W_g$. Response utility is relative to intrinsic greedy utility; $\pm$ is SD across split means.}',
        r'\label{tab:target-tradeoff}',r'\begin{adjustbox}{max width=\linewidth}',
        r'\begin{tabular}{lrrr}',r'\toprule',
        r'$(a,b)$ & Target cost & Cert. cost & Response utility \\',r'\midrule']
    for row in summary['sweep']:
        table.append(f"$({row['factor']:.1f},{row['entropy_fraction']:.2f})$ & "
            f"${100*row['target_cost_fraction']:.1f}\\%$ & ${100*row['certification_cost_fraction']:.1f}\\%$ & "
            f"${row['intrinsic_utility_ratio']:.3f}\\pm{row['intrinsic_utility_ratio_sd']:.3f}$ \\\\")
    table += [r'\bottomrule',r'\end{tabular}',r'\end{adjustbox}',r'\end{table}']
    (output/'table_target_tradeoff.tex').write_text('\n'.join(table)+'\n')
    names={'temperature':'Temperature','logshare':'Log-share','fairco_batch':'FairCo-style batch',
           'fw_penalty':'Two-sided batch FW','conic':'Conic reference, no margin',
           'certified':'Certified CWOP (conic)','fairco_certified':'FairCo + certificate'}
    order=list(names)
    plt.rcParams.update({'font.size':8,'axes.titlesize':8,'axes.labelsize':8,
        'xtick.labelsize':7,'ytick.labelsize':7,'axes.spines.top':False,
        'axes.spines.right':False,'pdf.fonttype':42})
    fig,axs=plt.subplots(1,2,figsize=(5.2,2.05),layout='constrained')
    for ax,dataset in zip(axs,['synthetic','lastfm']):
        for method,color,marker in zip(order,['#0072B2','#E69F00','#777777','#CC79A7','#D55E00','#009E73','#332288'],['o','v','s','D','x','*','P']):
            row=summary['matched'][dataset][method]
            ax.scatter(100*row['failures']/row['windows'],row['utility'],color=color,
                       marker=marker,s=55 if method=='certified' else 25,label=names[method],zorder=3)
        ax.set(xlabel='Violating windows (%)',ylabel='Utility / conic\nreference',xlim=(-5,105),
               title='Synthetic, N = 20k' if dataset=='synthetic' else 'Last.fm, N = 100k')
    handles,labels=axs[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='outside lower center',ncol=3,fontsize=6.7)
    fig.savefig(output/'review_tradeoffs.pdf',metadata={'Creator':'Scientific plotting','CreationDate':None,'ModDate':None})
    fig.savefig(output/'review_tradeoffs.png',dpi=160)
    plt.close(fig)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results',type=Path,required=True)
    parser.add_argument('--diagnostics',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    summary=summarize(args.results,args.diagnostics)
    render(summary,args.output)
    print(json.dumps(summary,indent=2))


if __name__=='__main__':
    main()
