"""Optimizer tuning on one disjoint split; all probe results are retained."""
from run_lastfm import load_matrix,build
from compact_controller import solve
from evaluation import RESULTS,repair,save_json,witness_certificate
from legacy_controller import policy_metrics

matrix,selected,_,_=load_matrix()
env,target,meta=build(20260919,matrix,selected)
rows=[]
for primal in (.25,.75,2.25,6.75):
    for dual in (5.,20.,80.,240.):
        x,_,diag=solve(env,target,5000,primal_rate=primal,dual_rate=dual,dual_bound=300)
        xr,theta=repair(env,x,target)
        rows.append(dict(primal_rate=primal,dual_rate=dual,
                         raw=policy_metrics(env,x,target),repaired=policy_metrics(env,xr,target),theta=theta,diagnostics=diag))
        print(primal,dual,rows[-1]['repaired']['welfare'],flush=True)
best=max(rows,key=lambda r:r['repaired']['welfare'])
save_json(RESULTS/'lastfm_tuning.json',dict(seed=20260919,iterations=5000,probes=rows,
              selected=dict(primal_rate=best['primal_rate'],dual_rate=best['dual_rate'])))
