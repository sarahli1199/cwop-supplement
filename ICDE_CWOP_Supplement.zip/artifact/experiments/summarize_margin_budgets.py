"""Summarize certificate reserves from locally generated matched experiments.

No data are bundled. Supply a results directory after running the experiments.
The script checks each stored margin independently against the theorem formulas.
"""
from pathlib import Path
import argparse
import hashlib
import json
import numpy as np


def independent_margins(q, mask, x, n_requests, windows=20, delta=.05):
    users, creators = mask.shape
    k = mask.sum(axis=1)
    lc, lh, lu = np.log(6*windows*np.array([creators, 1, users])/delta)
    counts = np.floor(n_requests*q-np.sqrt(2*n_requests*q*lu)).astype(int)
    assert counts.min() >= 3
    r = q @ x
    hhi = np.dot(r, r)
    variance = np.dot(r, (r-hhi)**2)
    cap = np.sqrt(2*r*(1-r)*lc/n_requests)+2*lc/(3*n_requests)
    hmargin = (2*np.sqrt(2*variance*lh/n_requests)
               +4*(r.max()-r.min())*lh/(3*n_requests)
               +(1+np.sqrt(lh))**2/n_requests)
    entropy = []
    for i in range(users):
        p = x[i, mask[i]]
        n = counts[i]
        bounded = np.log1p((k[i]-1)/n)+(np.log(n)+1)*np.sqrt(lu/(2*n))
        if np.any(p <= 0):
            specific = np.inf
        else:
            logs = np.log(p)
            variance_log = np.dot(p, (logs-np.dot(p, logs))**2)
            specific = (np.sqrt(2*variance_log*lu/n)
                        +2*(logs.max()-logs.min())*lu/(3*n)
                        +((k[i]-1)*np.log(n+1)+lu)/n)
        entropy.append(min(np.log(k[i]), bounded, specific))
    return float(hmargin), cap, np.array(entropy), counts


def summarize(results):
    report = {'normalization': 'Each final-plan margin divided by the corresponding strict uniform-over-candidates witness slack; maximum over coordinates and windows.',
              'datasets': {}, 'input_sha256': {}}
    def record(p):
        report['input_sha256'][p.name] = hashlib.sha256(p.read_bytes()).hexdigest()
    for dataset in ['synthetic', 'lastfm']:
        path = results/f'unified_feedback_{dataset}.json'
        record(path)
        data = json.loads(path.read_text())
        budgets = []; targets = []; minima = []; plans_checked = 0
        for trial in data['test']:
            if trial['method'] != 'certified':
                continue
            plan_path = results/trial['plans']; record(plan_path)
            with np.load(plan_path, allow_pickle=False) as a:
                q, mask, plans = a['q'], a['mask'], a['plans']
            k = mask.sum(axis=1); uniform = mask/k[:, None]; r0 = q @ uniform
            target = trial['targets']
            sh = target['hhi']-np.dot(r0, r0)
            sc = target['cap']-r0
            su = np.log(k)-target['entropy']
            assert sh > 0 and np.min(sc) > 0 and np.min(su) > 0
            assert len(plans) == len(trial['rows']) == 20
            for x, row in zip(plans, trial['rows']):
                mh, mc, mu, counts = independent_margins(q, mask, x, trial['N'])
                stored = row['safety']['certificate']
                for actual, expected in [(mh, stored['hhi']), (mc, stored['cap']), (mu, stored['entropy'])]:
                    np.testing.assert_allclose(actual, expected, rtol=1e-10, atol=1e-12)
                assert stored['valid']
                budgets.append([mh/sh, np.max(mc/sc), np.max(mu/su)])
                targets.append([mh/target['hhi'], np.max(mc)/target['cap'], np.max(mu)/target['entropy']])
                plans_checked += 1
            minimum_n = trial['minimum_uniform_n']
            for n, expected in [(minimum_n, True), (minimum_n-1, False)]:
                h, c, e, _ = independent_margins(q, mask, uniform, n)
                valid = bool(h <= sh and np.all(c <= sc) and np.all(e <= su))
                assert valid == expected, 'Stored witness threshold disagrees with theorem formulas'
            minima.append(minimum_n/trial['N'])
            if dataset == 'lastfm' and trial['seed'] == 20260920:
                h, c, e, counts = independent_margins(q, mask, uniform, 5000)
                lu = np.log(6*20*len(q)/.05)
                kl_remainder = ((k-1)*np.log(counts+1)+lu)/counts
                bounded = np.log1p((k-1)/counts)+(np.log(counts)+1)*np.sqrt(lu/(2*counts))
                assert np.all(kl_remainder >= np.log(k)) and np.all(bounded >= np.log(k))
                report['short_window_lastfm'] = {
                    'requests': 5000, 'relative_window_size': .05, 'users': len(q),
                    'creators': mask.shape[1], 'candidates_per_type': int(k[0]),
                    'type_count_lower_bound': int(counts.min()),
                    'max_entropy_margin_over_witness_slack': float(np.max(e/su)),
                    'entropy_margin_equals_max_entropy': bool(np.allclose(e, np.log(k))),
                    'witness_certified': bool(h <= sh and np.all(c <= sc) and np.all(e <= su))}
        report['datasets'][dataset] = {
            'certified_plans_checked': plans_checked,
            'minimum_margin_over_witness_slack': np.min(budgets, axis=0).tolist(),
            'maximum_margin_over_witness_slack': np.max(budgets, axis=0).tolist(),
            'maximum_margin_over_target': np.max(targets, axis=0).tolist(),
            'minimum_witness_window_size_ratio_range': [min(minima), max(minima)]}
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if not all((args.results/f'unified_feedback_{d}.json').exists() for d in ['synthetic', 'lastfm']):
        parser.error('Run the matched synthetic and Last.fm experiments first; result files are not bundled.')
    report = summarize(args.results)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'input_sha256'}, indent=2))


if __name__ == '__main__':
    main()
