"""Reproduce paired utility comparisons from the locally generated matched test trajectories."""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import statistics

ROOT = Path(__file__).resolve().parents[1]
BASELINES = ('temperature', 'logshare', 'fairco_batch', 'fw_penalty')
NAMES = {'temperature': 'Temperature', 'logshare': 'Log-share',
         'fairco_batch': 'FairCo-style batch', 'fw_penalty': 'Two-sided batch FW',
         'conic': 'Conic reference, no margin', 'certified': 'Certified CWOP (conic)'}

def compute(recomputed=False):
    manifest_path = ROOT/'INPUT_SHA256.json'
    manifest = json.loads(manifest_path.read_text()) if manifest_path.exists() else {}
    if not recomputed and not manifest:
        raise SystemExit('No saved data are bundled. Run the experiments first, then use --recomputed.')
    report = {'status': 'PASS', 'locally_recomputed_inputs': recomputed, 'scope': 'Paired held-out graph/split comparisons under the matched protocol; observed outcomes, without treating windows as independent replicates.',
              'violation_tolerance': 1e-6, 'input_sha256': {}, 'datasets': {}}
    records = []
    for dataset, expected_n, window_size in [('synthetic', 5, 20000), ('lastfm', 3, 100000)]:
        filename = 'results/unified_feedback_' + dataset + '.json'
        data_bytes = (ROOT/filename).read_bytes()
        digest = hashlib.sha256(data_bytes).hexdigest()
        if not recomputed:
            assert digest == manifest[filename], filename
        report['input_sha256'][filename] = digest
        data = json.loads(data_bytes)
        groups = {m: {} for m in (*BASELINES, 'conic', 'certified')}
        for trial in data['test']:
            m, seed = trial['method'], trial['seed']
            assert seed not in groups[m]
            assert trial['N'] == window_size and len(trial['rows']) == 20
            groups[m][seed] = trial
        seeds = set(groups['certified'])
        assert len(seeds) == expected_n and all(set(g) == seeds for g in groups.values())
        assert not seeds & {t['seed'] for t in data['training']}
        utility = lambda t: t['rows'][-1]['pooled']['welfare']
        violations = lambda t: sum(r['empirical']['max_violation'] > 1e-6 for r in t['rows'])
        means = {m: statistics.mean(utility(t) for t in g.values()) for m, g in groups.items()}
        failures = {m: sum(violations(t) for t in g.values()) for m, g in groups.items()}
        qualifying = [m for m in BASELINES if failures[m] == 0]
        best = max(qualifying, key=means.get)
        assert best == 'fw_penalty'
        qualifying_five_percent = [m for m in BASELINES if failures[m]/(expected_n*20) <= .05]
        best_five_percent = max(qualifying_five_percent, key=means.get)
        assert best_five_percent == best
        assert failures['certified'] == 0
        assert means['certified'] > max(means[m] for m in qualifying)
        pairs = {}
        for method in BASELINES:
            gains = []
            for seed in sorted(seeds):
                c, b = groups['certified'][seed], groups[method][seed]
                assert c['targets'] == b['targets']
                uc, ub = utility(c), utility(b)
                assert ub > 0
                gain = 100*(uc/ub-1)
                gains.append(gain)
                records.append({'dataset': dataset, 'seed': seed, 'baseline': method,
                                'cwop_utility': uc, 'baseline_utility': ub,
                                'utility_gain_percent': gain,
                                'cwop_violating_windows': violations(c),
                                'baseline_violating_windows': violations(b),
                                'windows_per_run': 20, 'requests_per_window': window_size})
            pairs[method] = {'ratio_of_means_gain_percent': 100*(means['certified']/means[method]-1),
                             'per_instance_gain_percent': gains,
                             'minimum_gain_percent': min(gains), 'maximum_gain_percent': max(gains),
                             'strict_utility_wins': sum(g > 0 for g in gains),
                             'baseline_violating_windows': failures[method]}
        assert pairs[best]['strict_utility_wins'] == expected_n
        report['datasets'][dataset] = {'instances': expected_n, 'requests_per_window': window_size,
                                      'zero_violation_baselines': qualifying,
                                      'strongest_zero_violation_baseline': best,
                                      'baselines_with_at_most_five_percent_window_failures': qualifying_five_percent,
                                      'strongest_baseline_at_five_percent_ceiling': best_five_percent,
                                      'normalized_mean_utility': {m: u/means['conic'] for m, u in means.items()},
                                      'violating_windows': failures, 'paired_comparisons': pairs}
    return report, records

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--recomputed', action='store_true', help='Compare locally rerun results without claiming original-file identity.')
    args = parser.parse_args()
    for dataset in ('synthetic', 'lastfm'):
        if not (ROOT/('results/unified_feedback_'+dataset+'.json')).exists():
            parser.error('No result data are bundled. Run the matched experiments first; see README.txt.')
    report, records = compute(args.recomputed)
    for name in ('verification', 'latex'):
        (ROOT/name).mkdir(exist_ok=True)
    (ROOT/'verification/matched_comparison.json').write_text(json.dumps(report, indent=2)+'\n')
    with (ROOT/'verification/matched_comparison_pairs.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(records[0]))
        writer.writeheader(); writer.writerows(records)
    macros = []
    rows = []
    for dataset, label, key in [('synthetic', 'Synthetic', 'Synthetic'), ('lastfm', 'Last.fm', 'Lastfm')]:
        d = report['datasets'][dataset]; p = d['paired_comparisons'][d['strongest_zero_violation_baseline']]
        for suffix, value in [('Gain', p['ratio_of_means_gain_percent']), ('MinGain', p['minimum_gain_percent']), ('MaxGain', p['maximum_gain_percent'])]:
            macros.append(r'\newcommand{\Matched'+key+suffix+'}{'+f'{value:.1f}'+r'\%}')
        rows.append(label+' & $'+f"{p['ratio_of_means_gain_percent']:.1f}"+r'\%$ & $'+f"{p['minimum_gain_percent']:.1f}"+r'\%$--$'+f"{p['maximum_gain_percent']:.1f}"+r'\%$ & $'+f"{p['strict_utility_wins']}/{d['instances']}"+r'$ \\')
    (ROOT/'latex/comparison_numbers.tex').write_text('\n'.join(macros)+'\n')
    table = r'''\begin{table}[t]\centering\small
\caption{Paired utility comparison against two-sided batch FW, the highest-utility selected baseline with zero observed window violations on each dataset. Mean gain is $100(\bar U_{\rm CWOP}/\bar U_{\rm FW}-1)$; the range uses each graph/split's own utility ratio. Wins count instances with strictly greater CWOP utility. Both methods have zero observed violations under this matched protocol.}
\label{tab:paired-comparison}
\begin{adjustbox}{max width=\linewidth}
\begin{tabular}{lrrr}
\toprule
Data & Mean gain & Per-instance range & Wins \\
\midrule
'''+ '\n'.join(rows)+r'''
\bottomrule
\end{tabular}
\end{adjustbox}
\end{table}
'''
    (ROOT/'latex/table_paired_comparison.tex').write_text(table)
    print(json.dumps({d: {'instances': v['instances'], **v['paired_comparisons']['fw_penalty']} for d,v in report['datasets'].items()},indent=2))

if __name__ == '__main__':
    main()
