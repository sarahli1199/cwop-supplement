"""Readability changes must preserve every displayed data coordinate."""
import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/cwop-figure-tests')
import json
import unittest
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from evaluation import RESULTS
from plot_readability import repaired_marker,residual_trace

class PlotTests(unittest.TestCase):
    def setUp(self):
        self.base=json.loads((RESULTS/'static.json').read_text())['instances'][0]
        self.fig,self.ax=plt.subplots()
    def tearDown(self):
        plt.close(self.fig)
    def test_cross_has_original_coordinate_and_high_zorder(self):
        y=self.base['policies']['joint_repaired']['metrics']['welfare']
        dot,=self.ax.plot([.65],[1.0758375908430537],'o-')
        cross=repaired_marker(self.ax,.65,y)
        np.testing.assert_array_equal(cross.get_offsets(),[[.65,y]])
        self.assertGreater(cross.get_zorder(),dot.get_zorder())
        self.assertGreaterEqual(cross.get_sizes()[0],100)
    def test_residuals_not_floored_or_smoothed(self):
        hist=self.base['policies']['joint_pd']['history']
        line=residual_trace(self.ax,hist)
        np.testing.assert_array_equal(line.get_ydata(),[r['max_violation'] for r in hist])
        np.testing.assert_array_equal(line.get_xdata(),[r['iteration'] for r in hist])
        self.assertEqual(line.get_ydata()[2],0)
        self.assertEqual(line.get_xdata()[2],600)
        self.assertEqual(self.ax.get_yscale(),'symlog')

if __name__=='__main__':
    unittest.main()
