"""Additional analytic and sampling evidence; retains previous result files."""
import argparse
import json
import numpy as np
from scipy.special import expit
from legacy_controller import Environment,Targets,make_environment,policy_metrics,entropy_rows
from evaluation import RESULTS,save_json,uniform,Oracle,residuals
from plan_safety import (margins,certificate,minimum_uniform_n,optimized_certificate,
                         certified_mix,witness_cost,frozen_test,scaled_margin_mix)

BASE=Targets(.055,.08,.65*np.log(18))

def lastfm(seed=20260920):
    a=np.load(RESULTS/f'lastfm_{seed}.npz')
    env=Environment(a['request_prob'],a['candidate_mask'],a['utility'])
    m=policy_metrics(env,uniform(env),BASE)
    return env,Targets(1.5*m['hhi'],1.5*m['max_share'],.65*np.log(64))

def scale():
    from evaluation import run_pd,repair
    import time
    env=make_environment(20260925,users=512,creators=1024,candidates=64,groups=32,head_count=8)
    rho=env.request_prob@uniform(env)
    target=Targets(1.5*(rho@rho),1.5*rho.max(),.65*np.log(64))
    begin=time.perf_counter();xo,od=Oracle(env,target).solve();conic_seconds=time.perf_counter()-begin
    begin=time.perf_counter();xp,pd=run_pd(env,target,10000);xr,theta=repair(env,xp,target);pd_seconds=time.perf_counter()-begin
    save_json(RESULTS/'refined_scale.json',dict(users=env.users,creators=env.creators,edges=int(env.candidate_mask.sum()),
        iterations=10000,seed=20260925,conic=od,pd=pd,repaired=policy_metrics(env,xr,target),repair_theta=theta,
        conic_end_to_end_seconds=conic_seconds,pd_end_to_end_seconds=pd_seconds,
        minimum_uniform_n=minimum_uniform_n(env,target)))

def curves():
    result={}
    for name,(env,target) in {'synthetic':(make_environment(),BASE),'lastfm':lastfm()}.items():
        x,details=Oracle(env,target).solve();w=details['metrics']['welfare']
        minimum=minimum_uniform_n(env,target)
        base_minimum=minimum_uniform_n(env,target,policy_specific=False)
        rows=[]
        for N in sorted(set([10000,12338,20000,50000,100000,200000,minimum,base_minimum])):
            m=margins(env,uniform(env),N,policy_specific=False,cap=target.cap)
            budget=witness_cost(env,target,m)
            common_floor=target.entropy+max(m['entropy'])
            mt=Targets(target.hhi-m['hhi'],target.cap-max(m['cap']),common_floor)
            common_score=None; failures=[]
            if residuals(env,uniform(env),mt).max()<-1e-8:
                try:
                    _,di=Oracle(env,mt).solve();common_score=di['metrics']['welfare']
                except Exception as error: failures.append('common: '+str(error))
            pt=Targets(mt.hhi,mt.cap,target.entropy+np.array(m['entropy']))
            typed_score=None
            if residuals(env,uniform(env),pt).max()<-1e-8:
                try:
                    _,di=Oracle(env,pt).solve();typed_score=di['metrics']['welfare']
                except Exception as error: failures.append('per-type: '+str(error))
            safe,di=optimized_certificate(env,target,N)
            row=dict(N=N,uniform_budget=budget,common_score=common_score,per_type_score=typed_score,
                     policy_specific_score=None if safe is None else di['metrics']['welfare'],
                     policy_specific=di,unrestricted_target_score=w,solver_failures=failures)
            rows.append(row)
            result[name]=dict(minimum_uniform_n=minimum,distribution_free_minimum_n=base_minimum,
                              witness_score=policy_metrics(env,uniform(env),target)['welfare'],
                              conic_score=w,rows=rows)
            save_json(RESULTS/'refined_curves.json',result)
            print('curve',name,N,row['policy_specific_score'],flush=True)

def baselines():
    from run_feedback import trial
    old=json.loads((RESULTS/'review_tuning.json').read_text())
    dest=RESULTS/'refined_baselines.json'
    out=json.loads(dest.read_text()) if dest.exists() else dict(training=[],test=[])
    for seed in (20260901,20260902):
        for p in (.1,.3,1.,3.,10.):
            if any(t['seed']==seed and t['parameter']==p for t in out['training']):continue
            t=trial(seed,'fw_penalty',p,20,10000,10000,fw_iterations=10000)
            out['training'].append(t);save_json(dest,out);print('fw training',seed,p,flush=True)
    training=[t for t in old['trials'] if t['method']!='fw_penalty']+out['training']
    options=[];selected={}
    for method in ('temperature','logshare','fairco_batch','fw_penalty'):
        choices=[]
        for p in sorted(set(t['parameter'] for t in training if t['method']==method)):
            ts=[t for t in training if t['method']==method and t['parameter']==p]
            metrics=[r['empirical'] for t in ts for r in t['rows']]
            rate=float(np.mean([m['max_violation']>1e-6 for m in metrics]))
            excess=float(np.mean([max(0,m['hhi']/.055-1,m['max_share']/.08-1,
                                           (.65-m['min_norm_entropy'])/.65) for m in metrics]))
            utility=float(np.mean([t['rows'][-1]['pooled']['welfare'] for t in ts]))
            choices.append(dict(method=method,parameter=p,rate=rate,normalized_excess=excess,utility=utility))
        feasible=[c for c in choices if c['rate']<=.05]
        best=max(feasible,key=lambda c:c['utility']) if feasible else min(choices,key=lambda c:(c['rate'],c['normalized_excess'],-c['utility']))
        selected[method]=best['parameter'];options+=choices
    out.update(selection=selected,options=options,rule='Training <=5% window violation, then utility; fallback window rate, normalized excess, utility. FW 10000 iterations.')
    oldtest=json.loads((RESULTS/'review_baselines.json').read_text())['trials']
    for seed in range(20260910,20260915):
        for method,p in selected.items():
            if any(t['seed']==seed and t['method']==method for t in out['test']):continue
            if method=='fw_penalty': t=trial(seed,method,p,20,10000,10000,fw_iterations=10000)
            else:t=next(t for t in oldtest if t['seed']==seed and t['method']==method and t['parameter']==p)
            out['test'].append(t);save_json(dest,out);print('test',seed,method,p,flush=True)
    out.setdefault('test_grid',[])
    for seed in range(20260910,20260915):
        for p in (.1,.3,1.,3.,10.):
            if any(t['seed']==seed and t['parameter']==p for t in out['test_grid']):continue
            t=next((t for t in out['test'] if t['seed']==seed and t['method']=='fw_penalty' and t['parameter']==p),None)
            if t is None:t=trial(seed,'fw_penalty',p,20,10000,10000,fw_iterations=10000)
            out['test_grid'].append(t);save_json(dest,out);print('fw grid',seed,p,flush=True)

def feedback(dataset,repetitions=2000):
    dest=RESULTS/f'refined_feedback_{dataset}.json'
    out=json.loads(dest.read_text()) if dest.exists() else dict(trials=[],calibration=[])
    seeds=range(20260910,20260915) if dataset=='synthetic' else range(20260920,20260923)
    # More types in Last.fm require a larger window, fixed before test trajectories.
    N=20000 if dataset=='synthetic' else 100000; J=20
    for seed in seeds:
        source,target=(make_environment(seed),BASE) if dataset=='synthetic' else lastfm(seed)
        mask=source.candidate_mask
        if dataset=='synthetic':p=np.where(mask,expit(2*np.where(mask,source.utility,0)-.8),0)
        else:
            p=np.where(mask,np.clip(source.utility,0,1),0)
        intrinsic=Environment(source.request_prob,mask,np.where(mask,p,-np.inf))
        for method in ('conic','conic_certified'):
            if any(t['seed']==seed and t['method']==method for t in out['trials']):continue
            f=np.ones(source.creators);affinity=mask.astype(float);exposure=np.zeros_like(p)
            rows=[];saved=[]; ref=Oracle(intrinsic,target)
            for j in range(J):
                score=p+.15*np.log(f/f.mean())+.1*np.log(np.maximum(affinity/(affinity.sum(1)/mask.sum(1))[:,None],1e-300))
                score=np.where(mask,score,-np.inf);env=Environment(source.request_prob,mask,score)
                x,di=ref.solve(score)
                if method=='conic_certified':
                    x,safe=certified_mix(env,x,target,N,J)
                    if x is None: raise RuntimeError(f'no certified plan for {dataset} {seed} N={N}')
                else:safe=None
                saved.append(x.copy())
                rng=np.random.default_rng(np.random.SeedSequence([seed,j,92203]))
                sizes=rng.multinomial(N,env.request_prob);counts=np.zeros_like(x);hits=np.zeros_like(x)
                for u in range(env.users):
                    ix=np.flatnonzero(mask[u]);counts[u,ix]=rng.multinomial(sizes[u],x[u,ix]/x[u,ix].sum())
                    hits[u,ix]=rng.binomial(counts[u,ix].astype(int),p[u,ix])
                f+=hits.sum(0);affinity+=hits;exposure+=counts
                em=policy_metrics(Environment(sizes/N,mask,intrinsic.utility),counts/sizes[:,None],target)
                total=exposure.sum(1)
                pm=policy_metrics(Environment(total/total.sum(),mask,intrinsic.utility),exposure/total[:,None],target)
                rows.append(dict(window=j+1,planned=policy_metrics(intrinsic,x,target),empirical=em,pooled=pm,
                                 safety=safe,score=policy_metrics(env,x,target)['welfare']))
            path=RESULTS/f'refined_plans_{dataset}_{seed}_{method}.npz'
            np.savez_compressed(path,q=intrinsic.request_prob,mask=mask,utility=intrinsic.utility,plans=np.array(saved))
            out['trials'].append(dict(seed=seed,method=method,N=N,rows=rows,plans=path.name,
                                      minimum_uniform_n=minimum_uniform_n(intrinsic,target),
                                      clipped_proxy_entries=int(np.sum(mask & ((source.utility<0)|(source.utility>1))))))
            save_json(dest,out);print('feedback',dataset,seed,method,flush=True)
    # First environment, every visited window; independence conditional on saved plan.
    first=seeds.start
    source,target=(make_environment(first),BASE) if dataset=='synthetic' else lastfm(first)
    for method in ('conic','conic_certified'):
        data=np.load(RESULTS/f'refined_plans_{dataset}_{first}_{method}.npz')
        for j,x in enumerate(data['plans']):
            if any(t['method']==method and t['window']==j+1 for t in out['calibration']):continue
            test=frozen_test(source,x,target,N,repetitions,seed=945000+j+(100 if method=='conic_certified' else 0))
            out['calibration'].append(dict(method=method,window=j+1,**test));save_json(dest,out)
    # Final-policy-dependent margins: the c=1 endpoint passes the full certificate.
    cfile=RESULTS/f'refined_calibration_checked_{dataset}.json'
    if not cfile.exists():
        data=np.load(RESULTS/f'refined_plans_{dataset}_{first}_conic.npz')
        intrinsic=Environment(data['q'],data['mask'],data['utility'])
        curve=[];failures=[]
        for c in np.linspace(0,1,11):
            x,di=scaled_margin_mix(intrinsic,data['plans'][0],target,N,float(c))
            curve.append(dict(multiplier=float(c),utility=policy_metrics(intrinsic,x,target)['welfare'],
                              **di,
                              **frozen_test(intrinsic,x,target,N,repetitions,seed=884000+int(c*10))))
        save_json(cfile,dict(N=N,repetitions=repetitions,rows=curve,solver_failures=failures))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['curves','baselines','synthetic','lastfm','scale']);p.add_argument('--repetitions',type=int,default=2000)
    args=p.parse_args()
    if args.mode=='curves':curves()
    elif args.mode=='baselines':baselines()
    elif args.mode=='scale':scale()
    else:feedback(args.mode,args.repetitions)
