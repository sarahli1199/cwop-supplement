"""Repeated serving with endogenous popularity and per-user affinity.

All methods observe the same known intrinsic click probabilities plus a feedback score.
Scores update only between windows. This is a controlled response model, not production
policy evaluation or a claim of learned-relevance performance. FairCo is explicitly a
batched score adaptation (no relevance learning); Offr is a batch FW adaptation with
two smooth penalties and known request probabilities, not the original online algorithm.
"""
import argparse
import time
import numpy as np
from scipy.special import expit
from legacy_controller import (Environment, Targets, make_environment, policy_metrics,
                               softmax_policy, entropy_rows, greedy_policy)
from evaluation import (RESULTS, Oracle, run_pd, repair, uniform, residuals, save_json)
from review_margins import tightened, slack_budget

TARGET=Targets(.055,.08,.65*np.log(18))
GRIDS={"temperature":[.15,.3,.6,1.2,2.4],
       "logshare":[.05,.15,.3,.6,1.2],
       "fairco_batch":[1e-6,1e-5,1e-4,1e-3,1e-2],
       "fw_penalty":[.1,.3,1.,3.,10.]}


def fw_policy(env, strength, iterations=1000):
    """Batch conditional gradient for W - A*C*HHI + A*sum q H_smoothed(x).

    An eligible top-1 linear oracle, diminishing 2/(t+2) steps. The entropy
    smoothing 1e-3 bounds gradients at zero. Includes BOTH target classes as
    regularizers, but does not claim hard constraint satisfaction.
    """
    x=uniform(env)
    eta=1e-3
    for t in range(iterations):
        rho=env.request_prob@x
        # HHI and entropy coefficient ratio fixed; global scale C makes it comparable.
        grad=env.utility-2*strength*env.creators*rho-strength*(np.log(x+eta)+1)
        best=np.argmax(np.where(env.candidate_mask,grad,-np.inf),axis=1)
        vertex=np.zeros_like(x); vertex[np.arange(env.users),best]=1.
        x+=(2./(t+2))*(vertex-x)
    return x


def trial(seed,method,param=None,windows=20,requests=10000,pd_iterations=2000,alpha=.15,fw_iterations=1000):
    env0=make_environment(seed)
    p=np.where(env0.candidate_mask,expit(2*np.where(env0.candidate_mask,env0.utility,0)-.8),0)
    intrinsic=Environment(env0.request_prob,env0.candidate_mask,np.where(env0.candidate_mask,p,-np.inf))
    mask=env0.candidate_mask
    f=np.ones(env0.creators)
    affinity=mask.astype(float)
    exposure=np.zeros_like(p)
    clicks=np.zeros_like(p)
    # Common random variates by seed and window; different policies lead to different outcomes.
    control_target=TARGET
    certificate=None
    if method in ('cwop_margin','oracle_margin'):
        strength=float(param)
        control_target=Targets(.055-.005*strength,.08-.01*strength,(.65+.07*strength)*np.log(18))
    elif method in ('cwop_certified','oracle_certified'):
        control_target,certificate=tightened(intrinsic,requests,windows)
        assert certificate['count_condition'] and slack_budget(intrinsic,control_target)['sufficient_feasibility']
    elif method=='cwop_safe':
        control_target=Targets(.05,.07,.72*np.log(18))
    oracle=Oracle(intrinsic,control_target) if method in ('oracle','oracle_margin','oracle_certified') else None
    probe=Oracle(intrinsic,TARGET) if method=='cwop_diagnostic' else None
    rows=[]
    started=time.perf_counter()
    for j in range(windows):
        logglobal=np.log(f/f.mean())
        meanlocal=(affinity.sum(1)/mask.sum(1))[:,None]
        loglocal=np.log(np.maximum(affinity/meanlocal,1e-300))
        score=p+alpha*logglobal+(2*alpha/3)*loglocal
        score=np.where(mask,score,-np.inf)
        env=Environment(env0.request_prob,mask,score)
        theta=0.; od=None
        if method=="feedback":
            x=softmax_policy(env,.1,1e-7)
        elif method=="temperature":
            x=softmax_policy(env,param,1e-7)
        elif method=="logshare":
            globalshare=(1+exposure.sum(0)); globalshare/=globalshare.mean()
            local=(mask+exposure); local/= (local.sum(1)/mask.sum(1))[:,None]
            shaped=score-param*(np.log(globalshare)+np.log(np.maximum(local,1e-300)))
            x=softmax_policy(Environment(env.request_prob,mask,shaped),.1,1e-7)
        elif method=="fairco_batch":
            # Singleton groups, known average merit, Eq.17 cumulative exposure disparity.
            merit=np.maximum(env.request_prob@p,1e-6)
            disparity=exposure.sum(0)/merit
            adjustment=param*(disparity.max()-disparity)
            x=greedy_policy(Environment(env.request_prob,mask,score+adjustment),1e-7)
        elif method=="fw_penalty":
            x=fw_policy(env,param,fw_iterations)
        elif method in ("cwop","cwop_safe","cwop_margin","cwop_certified","cwop_diagnostic","global_pd","local_pd"):
            # Fixed illustrative margins, chosen before this arm is run; do not
            # assert the conservative simultaneous theorem is satisfied at N=10k.
            x,_=run_pd(env,control_target,pd_iterations,method!="local_pd",method!="global_pd")
            if method in ("cwop","cwop_safe","cwop_margin","cwop_certified","cwop_diagnostic"):
                x,theta=repair(env,x,control_target)
        elif method in ("oracle","oracle_margin","oracle_certified"):
            x,od=oracle.solve(score)
        else:
            raise ValueError(method)
        if probe is not None:
            _,od=probe.solve(score)
        rng=np.random.default_rng(np.random.SeedSequence([seed,j,91021]))
        user=rng.choice(env.users,requests,p=env.request_prob)
        draws=rng.random(requests); response=rng.random(requests)
        cumulative=np.cumsum(x,axis=1); cumulative[:,-1]=1.
        chosen=np.sum(draws[:,None]>cumulative[user],axis=1)
        counts=np.zeros_like(x); np.add.at(counts,(user,chosen),1)
        hits=np.zeros_like(x); np.add.at(hits,(user,chosen),(response<p[user,chosen]).astype(float))
        exposure+=counts; clicks+=hits
        f+=hits.sum(0); affinity+=hits
        nuser=counts.sum(1)
        assert nuser.min()>0
        emp=counts/nuser[:,None]
        empirical_env=Environment(nuser/requests,mask,intrinsic.utility)
        em=policy_metrics(empirical_env,emp,TARGET)
        planned=policy_metrics(intrinsic,x,TARGET)
        total=exposure.sum(1)
        pooled=exposure/total[:,None]
        pooledenv=Environment(total/total.sum(),mask,intrinsic.utility)
        pm=policy_metrics(pooledenv,pooled,TARGET)
        consumption=clicks/np.maximum(clicks.sum(1,keepdims=True),1)
        rows.append(dict(window=j+1,planned=planned,empirical=em,pooled=pm,
                         score_welfare=policy_metrics(env,x,TARGET)['welfare'],oracle_diagnostics=od,
                         same_state_oracle_gap=(None if probe is None else od['metrics']['welfare']-policy_metrics(env,x,TARGET)['welfare']),
                         realized_click_rate=float(hits.sum()/requests),
                         pooled_click_rate=float(clicks.sum()/exposure.sum()),
                         min_consumption_entropy=float((entropy_rows(consumption,mask)/np.log(18)).min()),
                         repair_theta=theta,
                         safety_cost_budget=slack_budget(env,control_target),
                         max_creator_tracking=float(np.max(np.abs(counts.sum(0)/requests-env.request_prob@x)))))
    return dict(seed=seed,method=method,parameter=param,alpha=alpha,rows=rows,
                requests=requests,certificate=certificate,fw_iterations=fw_iterations,
                seconds=time.perf_counter()-started)


def tune(windows,requests,pd_iterations):
    rows=[]; selection={}
    # Fixed protocol: prefer <=2% normalized pooled target excess, then highest utility;
    # if none, minimize violation first. Training seeds disjoint from test seeds.
    for method,grid in GRIDS.items():
        options=[]
        for param in grid:
            trials=[trial(s,method,param,windows,requests,pd_iterations) for s in (20260901,20260902)]
            last=[t['rows'][-1]['pooled'] for t in trials]
            v=float(np.mean([max(m['hhi']/.055-1,m['max_share']/.08-1,
                                       (.65-m['min_norm_entropy'])/.65,0) for m in last]))
            w=float(np.mean([m['welfare'] for m in last]))
            item=dict(method=method,parameter=param,normalized_violation=v,welfare=w,trials=trials)
            options.append(item); rows.append(item)
        feasible=[o for o in options if o['normalized_violation']<=.02]
        best=max(feasible,key=lambda o:o['welfare']) if feasible else min(options,key=lambda o:(o['normalized_violation'],-o['welfare']))
        selection[method]=best['parameter']
        print('tuned',method,best['parameter'],best['normalized_violation'],flush=True)
        save_json(RESULTS/'feedback_tuning.json',dict(selection=selection,grid=rows))
    return selection


def main(args):
    tuning=RESULTS/'feedback_tuning.json'
    if args.reuse_tuning:
        import json
        selected=json.loads(tuning.read_text())['selection']
    else:
        selected=tune(args.windows,args.requests,args.pd_iterations)
    result=dict(protocol=vars(args),selected=selected,trials=[])
    methods=['feedback',*GRIDS,'global_pd','local_pd','cwop','cwop_safe','oracle']
    for seed in range(20260910,20260915):
        for method in methods:
            row=trial(seed,method,selected.get(method),args.windows,args.requests,args.pd_iterations)
            result['trials'].append(row)
            save_json(RESULTS/'feedback.json',result)
            last=row['rows'][-1]
            print(seed,method,'utility',round(last['pooled']['welfare'],4),'HHI',round(last['pooled']['hhi'],4),flush=True)
    # Sensitivity to feedback strength, identical held-out seeds and selected weights.
    sensitivity=[]
    for alpha in (0.,.3):
        for seed in range(20260910,20260915):
            for method in ('feedback','temperature','logshare','cwop'):
                sensitivity.append(trial(seed,method,selected.get(method),args.windows,args.requests,args.pd_iterations,alpha))
                save_json(RESULTS/'feedback_sensitivity.json',dict(trials=sensitivity))


if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--windows',type=int,default=20)
    p.add_argument('--requests',type=int,default=10000)
    p.add_argument('--pd-iterations',type=int,default=2000)
    p.add_argument('--reuse-tuning',action='store_true')
    main(p.parse_args())
