"""Download only the official noncommercial research archive, then verify its checksum."""
import hashlib
from pathlib import Path
import urllib.request
ROOT = Path(__file__).resolve().parents[1]

SOURCE_URL = 'https://files.grouplens.org/datasets/hetrec2011/hetrec2011-lastfm-2k.zip'
SOURCE_SHA256 = '6738f48195667ff03caaab4d32ca9a3133d8cc026b7c3cdaf6ce1010e913c59c'
target=ROOT/'external/hetrec2011-lastfm-2k.zip'
target.parent.mkdir(exist_ok=True)
if not target.exists():
    urllib.request.urlretrieve(SOURCE_URL,target)
actual=hashlib.sha256(target.read_bytes()).hexdigest()
assert actual==SOURCE_SHA256, 'Official input changed; do not silently substitute data.'
print('Verified public Last.fm archive; noncommercial research use only.')
