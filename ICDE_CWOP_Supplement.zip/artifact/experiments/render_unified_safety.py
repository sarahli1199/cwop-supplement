"""Final matched-window tables and figures, derived from saved experiments."""
import csv
import numpy as np
from render_review import ROOT,PAPER,read,table,plt
from render_safety_refinement import savefig
from evaluation import RESULTS,save_json

LABELS={'conic':'Conic reference, no margin','certified':'Conic reference + certificate',
        'temperature':'Temperature','logshare':'Log-share','fairco_batch':'FairCo-style batch',
        'fw_penalty':'Two-sided batch FW'}
ORDER=['temperature','logshare','fairco_batch','fw_penalty','conic','certified']


def main():
    plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
    summary={}
    for dataset in ('synthetic','lastfm'):
        data=read(f'unified_feedback_{dataset}.json');summary[dataset]={}
        assert len(data['calibration'])==40, 'Wait for all frozen-policy tests before rendering.'
        for method in ORDER:
            ts=[t for t in data['test'] if t['method']==method]
            assert len(ts)==(5 if dataset=='synthetic' else 3)
            rs=[r for t in ts for r in t['rows']]
            w=np.array([t['rows'][-1]['pooled']['welfare'] for t in ts])
            s=dict(utility=float(w.mean()),utility_sd=float(w.std(ddof=1)),
                   failures=sum(r['empirical']['max_violation']>1e-6 for r in rs),windows=len(rs),
                   N=ts[0]['N'],parameter=ts[0]['parameter'],
                   min_clicked_entropy=float(np.mean([t['rows'][-1]['min_consumption_entropy'] for t in ts])),
                   min_exposure_entropy=float(np.mean([t['rows'][-1]['pooled']['min_norm_entropy'] for t in ts])),
                   hhi=float(np.mean([t['rows'][-1]['pooled']['hhi'] for t in ts])),
                   cap=float(np.mean([t['rows'][-1]['pooled']['max_share'] for t in ts])))
            cal=[r for r in data['calibration'] if r['method']==method]
            if cal:s.update(frozen_failures=sum(r['failures'] for r in cal),frozen_repetitions=sum(r['repetitions'] for r in cal))
            if method=='certified':
                s['max_certified_excess']=max(r['safety']['certificate']['max_certified_excess'] for r in rs)
                s['refinement_errors']=[a for r in rs for a in r['safety']['refinement_attempts'] if 'error' in a]
                s['entropy_policy_branch']=sum(
                    a is not None and a+b<=c for r in rs
                    for a,b,c in zip(r['safety']['certificate']['entropy_linear'],
                                     r['safety']['certificate']['entropy_kl'],
                                     r['safety']['certificate']['entropy_bounded']))
                s['type_windows']=sum(len(r['safety']['certificate']['entropy_bounded']) for r in rs)
                lower=[r['safety']['uniform_envelope_lower_bound'] for r in rs]
                s['envelope_available']=sum(v is not None for v in lower)
                s['envelope_lower_mean']=float(np.mean([v for v in lower if v is not None])) if any(v is not None for v in lower) else None
                s['max_envelope_theta']=max(r['safety']['uniform_envelope_budget']['theta'] for r in rs)
            summary[dataset][method]=s
        summary[dataset]['certified']['relative_utility_loss']=1-summary[dataset]['certified']['utility']/summary[dataset]['conic']['utility']
    save_json(RESULTS/'unified_summary.json',summary)
    numbers=('\\newcommand{\\UnifiedSyntheticCertified}{%.3f}\n'
             '\\newcommand{\\UnifiedSyntheticCost}{%.1f\\%%}\n'
             '\\newcommand{\\UnifiedLastfmCertified}{%.3f}\n'
             '\\newcommand{\\UnifiedLastfmCost}{%.1f\\%%}\n') % (
                 summary['synthetic']['certified']['utility'],100*summary['synthetic']['certified']['relative_utility_loss'],
                 summary['lastfm']['certified']['utility'],100*summary['lastfm']['certified']['relative_utility_loss'])
    for directory in {PAPER/'latex',ROOT/'latex'}:(directory/'unified_numbers.tex').write_text(numbers)
    rows=[]
    for method in ORDER:
        row=[LABELS[method]]
        for dataset in ('synthetic','lastfm'):
            s=summary[dataset][method]
            sd=f"{s['utility_sd']:.4f}" if s['utility_sd']<.0005 else f"{s['utility_sd']:.3f}"
            row += [f"${s['utility']:.3f}\\pm{sd}$",f"${s['failures']}/{s['windows']}$"]
        rows.append(row)
    table('table_feedback_main.tex',r'Matched-window feedback comparison. All methods use 20k requests per window on five synthetic graphs and 100k on three Last.fm splits, with 20 windows per trajectory. Utility is mean simulated response probability (across-trajectory SD); failures count windows violating any target. Baselines are tuned on disjoint training instances at the same window sizes.',
          'tab:feedback',['Method','Synthetic utility','Failures','Last.fm utility','Failures'],rows)
    rows=[]
    for dataset in ('synthetic','lastfm'):
        prior=read(f'refined_feedback_{dataset}.json')
        ts=[t for t in prior['trials'] if t['method']=='conic_certified']
        w=float(np.mean([t['rows'][-1]['pooled']['welfare'] for t in ts]))
        base=summary[dataset]['conic']['utility'];current=summary[dataset]['certified']
        for label,utility,frozen in [('Witness segment',w,0),('Reoptimized',current['utility'],current['frozen_failures'])]:
            rows.append(['Synthetic' if dataset=='synthetic' else 'Last.fm',label,
                         f"${utility:.3f}$",f"${100*(1-utility/base):.1f}\\%$",r'$0$',f'${frozen}/40{{,}}000$'])
    table('table_certified_feedback.tex',r'Certified construction ablation at the same window sizes, graphs and response model as Table~\ref{tab:feedback}. Both constructions use the final-policy certificate. Relative utility loss compares separate feedback trajectories against the no-margin conic reference; it is not the fixed-score bound of Lemma~\ref{lem:uniform-envelope}.',
          'tab:certified-feedback',['Data','Construction','Utility','Relative loss','Window failures','Frozen failures'],rows)
    rows=[]
    for dataset in ('synthetic','lastfm'):
        for method in ORDER:
            s=summary[dataset][method]
            rows.append(['Synthetic' if dataset=='synthetic' else 'Last.fm',LABELS[method],
                         '---' if s['parameter'] is None else f"${s['parameter']:g}$",
                         f"${s['hhi']:.4f}$",f"${s['cap']:.4f}$",
                         f"${s['min_exposure_entropy']:.3f}$",f"${s['min_clicked_entropy']:.3f}$"])
    table('table_matched_details.tex',r'Matched-window policies: selected baseline parameters, pooled exposure, and minimum normalized clicked-item entropy. All reported metrics average over test trajectories; entropy uses each dataset\textquotesingle s candidate-set size.',
          'tab:matched-details',['Data','Method','Parameter','HHI','Max share','Exposure $H$','Clicked $H$'],rows)
    fig,axs=plt.subplots(1,2,figsize=(6.5,2.4),layout='constrained')
    colors=['#0072B2','#E69F00','#777777','#CC79A7','#D55E00','#009E73']
    markers=['o','v','s','D','x','*']
    for ax,dataset in zip(axs,('synthetic','lastfm')):
        for method,color,marker in zip(ORDER,colors,markers):
            s=summary[dataset][method]
            ax.scatter(100*s['failures']/s['windows'],s['utility'],color=color,marker=marker,
                       s=55 if method=='certified' else 25,label=LABELS[method],zorder=3)
        ax.set(xlabel='Violating windows (%)',ylabel='Mean response probability',xlim=(-5,105),
               title='Synthetic, N = 20k' if dataset=='synthetic' else 'Last.fm, N = 100k')
    handles,labels=axs[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='outside lower center',ncol=3,fontsize=6.7)
    savefig(fig,'review_tradeoffs')
    print(summary)


if __name__=='__main__':main()
