import itertools
import unittest
import numpy as np
from review_margins import margins,tightened
from evaluation import uniform,residuals
from legacy_controller import make_environment

def entropy(p):
    p=np.asarray(p);p=p[p>0];return float(-p@np.log(p))

class MarginsTest(unittest.TestCase):
    def test_entropy_replacement_bound(self):
        for n in range(3,15):
            bound=(np.log(n)+1)/n
            for a in range(n+1):
                for b in range(n-a+1):
                    counts=np.array([a,b,n-a-b])
                    for i,j in itertools.permutations(range(3),2):
                        if counts[i]==0:continue
                        changed=counts.copy();changed[i]-=1;changed[j]+=1
                        self.assertLessEqual(abs(entropy(counts/n)-entropy(changed/n)),bound+1e-14)
    def test_bias_exact_binomial(self):
        from scipy.stats import binom
        for n in (3,10,50):
            for p in (.01,.2,.5,.9):
                expected=sum(binom.pmf(k,n,p)*entropy([k/n,1-k/n]) for k in range(n+1))
                self.assertLessEqual(entropy([p,1-p])-expected,np.log1p(1/n)+1e-12)
    def test_witness_threshold(self):
        env=make_environment();x=uniform(env)
        self.assertGreater(residuals(env,x,tightened(env,12337)[0]).max(),0)
        self.assertLessEqual(residuals(env,x,tightened(env,12338)[0]).max(),0)
    def test_test_graphs_certificate(self):
        for seed in range(20260910,20260915):
            env=make_environment(seed);t,m=tightened(env,50000)
            self.assertTrue(m['count_condition'])
            self.assertLess(residuals(env,uniform(env),t).max(),0)
    def test_hhi_expansion(self):
        rng=np.random.default_rng(391)
        for _ in range(100):
            p=rng.dirichlet(np.ones(18));v=rng.multinomial(1000,p)/1000;e=v-p
            self.assertAlmostEqual(v@v-p@p,2*p@e+e@e,places=13)

if __name__=='__main__':unittest.main()
