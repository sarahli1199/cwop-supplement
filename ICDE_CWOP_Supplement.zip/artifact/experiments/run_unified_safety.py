"""Matched-window feedback evaluation with final-policy certification.

Training graphs/splits and test graphs/splits are disjoint. All policies see the
same specified feedback model and window size within a dataset. Outcomes remain
simulated, including responses on the Last.fm-derived preference graph.
"""
import argparse
import json
import time
import numpy as np
from scipy.special import expit
from legacy_controller import (Environment, Targets, make_environment, policy_metrics,
                               entropy_rows, softmax_policy, greedy_policy)
from evaluation import RESULTS, Oracle, uniform, save_json
from plan_safety import optimized_certificate, certificate, frozen_test, minimum_uniform_n
from run_safety_refinement import BASE, lastfm

GRIDS=dict(temperature=[.15,.3,.6,1.2,2.4,4.8,9.6,19.2],
           logshare=[.05,.15,.3,.6,1.2],
           fairco_batch=[1e-6,1e-5,1e-4,1e-3,1e-2],
           fw_penalty=[.1,.3,1.,3.,10.])


def compact_fw(env,strength,iterations=10000):
    """The same fixed-degree batch FW updates, stored only on eligible edges."""
    degrees=env.candidate_mask.sum(1)
    assert np.all(degrees==degrees[0])
    K=int(degrees[0]);U=env.users
    ui,ci=np.where(env.candidate_mask);ci=ci.reshape(U,K)
    utility=env.utility[env.candidate_mask].reshape(U,K)
    x=np.full((U,K),1/K);q=env.request_prob[:,None]
    for t in range(iterations):
        rho=np.bincount(ci.ravel(),weights=(q*x).ravel(),minlength=env.creators)
        grad=utility-2*strength*env.creators*rho[ci]-strength*(np.log(x+1e-3)+1)
        best=grad.argmax(1);step=2./(t+2)
        x*=1-step;x[np.arange(U),best]+=step
    out=np.zeros_like(env.utility);out[env.candidate_mask]=x.ravel()
    return out


def training_graphs():
    if all((RESULTS/f'lastfm_{s}.npz').exists() for s in (20260916,20260917)):return
    from run_lastfm import load_matrix,build
    matrix,selected,sha,nrows=load_matrix()
    expected=json.loads((RESULTS/'lastfm.json').read_text())['source_sha256']
    assert sha==expected
    meta=[]
    for s in (20260916,20260917):
        env,target,di=build(s,matrix,selected)
        np.savez_compressed(RESULTS/f'lastfm_{s}.npz',request_prob=env.request_prob,
                            candidate_mask=env.candidate_mask,utility=env.utility)
        meta.append(dict(seed=s,**di))
    save_json(RESULTS/'unified_lastfm_training_graphs.json',dict(source_sha256=sha,raw_rows=nrows,instances=meta))


def run_trial(dataset,seed,method,param=None,save_plans=False):
    source,target=(make_environment(seed),BASE) if dataset=='synthetic' else lastfm(seed)
    N=20000 if dataset=='synthetic' else 100000;J=20;mask=source.candidate_mask
    p=(np.where(mask,expit(2*np.where(mask,source.utility,0)-.8),0) if dataset=='synthetic'
       else np.where(mask,np.clip(source.utility,0,1),0))
    intrinsic=Environment(source.request_prob,mask,np.where(mask,p,-np.inf))
    f=np.ones(source.creators);affinity=mask.astype(float)
    exposure=np.zeros_like(p);clicks=np.zeros_like(p);rows=[];plans=[]
    ref=Oracle(intrinsic,target) if method in ('conic','certified') else None
    started=time.perf_counter()
    for j in range(J):
        score=p+.15*np.log(f/f.mean())+.1*np.log(np.maximum(affinity/(affinity.sum(1)/mask.sum(1))[:,None],1e-300))
        score=np.where(mask,score,-np.inf);env=Environment(source.request_prob,mask,score)
        safe=None
        if ref is not None:
            x,di=ref.solve(score)
            if method=='certified':
                x,safe=optimized_certificate(env,target,N,J,base=x)
                if x is None:raise RuntimeError(f'no certified plan: {dataset} {seed} {j}')
                assert certificate(env,x,target,N,J)['valid']
        elif method=='temperature':x=softmax_policy(env,param,1e-7)
        elif method=='logshare':
            globalshare=1+exposure.sum(0);globalshare/=globalshare.mean()
            local=mask+exposure;local/= (local.sum(1)/mask.sum(1))[:,None]
            shaped=score-param*(np.log(globalshare)+np.log(np.maximum(local,1e-300)))
            x=softmax_policy(Environment(env.request_prob,mask,shaped),.1,1e-7)
        elif method=='fairco_batch':
            merit=np.maximum(env.request_prob@p,1e-6);disparity=exposure.sum(0)/merit
            x=greedy_policy(Environment(env.request_prob,mask,score+param*(disparity.max()-disparity)),1e-7)
        elif method=='fw_penalty':x=compact_fw(env,param)
        else:raise ValueError(method)
        if save_plans:plans.append(x.copy())
        rng=np.random.default_rng(np.random.SeedSequence([seed,j,92203]))
        sizes=rng.multinomial(N,env.request_prob);counts=np.zeros_like(x);hits=np.zeros_like(x)
        assert sizes.min()>0
        for u in range(env.users):
            ix=np.flatnonzero(mask[u]);counts[u,ix]=rng.multinomial(sizes[u],x[u,ix]/x[u,ix].sum())
            hits[u,ix]=rng.binomial(counts[u,ix].astype(int),p[u,ix])
        f+=hits.sum(0);affinity+=hits;exposure+=counts;clicks+=hits
        em=policy_metrics(Environment(sizes/N,mask,intrinsic.utility),counts/sizes[:,None],target)
        total=exposure.sum(1)
        pm=policy_metrics(Environment(total/total.sum(),mask,intrinsic.utility),exposure/total[:,None],target)
        consumption=clicks/np.maximum(clicks.sum(1,keepdims=True),1)
        rows.append(dict(window=j+1,planned=policy_metrics(intrinsic,x,target),empirical=em,pooled=pm,
                         safety=safe,score=policy_metrics(env,x,target)['welfare'],
                         normalized_excess=float(max(0,em['hhi']/target.hhi-1,em['max_share']/target.cap-1,
                             (target.entropy-em['min_norm_entropy']*np.log(mask.sum(1)[0]))/target.entropy)),
                         pooled_click_rate=float(clicks.sum()/exposure.sum()),
                         min_consumption_entropy=float(np.min(entropy_rows(consumption,mask)/np.log(mask.sum(1))))))
    path=None
    if save_plans:
        path=f'unified_plans_{dataset}_{seed}_{method}.npz'
        np.savez_compressed(RESULTS/path,q=intrinsic.request_prob,mask=mask,utility=intrinsic.utility,plans=np.array(plans))
    return dict(dataset=dataset,seed=seed,method=method,parameter=param,N=N,rows=rows,plans=path,
                minimum_uniform_n=minimum_uniform_n(intrinsic,target),
                seconds=time.perf_counter()-started,fw_iterations=10000 if method=='fw_penalty' else None,
                targets=dict(hhi=target.hhi,cap=target.cap,entropy=target.entropy),
                clipped_proxy_entries=int(np.sum(mask&((source.utility<0)|(source.utility>1)))))


def run(dataset,phase):
    dest=RESULTS/f'unified_feedback_{dataset}.json'
    out=json.loads(dest.read_text()) if dest.exists() else dict(training=[],test=[],calibration=[])
    trainseeds=(20260901,20260902) if dataset=='synthetic' else (20260916,20260917)
    testseeds=range(20260910,20260915) if dataset=='synthetic' else range(20260920,20260923)
    if phase in ('all','train'):
        if dataset=='lastfm':training_graphs()
        for method,grid in GRIDS.items():
            for parameter in grid:
                for seed in trainseeds:
                    if any(t['seed']==seed and t['method']==method and t['parameter']==parameter for t in out['training']):continue
                    out['training'].append(run_trial(dataset,seed,method,parameter))
                    save_json(dest,out);print(dataset,'train',method,parameter,seed,flush=True)
        selected={};options=[]
        for method,grid in GRIDS.items():
            choices=[]
            for parameter in grid:
                ts=[t for t in out['training'] if t['method']==method and t['parameter']==parameter]
                rows=[r for t in ts for r in t['rows']]
                choices.append(dict(method=method,parameter=parameter,
                    rate=float(np.mean([r['empirical']['max_violation']>1e-6 for r in rows])),
                    normalized_excess=float(np.mean([r['normalized_excess'] for r in rows])),
                    utility=float(np.mean([t['rows'][-1]['pooled']['welfare'] for t in ts]))))
            feasible=[c for c in choices if c['rate']<=.05]
            best=max(feasible,key=lambda c:c['utility']) if feasible else min(choices,key=lambda c:(c['rate'],c['normalized_excess'],-c['utility']))
            selected[method]=best['parameter'];options+=choices
        out.update(selection=selected,options=options,
                   selection_rule='Training window violation <=5%, then utility; otherwise rate, normalized excess, utility.')
        save_json(dest,out)
    if phase in ('all','test','certified'):
        methods={'conic':None,'certified':None}
        if phase!='certified':methods.update(out['selection'])
        for method,param in methods.items():
            for seed in testseeds:
                if any(t['seed']==seed and t['method']==method for t in out['test']):continue
                out['test'].append(run_trial(dataset,seed,method,param,save_plans=True))
                save_json(dest,out);print(dataset,'test',method,seed,flush=True)
    if phase in ('all','calibrate'):
        for method in ('conic','certified'):
            t=next(t for t in out['test'] if t['method']==method and t['seed']==testseeds.start)
            a=np.load(RESULTS/t['plans']);env=Environment(a['q'],a['mask'],a['utility']);target=Targets(**t['targets'])
            for j,x in enumerate(a['plans']):
                if any(r['method']==method and r['window']==j+1 for r in out['calibration']):continue
                row=frozen_test(env,x,target,t['N'],2000,seed=1953000+j+(100 if method=='certified' else 0))
                out['calibration'].append(dict(method=method,window=j+1,**row));save_json(dest,out)
        print(dataset,'frozen sampling complete',flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('dataset',choices=['synthetic','lastfm'])
    p.add_argument('--phase',choices=['all','train','test','certified','calibrate'],default='all')
    a=p.parse_args();run(a.dataset,a.phase)
