"""Additional review comparisons. New files only; frozen training/test split."""
import argparse
import json
from concurrent.futures import ProcessPoolExecutor, as_completed
import numpy as np
from evaluation import RESULTS, save_json
from run_feedback import trial, GRIDS

GRIDS={**GRIDS,'temperature':GRIDS['temperature']+[4.8,9.6,19.2]}

def execute(job):
    seed,method,param,n=job
    return trial(seed,method,param,20,n,10000)

def violation(row):
    return row['empirical']['max_violation']>1e-6

def run(mode,workers):
    if mode=='baselines':
        original=json.loads((RESULTS/'feedback_tuning.json').read_text())
        train=[]
        for option in original['grid']: train.extend(option['trials'])
        jobs=[(s,'temperature',p,10000) for s in (20260901,20260902) for p in (4.8,9.6,19.2)]
        with ProcessPoolExecutor(max_workers=workers) as pool:
            for t in pool.map(execute,jobs): train.append(t)
        selection={}; options=[]
        for method,grid in GRIDS.items():
            choices=[]
            for p in grid:
                subset=[t for t in train if t['method']==method and t['parameter']==p]
                assert len(subset)==2
                rate=float(np.mean([violation(r) for t in subset for r in t['rows']]))
                welfare=float(np.mean([t['rows'][-1]['pooled']['welfare'] for t in subset]))
                choices.append(dict(method=method,parameter=p,window_violation=rate,welfare=welfare))
            eligible=[c for c in choices if c['window_violation']<=.05]
            best=max(eligible,key=lambda c:c['welfare']) if eligible else min(choices,key=lambda c:(c['window_violation'],-c['welfare']))
            selection[method]=best['parameter']; options.extend(choices)
        save_json(RESULTS/'review_tuning.json',dict(selection=selection,options=options,trials=train,
            rule='Maximize training mean intrinsic utility among <=5% window violation; otherwise minimize window violation then maximize utility. No test selection.'))
        jobs=[(s,m,p,10000) for s in range(20260910,20260915) for m,g in GRIDS.items() for p in g]
    else:
        jobs=[(s,m,t,10000) for s in range(20260910,20260915)
              for m in ('cwop_margin','oracle_margin') for t in (.5,1.,1.5)]
        jobs += [(s,m,None,50000) for s in range(20260910,20260915)
                 for m in ('cwop_certified','oracle_certified')]
    output=RESULTS/f'review_{mode}.json'
    existing=json.loads(output.read_text()) if output.exists() else {'trials':[]}
    completed={(t['seed'],t['method'],t['parameter'],t.get('requests',10000)) for t in existing['trials']}
    jobs=[j for j in jobs if j not in completed]
    with ProcessPoolExecutor(max_workers=workers) as pool:
        futures={pool.submit(execute,j):j for j in jobs}
        for f in as_completed(futures):
            t=f.result(); existing['trials'].append(t);save_json(output,existing)
            print(mode,t['seed'],t['method'],t['parameter'],len(existing['trials']),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['baselines','margins']);p.add_argument('--workers',type=int,default=2)
    args=p.parse_args();run(args.mode,args.workers)
