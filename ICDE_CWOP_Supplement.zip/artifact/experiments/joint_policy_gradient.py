"""Singh--Joachims-style known-score, single-item policy-gradient adaptation.

Use tabular Plackett--Luce logits (categorical for L=1) and replace the original
merit-disparity penalty with normalized positive residuals of the three CWOP
target families. Exact finite-action expectations replace Monte Carlo estimates.
This is an adaptation, not the authors' full learning-to-rank implementation.
No analytic sampling margin is used here; a separate certificate wrapper may be
applied by the experiment runner.
"""
import numpy as np
from scipy.special import softmax

ITERATIONS = 2000
LEARNING_RATE = .03
ENTROPY_REGULARIZATION = .001
PENALTIES = [.1, 1., 10., 100., 1000.]


def objective_gradient(logits, score, q, creators, total_creators, target, strength):
    """Return the exact penalized score and logit gradient on eligible edges."""
    x = softmax(logits, axis=1)
    U, K = x.shape; weighted = q[:, None]*x
    rho = np.bincount(creators.ravel(), weights=weighted.ravel(), minlength=total_creators)
    logx = np.log(np.maximum(x, 1e-300)); entropy = -np.sum(x*logx, axis=1)
    hres = max(0., (rho@rho)/target.hhi-1)
    cres = np.maximum(0., rho/target.cap-1)
    ures = np.maximum(0., 1-entropy/target.entropy)
    penalty = .5*(hres*hres+np.mean(cres*cres)+np.mean(ures*ures))
    value = float(np.sum(weighted*score)-strength*penalty+
                  ENTROPY_REGULARIZATION*(q@entropy))
    grad = q[:, None]*(score-strength*(2*hres*rho[creators]/target.hhi+
                     cres[creators]/(total_creators*target.cap)))
    grad -= strength*ures[:, None]*(logx+1)/(U*target.entropy)
    grad -= ENTROPY_REGULARIZATION*q[:, None]*(logx+1)
    gradient = x*(grad-np.sum(x*grad, axis=1, keepdims=True))
    return value, gradient, x


def solve(env, target, strength, initial=None, iterations=ITERATIONS):
    U = env.users; K = int(env.candidate_mask.sum(1)[0])
    assert np.all(env.candidate_mask.sum(1) == K)
    creators = np.where(env.candidate_mask)[1].reshape(U, K)
    score = env.utility[env.candidate_mask].reshape(U, K)
    logits = np.zeros((U, K)) if initial is None else initial.copy()
    first = np.zeros_like(logits); second = np.zeros_like(logits)
    best_value = -np.inf; best = None; best_logits = None
    for step in range(1, iterations+1):
        value, grad, x = objective_gradient(logits, score, env.request_prob,
                                           creators, env.creators, target, strength)
        if value > best_value:
            best_value, best, best_logits = value, x.copy(), logits.copy()
        first = .9*first+.1*grad; second = .999*second+.001*grad*grad
        logits += LEARNING_RATE*(first/(1-.9**step))/(np.sqrt(second/(1-.999**step))+1e-8)
        logits -= logits.mean(1, keepdims=True)
    # The exploration floor is shared with the other known-score baselines.
    best = (1-K*1e-7)*best+1e-7
    out = np.zeros_like(env.utility); out[env.candidate_mask] = best.ravel()
    return out, best_logits, dict(objective=best_value, iterations=iterations,
                                 penalty=strength, exact_gradient=True)
