"""Single numeric source for manuscript tables, plots, and validation."""
import json
import numpy as np
from evaluation import ROOT,RESULTS,save_json

def load(name): return json.loads((RESULTS/name).read_text())
def stats(v):
    a=np.asarray(v,float)
    return dict(mean=float(a.mean()),sd=float(a.std(ddof=1)) if len(a)>1 else 0.)

def main():
    static=load('static.json'); real=load('lastfm.json'); feedback=load('feedback.json')
    assert len(static['instances'])==6 and len(real['instances'])==3 and len(feedback['trials'])==50
    out=dict(static=[],lastfm=[],feedback={},paired={})
    for r in static['instances']:
        wc=r['oracle']['metrics']['welfare']; wp=r['policies']['joint_repaired']['metrics']['welfare']
        out['static'].append(dict(seed=r['seed'],greedy=r['witness']['greedy_welfare'],oracle=wc,
               cwop=wp,cost=r['witness']['greedy_welfare']-wc,gap=wc-wp,
               certificate=r['oracle']['certified_gap'],floor_bound=r['witness']['exploration_gap_upper']))
    for r in real['instances']:
        out['lastfm'].append(dict(seed=r['seed'],greedy=r['greedy']['welfare'],
                       oracle=r['oracle']['metrics']['welfare'],cwop=r['repaired']['welfare'],
                       gap=r['oracle']['metrics']['welfare']-r['repaired']['welfare'],
                       certificate=r['oracle']['certified_gap'],recall=r['heldout_recall20'],
                       popularity_recall=r['popularity_recall20']))
    methods=list(dict.fromkeys(r['method'] for r in feedback['trials']))
    for method in methods:
        trials=[r for r in feedback['trials'] if r['method']==method]; assert len(trials)==5
        summary={}
        for key in ['welfare','hhi','max_share','min_norm_entropy','max_violation']:
            summary[key]=stats([r['rows'][-1]['pooled'][key] for r in trials])
        summary['window_violation_rate']=stats([np.mean([v['empirical']['max_violation']>1e-6 for v in r['rows']]) for r in trials])
        summary['planned_max_violation']=max(v['planned']['max_violation'] for r in trials for v in r['rows'])
        summary['click_rate']=stats([r['rows'][-1]['pooled_click_rate'] for r in trials])
        summary['min_consumption_entropy']=stats([r['rows'][-1]['min_consumption_entropy'] for r in trials])
        summary['seconds']=stats([r['seconds'] for r in trials])
        out['feedback'][method]=summary
    cw={r['seed']:r['rows'][-1]['pooled']['welfare'] for r in feedback['trials'] if r['method']=='cwop'}
    for method in methods:
        if method=='cwop':continue
        values=[cw[r['seed']]-r['rows'][-1]['pooled']['welfare'] for r in feedback['trials'] if r['method']==method]
        summary=stats(values); width=2.776445105*summary['sd']/np.sqrt(5)
        out['paired'][method]=dict(**summary,ci95=[summary['mean']-width,summary['mean']+width])
    oracles=[v['oracle_diagnostics'] for r in feedback['trials'] for v in r['rows'] if v['oracle_diagnostics']]
    out['feedback_oracle']=dict(status_counts={s:sum(r['status']==s for r in oracles) for s in set(r['status'] for r in oracles)},
                               max_certificate=max(r['certified_gap'] for r in oracles))
    save_json(RESULTS/'summary.json',out)
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()
