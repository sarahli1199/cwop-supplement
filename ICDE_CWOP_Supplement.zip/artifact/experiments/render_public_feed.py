"""Render all matched comparisons from locally generated public/synthetic outputs."""
from pathlib import Path
import argparse
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from summarize_margin_budgets import independent_margins

METHODS={'temperature':'Temperature','logshare':'Log-share','fairco_batch':'FairCo-style batch',
         'fairco_certificate':'FairCo + certificate','fw_penalty':'Two-sided batch FW',
         'joint_pg':'Joint PG','joint_pg_certificate':'Joint PG + certificate',
         'conic':'Conic reference, no margin','certified':'Certified CWOP (conic)'}


def summarize(existing,hybrid,new):
    result={'matched':{},'joint_outcomes':{},'public_margin_budget':{},'paired_gains':{}}
    old_hybrid=json.loads((hybrid/'hybrid.json').read_text())['rows']
    for dataset in ['synthetic','lastfm','kuairand']:
        added=json.loads((new/f'reviewer_{dataset}.json').read_text())['test']
        trials=[] if dataset=='kuairand' else json.loads((existing/f'unified_feedback_{dataset}.json').read_text())['test']
        trials=trials+added
        if dataset!='kuairand':
            trials += [dict(t,method='fairco_certificate') for t in old_hybrid if t['dataset']==dataset]
        def utility(t):return t['pooled']['welfare'] if 'pooled' in t else t['rows'][-1]['pooled']['welfare']
        reference=float(np.mean([utility(t) for t in trials if t['method']=='conic']))
        bymethod={};byseed={}
        for method in METHODS:
            ts=[t for t in trials if t['method']==method];assert len(ts)==(5 if dataset=='synthetic' else 3)
            us=np.array([utility(t) for t in ts])/reference;rs=[r for t in ts for r in t['rows']]
            bymethod[method]=dict(utility=float(us.mean()),sd=float(us.std(ddof=1)),
                failures=sum(r['empirical']['max_violation']>1e-6 for r in rs),windows=len(rs))
            byseed[method]={t['seed']:utility(t) for t in ts}
        safe=[m for m,v in bymethod.items() if v['failures']==0 and m!='certified']
        strongest=max(safe,key=lambda m:bymethod[m]['utility'])
        result['paired_gains'][dataset]=dict(strongest_zero_failure_baseline=strongest,
            mean_gain=bymethod['certified']['utility']/bymethod[strongest]['utility']-1,
            per_seed=[byseed['certified'][s]/byseed[strongest][s]-1 for s in sorted(byseed['certified'])],
            certification_cost=1-bymethod['certified']['utility'])
        result['matched'][dataset]=bymethod
        if dataset=='kuairand':
            for method in ['conic','certified']:
                ts=[t for t in trials if t['method']==method];rs=[(t,r) for t in ts for r in t['rows']]
                result['joint_outcomes'][method]=dict(
                    hhi=max(r['empirical']['hhi']/t['targets']['hhi'] for t,r in rs),
                    cap=max(r['empirical']['max_share']/t['targets']['cap'] for t,r in rs),
                    entropy=min(r['empirical']['min_norm_entropy'] for t,r in rs),
                    global_failures=sum(max(r['empirical']['hhi']-t['targets']['hhi'],r['empirical']['max_share']-t['targets']['cap'])>1e-6 for t,r in rs),
                    local_failures=int(sum(t['targets']['entropy']-r['empirical']['min_norm_entropy']*np.log(64)>1e-6 for t,r in rs)),windows=len(rs))
            budgets=[];target_ratios=[]
            for t in [t for t in trials if t['method']=='certified']:
                arr=np.load(new/t['plans'],allow_pickle=False);q,mask=arr['q'],arr['mask'];target=t['targets']
                x0=mask/mask.sum(1)[:,None];rho0=q@x0
                sh=target['hhi']-rho0@rho0;sc=target['cap']-rho0;su=np.log(mask.sum(1))-target['entropy']
                for x in arr['plans']:
                    mh,mc,mu,_=independent_margins(q,mask,x,t['N'])
                    budgets.append([mh/sh,max(mc/sc),max(mu/su)])
                    target_ratios.append([mh/target['hhi'],max(mc)/target['cap'],max(mu)/target['entropy']])
            result['public_margin_budget']={'slack':np.max(budgets,axis=0).tolist(),'target':np.max(target_ratios,axis=0).tolist()}
    return result


def render(s,out):
    out.mkdir(parents=True,exist_ok=True)
    (out/'public_feed_summary.json').write_text(json.dumps(s,indent=2)+'\n')
    macros=[]
    for dataset,name in [('synthetic','PGSyntheticGain'),('lastfm','PGLastfmGain'),('kuairand','PublicFeedGain')]:
        macros.append('\\newcommand{\\'+name+'}{'+f"{100*s['paired_gains'][dataset]['mean_gain']:.1f}"+r'\%}')
    macros.append(r'\newcommand{\PublicFeedCost}{'+f"{100*s['paired_gains']['kuairand']['certification_cost']:.1f}"+r'\%}')
    for method,name in [('certified','PublicFeedCertified'),('joint_pg_certificate','PublicFeedPG')]:
        macros.append('\\newcommand{\\'+name+'}{'+f"{s['matched']['kuairand'][method]['utility']:.3f}"+'}')
    (out/'reviewer_numbers.tex').write_text('\n'.join(macros)+'\n')
    outcome_rows=[]
    for method,label in [('conic',r'\multirow{2}{*}{KuaiRand} & No margin'),('certified',' & Certified')]:
        v=s['joint_outcomes'][method]
        outcome_rows.append(label+f" & ${v['hhi']:.3f}$ & ${v['cap']:.3f}$ & ${v['entropy']:.3f}$ & "
            +f"${100*v['global_failures']/v['windows']:.1f}\\%$ & ${100*v['local_failures']/v['windows']:.1f}\\%$"+r' \\')
    (out/'public_outcome_rows.tex').write_text('\n'.join(outcome_rows)+'\n')
    v=s['public_margin_budget'];cells=[f"${100*t:.1f}\\%\\ ({100*b:.1f}\\%)$" for t,b in zip(v['target'],v['slack'])]
    (out/'public_margin_row.tex').write_text('KuaiRand & '+' & '.join(cells)+r' \\'+'\n')
    ds=['synthetic','lastfm','kuairand']
    lines=[r'\begin{table*}[t]\centering\small',
        r'\caption{Matched feedback: 20 windows per trajectory, 20k requests on five synthetic graphs and 100k on three Last.fm splits and three disjoint KuaiRand user groups. Utility $U_{\rm eval}/U_{\rm ref}$ and its SD use the same dataset\'s no-margin conic mean as a fixed denominator. Failures are percentages of windows. Tuning uses separate training instances; certificate wrappers inherit the raw comparator\'s parameter. Bold marks highest utility among methods with zero observed violations.}',
        r'\label{tab:feedback}',r'\begin{adjustbox}{max width=\linewidth}',r'\begin{tabular}{lrrrrrr}',r'\toprule',
        r'Method & Synthetic ratio & Failures & Last.fm ratio & Failures & KuaiRand ratio & Failures \\',r'\midrule']
    for method,label in METHODS.items():
        cells=[]
        for d in ds:
            v=s['matched'][d][method];best=max(z['utility'] for z in s['matched'][d].values() if z['failures']==0)
            u=(f"\\textbf{{{v['utility']:.3f}}}" if v['failures']==0 and v['utility']==best else f"{v['utility']:.3f}")
            cells += [f"${u}\\pm{v['sd']:.3f}$",f"${100*v['failures']/v['windows']:.1f}\\%$"]
        lines.append(label+' & '+' & '.join(cells)+r' \\')
    lines += [r'\bottomrule',r'\end{tabular}',r'\end{adjustbox}',r'\end{table*}']
    (out/'table_feedback_main.tex').write_text('\n'.join(lines).replace("dataset\\'s","dataset's").replace("comparator\\'s","comparator's")+'\n')
    plt.rcParams.update({'font.size':8,'axes.titlesize':8,'axes.labelsize':8,'xtick.labelsize':7,'ytick.labelsize':7,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
    fig,axs=plt.subplots(1,3,figsize=(7,2.15),layout='constrained')
    colors=['#0072B2','#E69F00','#777777','#332288','#CC79A7','#882255','#44AA99','#D55E00','#009E73']
    markers=['o','v','s','P','D','^','h','x','*']
    for ax,d,title in zip(axs,ds,['Synthetic, N = 20k','Last.fm, N = 100k','KuaiRand, N = 100k']):
        for (method,label),color,marker in zip(METHODS.items(),colors,markers):
            v=s['matched'][d][method]
            ax.scatter(100*v['failures']/v['windows'],v['utility'],color=color,marker=marker,
                       s=55 if method=='certified' else 25,label=label.replace('S--J','S–J'),zorder=3)
        ax.set(xlabel='Violating windows (%)',ylabel='Utility / conic\nreference',xlim=(-5,105),title=title)
    handles,labels=axs[0].get_legend_handles_labels();fig.legend(handles,labels,loc='outside lower center',ncol=3,fontsize=6.7)
    fig.savefig(out/'review_tradeoffs.pdf',metadata={'Creator':'Scientific plotting','CreationDate':None,'ModDate':None})
    fig.savefig(out/'review_tradeoffs.png',dpi=160);plt.close(fig)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for x in ['existing','hybrid','new','output']:p.add_argument('--'+x,type=Path,required=True)
    a=p.parse_args();s=summarize(a.existing,a.hybrid,a.new);render(s,a.output);print(json.dumps(s,indent=2))


if __name__=='__main__':main()
