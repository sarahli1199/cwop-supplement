"""Reviewer-requested public-feed and policy-gradient comparisons.

All raw inputs and results stay in explicitly supplied local directories. Training
and test groups are disjoint. The response and feedback model is the same as the
existing matched evaluation; public-data outcomes are simulated from fitted
proxies, not an estimate of deployment impact.
"""
from pathlib import Path
import argparse
import hashlib
import json
import time
import numpy as np
from scipy.special import expit
from legacy_controller import Environment, Targets, make_environment, policy_metrics, softmax_policy
from evaluation import Oracle, uniform
from plan_safety import certificate, optimized_certificate, certified_mix
from run_fairco_tradeoff import history_score, serve, fairco_proposal
from run_unified_safety import compact_fw, GRIDS
from joint_policy_gradient import solve as policy_gradient, PENALTIES


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def load_source(dataset, seed, inputs, existing):
    if dataset == 'synthetic':
        base = make_environment(seed)
        p = np.where(base.candidate_mask, expit(2*np.where(base.candidate_mask, base.utility, 0)-.8), 0)
        target = Targets(.055, .08, .65*np.log(18))
        env = Environment(base.request_prob, base.candidate_mask, np.where(base.candidate_mask, p, -np.inf))
        provenance = {'generator_seed':seed}
    else:
        path = (inputs/f'kuairand_{seed}.npz' if dataset == 'kuairand'
                else existing/f'lastfm_{seed}.npz')
        with np.load(path, allow_pickle=False) as arr:
            q = arr['q' if dataset == 'kuairand' else 'request_prob']
            mask = arr['mask' if dataset == 'kuairand' else 'candidate_mask']
            p = np.where(mask, np.clip(arr['utility'], 0, 1), 0)
        env = Environment(q, mask, np.where(mask, p, -np.inf))
        rho = q@uniform(env)
        target = Targets(1.5*(rho@rho), 1.5*rho.max(), .65*np.log(mask.sum(1)[0]))
        provenance = {'file':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
    return env, target, provenance


def trial(dataset, seed, method, parameter, inputs, existing, output, save_plans):
    source, target, provenance = load_source(dataset, seed, inputs, existing)
    mask = source.candidate_mask; p = np.where(mask, source.utility, 0)
    q = source.request_prob; N = 20000 if dataset == 'synthetic' else 100000
    J = 20; f = np.ones(source.creators); affinity = mask.astype(float)
    exposure = np.zeros_like(p); rows = []; plans = []; logits = None
    ref = Oracle(source, target) if method in ('conic', 'certified') else None
    begin = time.perf_counter()
    for j in range(J):
        score = history_score(p, mask, f, affinity)
        env = Environment(q, mask, score); safe = None; optimization = None
        if method in ('conic', 'certified'):
            x, optimization = ref.solve(score)
            if method == 'certified':
                x, safe = optimized_certificate(env, target, N, J, base=x)
        elif method == 'temperature':
            x = softmax_policy(env, parameter, 1e-7)
        elif method == 'logshare':
            gs = 1+exposure.sum(0); gs /= gs.mean()
            local = mask+exposure; local /= (local.sum(1)/mask.sum(1))[:, None]
            adjusted = score-parameter*(np.log(gs)+np.log(np.maximum(local, 1e-300)))
            x = softmax_policy(Environment(q, mask, adjusted), .1, 1e-7)
        elif method in ('fairco_batch', 'fairco_certificate'):
            x = fairco_proposal(q, mask, p, score, exposure, parameter)
            if method == 'fairco_certificate':
                x, safe = certified_mix(env, x, target, N, J)
        elif method == 'fw_penalty':
            x = compact_fw(env, parameter)
        elif method in ('joint_pg', 'joint_pg_certificate'):
            x, logits, optimization = policy_gradient(env, target, parameter, logits)
            if method == 'joint_pg_certificate':
                x, safe = certified_mix(env, x, target, N, J)
        else:
            raise ValueError(method)
        assert x is not None, (dataset, seed, method, j)
        assert np.isfinite(x).all() and x.min() >= 0
        np.testing.assert_allclose(x.sum(1), 1, atol=1e-12)
        if safe is not None:
            assert certificate(env, x, target, N, J)['valid']
        if save_plans: plans.append(x.copy())
        sizes, counts, hits = serve(q, mask, p, x, seed, j, N)
        f += hits.sum(0); affinity += hits; exposure += counts
        empirical = policy_metrics(Environment(sizes/N, mask, source.utility), counts/sizes[:, None], target)
        total = exposure.sum(1)
        pooled = policy_metrics(Environment(total/total.sum(), mask, source.utility), exposure/total[:, None], target)
        rows.append(dict(window=j+1, score=policy_metrics(env, x, target)['welfare'],
                         empirical=empirical, pooled=pooled, safety=safe, optimization=optimization,
                         normalized_excess=float(max(0, empirical['hhi']/target.hhi-1,
                             empirical['max_share']/target.cap-1,
                             1-empirical['min_norm_entropy']*np.log(mask.sum(1)[0])/target.entropy))))
    filename = None
    if save_plans:
        filename = f'plans_{dataset}_{seed}_{method}.npz'
        np.savez_compressed(output/filename, q=q, mask=mask, utility=source.utility, plans=np.array(plans))
    return dict(dataset=dataset, seed=seed, method=method, parameter=parameter,
                N=N, J=J, delta=.05, targets=dict(hhi=target.hhi,cap=target.cap,entropy=target.entropy),
                provenance=provenance, rows=rows, plans=filename, seconds=time.perf_counter()-begin)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('dataset', choices=['synthetic','lastfm','kuairand'])
    p.add_argument('--inputs', type=Path, required=True)
    p.add_argument('--existing', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--phase', choices=['all','train','test'], default='all')
    p.add_argument('--method', help='Optional independent method job; writes a separate result file.')
    p.add_argument('--seed',type=int,help='Optional single test seed for independent jobs.')
    a = p.parse_args(); a.output.mkdir(parents=True, exist_ok=True)
    name = 'reviewer_'+a.dataset+('' if a.method is None else '_'+a.method)+('' if a.seed is None else '_'+str(a.seed))+'.json'
    dest = a.output/name
    out = json.loads(dest.read_text()) if dest.exists() else dict(dataset=a.dataset,training=[],test=[])
    train = ([20260901,20260902] if a.dataset=='synthetic' else
             [20260916,20260917] if a.dataset=='lastfm' else [20261110,20261111])
    test = (list(range(20260910,20260915)) if a.dataset=='synthetic' else
            [20260920,20260921,20260922] if a.dataset=='lastfm' else [20261120,20261121,20261122])
    if a.seed is not None:
        assert a.phase=='test' and a.seed in test
        test=[a.seed]
    grids = dict(joint_pg=PENALTIES)
    if a.dataset == 'kuairand': grids = {**GRIDS, **grids}
    if a.method is not None: grids = {m:g for m,g in grids.items() if m==a.method}
    if a.phase in ('all','train'):
        for method, grid in grids.items():
            for parameter in grid:
                for seed in train:
                    if any(t['method']==method and t['parameter']==parameter and t['seed']==seed for t in out['training']): continue
                    t = trial(a.dataset,seed,method,parameter,a.inputs,a.existing,a.output,False)
                    out['training'].append(t); save(dest,out)
                    print(a.dataset,'train',method,parameter,seed,'seconds',round(t['seconds'],2),flush=True)
        selected = out.get('selection',{}); options = []
        for method, grid in grids.items():
            choices = []
            for parameter in grid:
                ts = [t for t in out['training'] if t['method']==method and t['parameter']==parameter]
                assert len(ts)==len(train)
                rs = [r for t in ts for r in t['rows']]
                choices.append(dict(method=method,parameter=parameter,
                    rate=float(np.mean([r['empirical']['max_violation']>1e-6 for r in rs])),
                    normalized_excess=float(np.mean([r['normalized_excess'] for r in rs])),
                    utility=float(np.mean([t['rows'][-1]['pooled']['welfare'] for t in ts]))))
            feasible = [c for c in choices if c['rate']<=.05]
            best = max(feasible,key=lambda c:c['utility']) if feasible else min(choices,key=lambda c:(c['rate'],c['normalized_excess'],-c['utility']))
            selected[method] = best['parameter']; options += choices
        out.update(selection=selected,options=options); save(dest,out)
    if a.phase in ('all','test'):
        methods = dict(out.get('selection',{}))
        if 'joint_pg' in methods: methods['joint_pg_certificate']=methods['joint_pg']
        if 'fairco_batch' in methods: methods['fairco_certificate']=methods['fairco_batch']
        if a.dataset=='kuairand' and a.method is None: methods.update(conic=None,certified=None)
        if a.method in ('conic','certified'): methods = {a.method:None}
        for method,parameter in methods.items():
            for seed in test:
                if any(t['method']==method and t['seed']==seed for t in out['test']): continue
                t = trial(a.dataset,seed,method,parameter,a.inputs,a.existing,a.output,True)
                out['test'].append(t); save(dest,out)
                print(a.dataset,'test',method,parameter,seed,'seconds',round(t['seconds'],2),flush=True)


if __name__ == '__main__':
    main()
