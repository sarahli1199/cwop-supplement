"""Recompute both exposure outcomes from saved plans and the original sampling seeds.

Usage: python experiments/replay_exposure_outcomes.py --artifact PATH
PATH is the artifact directory in this ICDE supplement.
No optimizer is rerun. No new simulated experiment or alternative seed is introduced.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import math
import zipfile
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
TOL = 1e-6
METHODS = ('temperature', 'logshare', 'fairco_batch', 'fw_penalty', 'conic', 'certified')
LABELS = {'temperature': 'Temperature', 'logshare': 'Log-share',
          'fairco_batch': 'FairCo-style batch', 'fw_penalty': 'Two-sided batch FW',
          'conic': 'Conic reference, no margin', 'certified': 'Conic reference + certificate'}

def entropy(x):
    term = np.zeros_like(x)
    positive = x > 0
    term[positive] = x[positive] * np.log(x[positive])
    return -term.sum(axis=1)

def metrics(counts, utility, degrees, target):
    sizes = counts.sum(axis=1)
    x = counts / sizes[:, None]
    rho = counts.sum(axis=0) / counts.sum()
    ent = entropy(x)
    hhi = float(rho @ rho)
    cap = float(rho.max())
    violations = [max(0., hhi-target['hhi']), max(0., cap-target['cap']),
                  max(0., target['entropy']-float(ent.min()))]
    return dict(hhi=hhi, max_share=cap, min_norm_entropy=float((ent/np.log(degrees)).min()),
                mean_norm_entropy=float((ent/np.log(degrees)).mean()),
                welfare=float((counts*np.where(np.isfinite(utility), utility, 0)).sum()/counts.sum()),
                hhi_violation=violations[0], cap_violation=violations[1],
                entropy_violation=violations[2], max_violation=max(violations))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--artifact', type=Path, required=True)
    parser.add_argument('--archive', type=Path, help='Optional delivered ZIP to supply its final checksum manifest')
    args = parser.parse_args()
    artifact = args.artifact.resolve()
    inputs = {}
    if args.archive:
        with zipfile.ZipFile(args.archive) as archive:
            manifest = json.loads(archive.read('INPUT_SHA256.json'))
    else:
        manifest = json.loads((artifact/'INPUT_SHA256.json').read_text())

    def verified(path):
        key = str(path.relative_to(artifact))
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        assert manifest[key] == digest, key
        inputs[key] = digest

    all_rows = []
    summaries = {}
    max_error = 0.
    trajectory_count = 0
    for dataset, n, seeds in [('synthetic', 20000, set(range(20260910,20260915))),
                              ('lastfm', 100000, set(range(20260920,20260923)))]:
        path = artifact/'results'/f'unified_feedback_{dataset}.json'
        verified(path)
        data = json.loads(path.read_text())
        assert len(data['test']) == len(METHODS)*len(seeds)
        for trial in data['test']:
            assert trial['seed'] in seeds and trial['N'] == n
            assert trial['method'] in METHODS and len(trial['rows']) == 20
            plan_path = artifact/'results'/trial['plans']
            verified(plan_path)
            with np.load(plan_path, allow_pickle=False) as saved:
                q, mask, utility, plans = (saved[k] for k in ('q','mask','utility','plans'))
            degrees = mask.sum(axis=1)
            assert np.all(degrees == degrees[0])
            target = trial['targets']
            floor = target['entropy']/math.log(int(degrees[0]))
            assert abs(floor-.65) < 1e-12
            if dataset == 'synthetic':
                assert target['hhi'] == .055 and target['cap'] == .08
            pooled = np.zeros_like(utility)
            for j, (x, row) in enumerate(zip(plans, trial['rows'])):
                assert row['window'] == j+1
                rng = np.random.default_rng(np.random.SeedSequence([trial['seed'], j, 92203]))
                sizes = rng.multinomial(n, q)
                assert sizes.min() > 0
                counts = np.zeros_like(x)
                for u in range(len(q)):
                    ix = np.flatnonzero(mask[u])
                    counts[u, ix] = rng.multinomial(sizes[u], x[u, ix]/x[u, ix].sum())
                    # Consume the click draws, preserving the original RNG sequence.
                    rng.binomial(counts[u, ix].astype(int), utility[u, ix])
                pooled += counts
                empirical = metrics(counts, utility, degrees, target)
                pool_metrics = metrics(pooled, utility, degrees, target)
                for label, result in [('empirical', empirical), ('pooled', pool_metrics)]:
                    for key, value in result.items():
                        err = abs(value-row[label][key])
                        max_error = max(max_error, err)
                        assert err < 1e-10, (dataset, trial['seed'], trial['method'], j, label, key, err)
                h_fail = empirical['hhi_violation'] > TOL
                c_fail = empirical['cap_violation'] > TOL
                e_fail = empirical['entropy_violation'] > TOL
                all_rows.append(dict(dataset=dataset, method=trial['method'], seed=trial['seed'],
                    window=j+1, requests=n, eta=target['hhi'], kappa=target['cap'], entropy_floor=floor,
                    hhi=empirical['hhi'], max_share=empirical['max_share'],
                    min_norm_entropy=empirical['min_norm_entropy'],
                    hhi_ratio=empirical['hhi']/target['hhi'], cap_ratio=empirical['max_share']/target['cap'],
                    hhi_failure=int(h_fail), cap_failure=int(c_fail),
                    global_failure=int(h_fail or c_fail), local_failure=int(e_fail),
                    any_failure=int(h_fail or c_fail or e_fail),
                    hhi_excess=empirical['hhi_violation'], cap_excess=empirical['cap_violation'],
                    entropy_deficit_nats=empirical['entropy_violation']))
            trajectory_count += 1
        summaries[dataset] = {}
        for method in METHODS:
            rows = [r for r in all_rows if r['dataset'] == dataset and r['method'] == method]
            assert len(rows) == 20*len(seeds)
            summaries[dataset][method] = dict(windows=len(rows),
                hhi_failures=sum(r['hhi_failure'] for r in rows),
                cap_failures=sum(r['cap_failure'] for r in rows),
                global_failures=sum(r['global_failure'] for r in rows),
                local_failures=sum(r['local_failure'] for r in rows),
                any_failures=sum(r['any_failure'] for r in rows),
                max_hhi_ratio=max(r['hhi_ratio'] for r in rows),
                max_cap_ratio=max(r['cap_ratio'] for r in rows),
                max_hhi=max(r['hhi'] for r in rows),
                max_share=max(r['max_share'] for r in rows),
                min_norm_entropy=min(r['min_norm_entropy'] for r in rows),
                max_hhi_excess=max(r['hhi_excess'] for r in rows),
                max_cap_excess=max(r['cap_excess'] for r in rows),
                max_entropy_deficit_nats=max(r['entropy_deficit_nats'] for r in rows))
            if method == 'certified':
                assert summaries[dataset][method]['any_failures'] == 0

    evidence = ROOT/'evidence'
    evidence.mkdir(exist_ok=True)
    report = dict(status='PASS', source_artifact='ICDE_CWOP_Supplement.zip',
        trajectories_replayed=trajectory_count, windows_replayed=len(all_rows),
        requests_replayed=sum(r['requests'] for r in all_rows),
        maximum_metric_discrepancy=max_error, violation_tolerance=TOL,
        numpy_version=np.__version__, input_sha256=inputs, summary=summaries)
    (evidence/'dual_outcomes_summary.json').write_text(json.dumps(report, indent=2)+'\n')
    with (evidence/'dual_outcomes_windows.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(all_rows[0]))
        writer.writeheader(); writer.writerows(all_rows)

    def table(methods, name, label, caption):
        lines = [r'\begin{table}[t]\centering\small', '\\caption{'+caption+'}',
                 '\\label{'+label+'}', r'\begin{tabular}{llrrrrr}', r'\toprule',
                 r'Data & Policy & HHI/$\eta$ & Share/$\kappa$ & $H/\log K$ & Global & Local \\', r'\midrule']
        for dataset in ('synthetic','lastfm'):
            for method in methods:
                s=summaries[dataset][method]
                policy = {'conic':'No margin','certified':'Certified'}.get(method,LABELS[method])
                lines.append(('Synthetic' if dataset=='synthetic' else 'Last.fm')+' & '+policy+
                    f" & ${s['max_hhi_ratio']:.3f}$ & ${s['max_cap_ratio']:.3f}$ & ${s['min_norm_entropy']:.3f}$"+
                    f" & ${s['global_failures']}/{s['windows']}$ & ${s['local_failures']}/{s['windows']}$"+r' \\')
            if dataset=='synthetic': lines.append(r'\midrule')
        lines += [r'\bottomrule',r'\end{tabular}',r'\end{table}']
        (ROOT/'latex'/name).write_text('\n'.join(lines)+'\n')

    print(json.dumps({k:v for k,v in report.items() if k not in ('input_sha256','summary')}, indent=2))
    for dataset in summaries:
        for method, s in summaries[dataset].items():
            print(dataset, method, json.dumps(s))

if __name__ == '__main__':
    main()
