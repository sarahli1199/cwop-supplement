"""Rerun six environments, independent constrained oracles and feasible baselines."""
import argparse
import numpy as np
from legacy_controller import make_environment, Targets, policy_metrics, greedy_policy, softmax_policy
from evaluation import RESULTS, Oracle, run_pd, repair, save_json, best_uniform_mixture, witness_certificate


def main(iterations):
    output = dict(protocol=dict(iterations=iterations, floor=1e-7, seeds=list(range(20260722,20260727))), instances=[])
    for seed in list(range(20260722,20260727))+[20260752]:
        stress = seed == 20260752
        env = make_environment(seed,48,72,30,8,8) if stress else make_environment(seed)
        target = Targets(2/72 if stress else .055, .04 if stress else .08, .65*np.log(30 if stress else 18))
        cert = witness_certificate(env, target)
        oracle = Oracle(env,target)
        xo, od = oracle.solve()
        xz, zd = Oracle(env,target,0.).solve()
        row = dict(seed=seed, stress=stress, witness=cert, oracle=od, oracle_without_floor=zd, policies={})
        save = dict(request_prob=env.request_prob, candidate_mask=env.candidate_mask, utility=env.utility, oracle=xo)
        if seed == 20260722:
            _, sd = oracle.solve(solver="SCS")
            row["second_solver"] = sd
        policies = {"greedy": greedy_policy(env,0.), "softmax_0.30":softmax_policy(env,.3,1e-7)}
        for name, global_c, local_c in [("global_pd",True,False),("local_pd",False,True),("joint_pd",True,True)]:
            xp, diag = run_pd(env,target,iterations,global_c,local_c)
            row["policies"][name] = dict(metrics=policy_metrics(env,xp,target), **diag)
            save[name] = xp
            if name == "joint_pd":
                xr, theta = repair(env,xp,target)
                row["policies"]["joint_repaired"] = dict(metrics=policy_metrics(env,xr,target), theta=theta,
                                oracle_gap=od["metrics"]["welfare"]-policy_metrics(env,xr,target)["welfare"])
                save["joint_repaired"] = xr
        # Feasible dual-sided non-PD reference, tuning is explicit per-instance upper envelope.
        mixrows=[]
        for temp in [0.01,.05,.1,.2,.3,.5,1.,2.]:
            xp, theta = best_uniform_mixture(env,softmax_policy(env,temp,1e-7),target)
            mixrows.append(dict(temperature=temp, theta=theta, **policy_metrics(env,xp,target)))
        row["feasible_softmax_envelope"] = mixrows
        row["best_feasible_softmax"] = max(mixrows,key=lambda a:a["welfare"])
        for name,x in policies.items():
            row["policies"][name] = dict(metrics=policy_metrics(env,x,target))
            save[name]=x
        if seed == 20260722:
            row["frontier"]=[]
            for h in [.3,.45,.55,.65,.75,.85]:
                tar = Targets(.055,.08,h*np.log(18))
                _, d=Oracle(env,tar).solve()
                row["frontier"].append(dict(entropy_floor=h, **d))
        np.savez_compressed(RESULTS/f"static_{seed}.npz",**save)
        output["instances"].append(row)
        save_json(RESULTS/"static.json",output)
        print(seed, "oracle",od["metrics"]["welfare"],"certificate gap",od["certified_gap"],
              "PD gap",row["policies"]["joint_repaired"]["oracle_gap"],flush=True)


if __name__=="__main__":
    p=argparse.ArgumentParser(); p.add_argument("--iterations",type=int,default=30000)
    main(p.parse_args().iterations)
