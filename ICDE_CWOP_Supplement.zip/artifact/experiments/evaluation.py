"""Independent convex oracle and shared, explicitly checked evaluation utilities."""
from __future__ import annotations

import json
import time
from pathlib import Path
import numpy as np
import cvxpy as cp
from scipy import sparse
from compact_controller import solve as compact_solve
from legacy_controller import (Environment, Targets, constraint_vector, entropy_rows,
                               policy_metrics, greedy_policy, primal_dual_cwop)

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
RESULTS.mkdir(exist_ok=True)


def save_json(path, obj):
    Path(path).write_text(json.dumps(obj, indent=2, allow_nan=False) + "\n")


def uniform(env):
    return env.candidate_mask / env.candidate_mask.sum(1, keepdims=True)


def residuals(env, x, target):
    h, c, e = constraint_vector(env, x, target)
    return np.r_[h, c, e]


def witness_certificate(env, target, floor=1e-7):
    x0 = uniform(env)
    delta = float(-residuals(env, x0, target).max())
    if delta <= 0:
        raise ValueError("uniform witness is not strictly feasible")
    w0 = policy_metrics(env, x0, target)["welfare"]
    wg = policy_metrics(env, greedy_policy(env, 0), target)["welfare"]
    b = float(x0[env.candidate_mask].min())
    return dict(delta=delta, witness_welfare=w0, greedy_welfare=wg,
                dual_l1_upper=(wg-w0)/delta,
                exploration_gap_upper=floor/b*(wg-w0), min_coordinate=b)


def repair(env, x, target, cushion=1e-10):
    """Checked segment repair, initialized by the proven sufficient mixing weight.

    Bisection reduces unnecessary mixing; it is not a projection onto the full set.
    """
    x = np.maximum(x, 0) * env.candidate_mask
    x /= x.sum(1, keepdims=True)
    x0 = uniform(env)
    delta = float(-residuals(env, x0, target).max())
    if delta <= cushion:
        raise ValueError("no strict witness for requested repair")
    v = max(0., float(residuals(env, x, target).max()))
    theta = min(1., (v+cushion)/(delta+v))
    low, high = 0., theta
    for _ in range(40):
        mid = (low+high)/2
        if residuals(env, (1-mid)*x+mid*x0, target).max() > -cushion:
            low=mid
        else:
            high=mid
    theta=high
    repaired = (1-theta)*x + theta*x0
    assert residuals(env, repaired, target).max() <= 5e-12
    return repaired, theta


class Oracle:
    """CVXPY conic model, distinct from the hand-written primal-dual solver.

    Stores only eligible edges (not all slates). Single-item actions only.
    The tangent dual upper bound is computed independently from returned duals.
    It is a floating-point certificate, not an interval-arithmetic proof.
    """
    def __init__(self, env, target, floor=1e-7):
        self.env, self.target, self.floor = env, target, floor
        self.ui, self.ci = np.where(env.candidate_mask)
        edges = len(self.ui)
        rows = sparse.csr_matrix((np.ones(edges), (self.ui, np.arange(edges))),
                                 shape=(env.users, edges))
        cols = sparse.csr_matrix((env.request_prob[self.ui], (self.ci, np.arange(edges))),
                                 shape=(env.creators, edges))
        self.x = cp.Variable(edges)
        self.r = cp.Parameter(edges)
        rho = cols @ self.x
        ent = rows @ cp.entr(self.x)
        self.cons = [rows @ self.x == 1, self.x >= floor,
                     cp.sum_squares(rho) <= target.hhi, rho <= target.cap,
                     ent >= target.entropy]
        self.problem = cp.Problem(cp.Maximize(self.r @ self.x), self.cons)

    def solve(self, utility=None, solver="CLARABEL"):
        utility = self.env.utility if utility is None else utility
        self.r.value = self.env.request_prob[self.ui] * utility[self.ui, self.ci]
        begin = time.perf_counter()
        if solver == "CLARABEL":
            self.problem.solve(solver=solver, tol_gap_abs=1e-10, tol_gap_rel=1e-10,
                               tol_feas=1e-10, max_iter=300, warm_start=True)
        else:
            self.problem.solve(solver=solver, eps=2e-7, max_iters=200000,
                               warm_start=False)
        elapsed = time.perf_counter()-begin
        if self.problem.status not in ("optimal", "optimal_inaccurate"):
            raise RuntimeError(self.problem.status)
        x = np.zeros_like(self.env.utility)
        x[self.ui, self.ci] = self.x.value
        env = Environment(self.env.request_prob, self.env.candidate_mask, utility)
        raw = policy_metrics(env, x, self.target)
        xr, theta = repair(env, x, self.target)
        # Strict positivity permits a valid tangent to entropy. Domain is X_floor.
        at = (1-1e-9)*xr + 1e-9*uniform(env)
        dual = np.r_[self.cons[2].dual_value, self.cons[3].dual_value,
                     self.cons[4].dual_value]
        dual = np.maximum(dual, 0)
        rho = env.request_prob @ at
        grad = env.request_prob[:, None]*(np.where(env.candidate_mask, utility, 0)
                 - 2*dual[0]*rho - dual[1:1+env.creators])
        grad += dual[1+env.creators:, None] * (-(np.log(np.maximum(at, 1e-300))+1))
        lag = policy_metrics(env, at, self.target)["welfare"]-dual@residuals(env, at, self.target)
        tangent = 0.
        for u in range(env.users):
            active = env.candidate_mask[u]
            gu = grad[u, active]
            tangent += self.floor*gu.sum()+(1-self.floor*len(gu))*gu.max()-gu@at[u, active]
        upper = float(lag+tangent)
        metrics = policy_metrics(env, xr, self.target)
        details = dict(solver=solver, status=self.problem.status, seconds=elapsed,
                       raw_metrics=raw, metrics=metrics, repair_theta=theta,
                       tangent_dual_upper=upper,
                       certified_gap=upper-metrics["welfare"],
                       max_constraint_dual=float(dual.max()),
                       dual_l1=float(dual.sum()))
        return xr, details


def run_pd(env, target, iterations=30000, global_control=True, local_control=True):
    cert = witness_certificate(env, target)
    bound = 100. if cert["dual_l1_upper"] < 90 else float(np.ceil(cert["dual_l1_upper"]/100)*100)
    x, history, diag = compact_solve(env, target, iterations, 1e-7, .75,
                    5. if global_control and not local_control else 1.25,
                    bound, global_control, local_control, max(1, iterations//100))
    return x, dict(history=history, diagnostics=diag, dual_bound=bound, witness=cert)


def best_uniform_mixture(env, x, target):
    """Best feasible point on the segment to uniform, via scalar bisection."""
    x0 = uniform(env)
    if residuals(env, x, target).max() <= 0:
        return x, 0.
    low, high = 0., 1.
    assert residuals(env, x0, target).max() < 0
    for _ in range(55):
        mid = (low+high)/2
        if residuals(env, (1-mid)*x+mid*x0, target).max() > -1e-10:
            low = mid
        else:
            high = mid
    return (1-high)*x+high*x0, high
