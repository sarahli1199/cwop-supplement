import unittest
import numpy as np
from legacy_controller import make_environment, Targets, Environment, greedy_policy, policy_metrics
from evaluation import Oracle, uniform, residuals, repair, witness_certificate
from run_feedback import fw_policy
from compact_controller import solve
from legacy_controller import primal_dual_cwop


class EvaluationTests(unittest.TestCase):
    def setUp(self):
        self.env=make_environment()
        self.target=Targets(.055,.08,.65*np.log(18))

    def test_repair(self):
        x=greedy_policy(self.env,0.)
        xr,t=repair(self.env,x,self.target)
        self.assertGreater(t,0)
        self.assertLessEqual(residuals(self.env,xr,self.target).max(),1e-12)
        np.testing.assert_allclose(xr.sum(1),1.)

    def test_dual_certificate(self):
        cert=witness_certificate(self.env,self.target)
        self.assertLess(cert['dual_l1_upper'],100)
        self.assertLess(cert['exploration_gap_upper'],1.6e-6)

    def test_oracle_and_translation(self):
        o=Oracle(self.env,self.target)
        x,d=o.solve()
        self.assertLess(d['certified_gap'],1e-5)
        self.assertLess(d['metrics']['max_violation'],1e-10)
        shifted=np.where(self.env.candidate_mask,self.env.utility+10,-np.inf)
        y,sd=o.solve(shifted)
        self.assertAlmostEqual(sd['metrics']['welfare']-d['metrics']['welfare'],10,places=6)
        self.assertGreaterEqual(d['tangent_dual_upper'],d['metrics']['welfare']-1e-10)

    def test_gradient_geometry(self):
        env=self.env; x=uniform(env); xi=np.linspace(.1,.2,1+env.creators+env.users)
        rho=env.request_prob@x
        gradient=env.request_prob[:,None]*(np.where(env.candidate_mask,env.utility,0)-2*xi[0]*rho-xi[1:1+env.creators])
        gradient+=xi[1+env.creators:,None]*(-np.log(np.maximum(x,1e-100))-1)
        def lag(p):
            return policy_metrics(env,p,self.target)['welfare']-xi@residuals(env,p,self.target)
        for u in (0,10,23):
            a,b=np.flatnonzero(env.candidate_mask[u])[:2]
            direction=np.zeros_like(x); direction[u,a]=1; direction[u,b]=-1
            numerical=(lag(x+1e-6*direction)-lag(x-1e-6*direction))/2e-6
            self.assertAlmostEqual(numerical,gradient[u,a]-gradient[u,b],places=7)

    def test_negative_exponent_drift(self):
        rng=np.random.default_rng(192)
        for a in (-10,-1,0):
            for _ in range(20):
                f=rng.integers(1,100,size=8); rho=f/f.sum(); pi=rho**a; pi/=pi.sum()
                self.assertLessEqual(rho@pi,1/8+1e-12)
                expected=sum(pi[i]*np.sum(((f+np.eye(8)[i])/(f.sum()+1)-1/8)**2) for i in range(8))
                bound=(f.sum()/(f.sum()+1))**2*np.sum((rho-1/8)**2)+(1-1/8)/(f.sum()+1)**2
                self.assertLessEqual(expected,bound+1e-12)

    def test_hhi_infinity_bound(self):
        rng=np.random.default_rng(1)
        for _ in range(100):
            a,b=rng.dirichlet(np.ones(50),size=2)
            self.assertLessEqual(abs(a@a-b@b),2*np.max(abs(a-b)))

    def test_compact_equivalent(self):
        args=(self.env,self.target,100,1e-7,.75,1.25,100,True,True,100)
        x,_,_=primal_dual_cwop(*args)
        y,_,_=solve(*args)
        np.testing.assert_allclose(x,y,rtol=1e-10,atol=1e-12)


if __name__=='__main__':
    unittest.main()
