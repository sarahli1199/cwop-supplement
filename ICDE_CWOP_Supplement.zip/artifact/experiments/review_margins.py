"""One-sided single-item serving certificate; no estimated/bootstrap quantiles."""
import numpy as np
from legacy_controller import Targets, make_environment, greedy_policy, policy_metrics
from evaluation import uniform, residuals, save_json, RESULTS

def margins(env, requests, windows=20, delta=.05, cap=.08):
    C, U = env.creators, env.users
    K = env.candidate_mask.sum(1)
    lc = np.log(5*windows*C/delta)
    lh = np.log(5*windows/delta)
    lu = np.log(5*windows*U/delta)
    mean = requests*env.request_prob
    lower = np.floor(mean-np.sqrt(2*mean*lu)).astype(int)
    cap_margin = np.sqrt(2*cap*lc/requests)+2*lc/(3*requests)
    hhi_margin = cap*np.sqrt(2*lh/requests)+(1+np.sqrt(lh))**2/requests
    if lower.min() < 3:
        ent = np.log(K)
    else:
        ent = np.minimum(np.log(K), np.log1p((K-1)/lower)
            +(np.log(lower)+1)*np.sqrt(lu/(2*lower)))
    return dict(hhi=float(hhi_margin), cap=float(cap_margin), entropy=ent.tolist(),
                lower_counts=lower.tolist(), count_condition=bool(lower.min()>=3),
                requests=requests, windows=windows, delta=delta)

def tightened(env, requests, windows=20, delta=.05):
    m=margins(env,requests,windows,delta)
    # Existing solver accepts a common entropy floor; take the worst type.
    target=Targets(.055-m['hhi'],.08-m['cap'],.65*np.log(18)+max(m['entropy']))
    return target,m

def slack_budget(env, target):
    base=Targets(.055,.08,.65*np.log(18))
    x0=uniform(env)
    slacks=-residuals(env,x0,base)
    reserve=np.r_[base.hhi-target.hhi,
                  np.full(env.creators,base.cap-target.cap),
                  np.full(env.users,target.entropy-base.entropy)]
    theta=float(np.max(reserve/slacks))
    w0=policy_metrics(env,x0,base)['welfare']
    wg=policy_metrics(env,greedy_policy(env,0),base)['welfare']
    return dict(theta=theta, sufficient_feasibility=bool(theta<=1),
                score_cost_upper=float(theta*(wg-w0)), witness_score=float(w0))

def main():
    env=make_environment(); x0=uniform(env)
    def feasible(n):
        target,m=tightened(env,n)
        return m['count_condition'] and residuals(env,x0,target).max()<=0
    lo,hi=1,2000000
    assert feasible(hi)
    while hi-lo>1:
        mid=(lo+hi)//2
        if feasible(mid): hi=mid
        else: lo=mid
    target,m=tightened(env,50000)
    # Uniform, valid norm bounds on the exact implementation's floored domain.
    eps=1e-7; B=100.; T=30000; gx=.75; gd=1.25
    K=env.candidate_mask.sum(1); q=env.request_prob
    utility=np.where(env.candidate_mask,np.abs(env.utility),0)
    per_edge=q[:,None]*(utility+3*B)+B*max(1.,abs(np.log(eps)+1))
    Gx2=float(np.sum(per_edge[env.candidate_mask]**2))
    Gd2=max(.055,1-.055)**2+env.creators*max(.08,1-.08)**2+float(np.sum(np.maximum(.65*np.log(18),np.log(K)-.65*np.log(18))**2))
    Dx2=float(np.sum(2*(1-K*eps)**2)); Dd2=(1+env.creators+env.users)*B**2
    bound=(Dx2/(2*gx)+gx*Gx2+Dd2/(2*gd)+gd*Gd2)/np.sqrt(T)
    result=dict(minimum_uniform_witness_requests=hi,
        at_10000=margins(env,10000), at_50000=m,
        uniform_budget_50000=slack_budget(env,target),
        optimization_bound=dict(T=T,B=B,epsilon=eps,Gx2=Gx2,Gdual2=Gd2,
                                Dx2=Dx2,Ddual2=Dd2,epsilon_T=float(bound)),
        protocol='Five one-sided event families, delta/5 each; Nq Chernoff lower counts; plug-in entropy bias and bounded differences.')
    save_json(RESULTS/'review_bounds.json',result)
    print(result,flush=True)

if __name__=='__main__': main()
