"""Prespecified FairCo certification and matched-history tradeoff diagnostics.

Supply locally generated matched experiment outputs with --results. No inputs or
numerical outputs are distributed with this code. The hybrid uses FairCo-style
batch scores, known merits, the existing training-selected lambda, and certified
segment repair only. Frozen-history sweeps do not simulate new feedback paths.
"""
from pathlib import Path
import argparse
import hashlib
import json
import time
import numpy as np
from legacy_controller import Environment, Targets, policy_metrics, greedy_policy
from evaluation import Oracle, uniform
from plan_safety import certificate, certified_mix, optimized_certificate, frozen_test

SETTINGS = [(1.5, .65), (1.5, .50), (2.0, .65), (2.0, .50), (2.5, .35)]
WINDOWS = [0, 9, 19]


def dump(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, allow_nan=False)+'\n')


def load_trial(results, trial):
    with np.load(results/trial['plans'], allow_pickle=False) as a:
        q, mask, utility, plans = [a[k].copy() for k in ['q', 'mask', 'utility', 'plans']]
    p = np.where(mask, utility, 0.)
    return q, mask, p, plans


def history_score(p, mask, f, affinity):
    score = p+.15*np.log(f/f.mean())+.1*np.log(np.maximum(
        affinity/(affinity.sum(1)/mask.sum(1))[:, None], 1e-300))
    return np.where(mask, score, -np.inf)


def serve(q, mask, p, x, seed, window, requests):
    rng = np.random.default_rng(np.random.SeedSequence([seed, window, 92203]))
    sizes = rng.multinomial(requests, q)
    assert sizes.min() > 0
    counts, hits = np.zeros_like(p), np.zeros_like(p)
    for u in range(len(q)):
        ix = np.flatnonzero(mask[u])
        counts[u, ix] = rng.multinomial(sizes[u], x[u, ix]/x[u, ix].sum())
        hits[u, ix] = rng.binomial(counts[u, ix].astype(int), p[u, ix])
    return sizes, counts, hits


def fairco_proposal(q, mask, p, score, exposure, parameter):
    merit = np.maximum(q@p, 1e-6)
    disparity = exposure.sum(0)/merit
    shaped = score+parameter*(disparity.max()-disparity)
    return greedy_policy(Environment(q, mask, shaped), 1e-7)


def hybrid(results, data, trial):
    q, mask, p, saved = load_trial(results, trial)
    target = Targets(**trial['targets'])
    f, affinity = np.ones(mask.shape[1]), mask.astype(float)
    exposure = np.zeros_like(p)
    rows = []
    start = time.perf_counter()
    for j in range(20):
        score = history_score(p, mask, f, affinity)
        env = Environment(q, mask, score)
        proposal = fairco_proposal(q, mask, p, score, exposure, trial['parameter'])
        x, detail = certified_mix(env, proposal, target, trial['N'])
        assert x is not None and certificate(env, x, target, trial['N'])['valid']
        sizes, counts, hits = serve(q, mask, p, x, trial['seed'], j, trial['N'])
        empirical = policy_metrics(Environment(sizes/trial['N'], mask, np.where(mask, p, -np.inf)),
                                   counts/sizes[:, None], target)
        f += hits.sum(0); affinity += hits; exposure += counts
        rows.append(dict(window=j+1, theta=detail['theta'], empirical=empirical,
                         certificate=detail['certificate']))
    total = exposure.sum(1)
    pooled = policy_metrics(Environment(total/total.sum(), mask, np.where(mask, p, -np.inf)),
                            exposure/total[:, None], target)
    return dict(dataset=trial['dataset'], seed=trial['seed'], parameter=trial['parameter'],
                N=trial['N'], J=20, delta=.05, targets=trial['targets'],
                method='fairco_plus_certificate', rows=rows, pooled=pooled,
                seconds=time.perf_counter()-start)


def frozen_histories(results, trial):
    q, mask, p, plans = load_trial(results, trial)
    f, affinity = np.ones(mask.shape[1]), mask.astype(float)
    exposure = np.zeros_like(p)
    target = Targets(**trial['targets'])
    for j, x in enumerate(plans):
        score = history_score(p, mask, f, affinity)
        env = Environment(q, mask, score)
        np.testing.assert_allclose(policy_metrics(env, x, target)['welfare'],
                                   trial['rows'][j]['score'], rtol=1e-12, atol=1e-12)
        if j in WINDOWS:
            yield j, env, p, x
        sizes, counts, hits = serve(q, mask, p, x, trial['seed'], j, trial['N'])
        met = policy_metrics(Environment(sizes/trial['N'], mask, np.where(mask, p, -np.inf)),
                             counts/sizes[:, None], target)
        for k, v in met.items():
            np.testing.assert_allclose(v, trial['rows'][j]['empirical'][k], rtol=1e-10, atol=1e-12)
        f += hits.sum(0); affinity += hits; exposure += counts


def frozen_case(trial, j, env, p, old_certified, setting_index):
    factor, entropy_fraction = SETTINGS[setting_index]
    witness = uniform(env); rho0 = env.request_prob@witness
    k = env.candidate_mask.sum(1)
    assert np.all(k == k[0])
    target = Targets(factor*(rho0@rho0), factor*rho0.max(), entropy_fraction*np.log(k[0]))
    base, optimization = Oracle(env, target).solve()
    if setting_index == 0:
        x = old_certified.copy()
        construction = 'saved certified plan on exactly replayed history'
    else:
        x, detail = optimized_certificate(env, target, trial['N'], base=base)
        construction = 'checked conic reoptimization'
    assert x is not None
    cert = certificate(env, x, target, trial['N'])
    assert cert['valid']
    wg = policy_metrics(env, greedy_policy(env, 0), target)['welfare']
    wc = policy_metrics(env, base, target)['welfare']
    wz = policy_metrics(env, x, target)['welfare']
    assert wg > 0 and wg >= wc-1e-8 and wc >= wz-1e-8
    intrinsic = Environment(env.request_prob, env.candidate_mask, np.where(env.candidate_mask, p, -np.inf))
    best_response = policy_metrics(intrinsic, greedy_policy(intrinsic, 0), target)['welfare']
    test = frozen_test(env, x, target, trial['N'], repetitions=100,
                       seed=trial['seed']+10000+100*j+setting_index)
    return dict(seed=trial['seed'], window=j+1, factor=factor, entropy_fraction=entropy_fraction,
                construction=construction, greedy_score=wg, conic_score=wc, certified_score=wz,
                target_cost_fraction=(wg-wc)/wg, certification_cost_fraction=(wc-wz)/wg,
                total_cost_fraction=(wg-wz)/wg, conic_score_ratio=wc/wg,
                certified_score_ratio=wz/wg,
                intrinsic_utility_ratio=policy_metrics(intrinsic, x, target)['welfare']/best_response,
                conic_intrinsic_utility_ratio=policy_metrics(intrinsic, base, target)['welfare']/best_response,
                optimization=optimization, certificate=cert, frozen_test=test)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--phase', choices=['hybrid', 'frozen'], required=True)
    parser.add_argument('--seed', type=int, help='Optional Last.fm split for independent jobs.')
    args = parser.parse_args()
    data = {d: json.loads((args.results/f'unified_feedback_{d}.json').read_text())
            for d in ['synthetic', 'lastfm']}
    out = json.loads(args.output.read_text()) if args.output.exists() else {
        'phase': args.phase, 'settings': SETTINGS, 'frozen_windows': [j+1 for j in WINDOWS],
        'scope': 'Hybrid: new feedback trajectories. Sweep: frozen histories from saved certified Last.fm trajectories.',
        'input_sha256': {}, 'rows': []}
    for d in data:
        path = args.results/f'unified_feedback_{d}.json'
        out['input_sha256'][path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
    for d, records in data.items():
        for trial in records['test']:
            if args.seed is not None and trial['seed'] != args.seed: continue
            desired = 'fairco_batch' if args.phase == 'hybrid' else 'certified'
            if trial['method'] != desired or (args.phase == 'frozen' and d != 'lastfm'): continue
            path = args.results/trial['plans']
            out['input_sha256'][path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
            if args.phase == 'hybrid':
                if any(r['dataset']==d and r['seed']==trial['seed'] for r in out['rows']): continue
                row = hybrid(args.results, records, trial)
                out['rows'].append(row); dump(args.output, out)
                print('hybrid', d, trial['seed'], 'utility', row['pooled']['welfare'],
                      'failures', sum(r['empirical']['max_violation']>1e-6 for r in row['rows']), flush=True)
            else:
                for j, env, p, saved in frozen_histories(args.results, trial):
                    for si, setting in enumerate(SETTINGS):
                        if any(r['seed']==trial['seed'] and r['window']==j+1 and
                               [r['factor'], r['entropy_fraction']]==list(setting) for r in out['rows']): continue
                        row = frozen_case(trial, j, env, p, saved, si)
                        out['rows'].append(row); dump(args.output, out)
                        print('frozen', trial['seed'], j+1, setting, 'score', row['certified_score_ratio'],
                              'response', row['intrinsic_utility_ratio'], flush=True)
    dump(args.output, out)


if __name__ == '__main__':
    main()
