"""Independent checks of the unified protocol and the uniform-envelope lemma."""
import json
import numpy as np
from evaluation import RESULTS,uniform,residuals
from legacy_controller import Environment,Targets,make_environment,policy_metrics
from plan_safety import certificate,uniform_envelope,witness_cost,frozen_test
from run_unified_safety import compact_fw,run_trial,GRIDS
from run_feedback import fw_policy


def main():
    env=make_environment();target=Targets(.055,.08,.65*np.log(18))
    assert np.max(np.abs(compact_fw(env,.3,100)-fw_policy(env,.3,100)))<1e-12
    rng=np.random.default_rng(8414)
    for N in (20000,50000,100000):
        envelope=uniform_envelope(env,target,N)
        upper=np.r_[envelope['hhi'],envelope['cap'],envelope['entropy']]
        for _ in range(100):
            x=uniform(env)+rng.uniform(0,.1)*(np.where(env.candidate_mask,rng.uniform(size=env.utility.shape),0)-uniform(env))
            x/=x.sum(1,keepdims=True)
            assert residuals(env,x,target).max()<0
            m=certificate(env,x,target,N)
            assert np.max(np.r_[m['hhi'],m['cap'],m['entropy']]-upper)<1e-12
    e=Environment(np.ones(1),np.ones((1,2),bool),np.ones((1,2)))
    zero=certificate(e,np.array([[1.,0.]]),Targets(1.,1.,0.),10000)
    assert zero['entropy_linear']==[None] and np.isfinite(zero['entropy'][0])
    checked=certified=replications=0
    for dataset in ('synthetic','lastfm'):
        data=json.loads((RESULTS/f'unified_feedback_{dataset}.json').read_text())
        assert len(data['training'])==2*sum(map(len,GRIDS.values()))
        assert len(data['test'])==(30 if dataset=='synthetic' else 18)
        trainseeds={t['seed'] for t in data['training']};testseeds={t['seed'] for t in data['test']}
        assert not trainseeds&testseeds
        # Recompute the training-only selection from raw per-window results.
        for method in GRIDS:
            options=[]
            for parameter in GRIDS[method]:
                ts=[t for t in data['training'] if t['method']==method and t['parameter']==parameter]
                rows=[r for t in ts for r in t['rows']]
                options.append((parameter,np.mean([r['empirical']['max_violation']>1e-6 for r in rows]),
                                np.mean([r['normalized_excess'] for r in rows]),
                                np.mean([t['rows'][-1]['pooled']['welfare'] for t in ts])))
            feasible=[o for o in options if o[1]<=.05]
            selected=max(feasible,key=lambda o:o[3]) if feasible else min(options,key=lambda o:(o[1],o[2],-o[3]))
            assert selected[0]==data['selection'][method]
        for t in data['test']:
            a=np.load(RESULTS/t['plans']);e=Environment(a['q'],a['mask'],a['utility']);tg=Targets(**t['targets'])
            assert t['N']==(20000 if dataset=='synthetic' else 100000)
            if t['method']=='fw_penalty':assert t['fw_iterations']==10000
            for x,row in zip(a['plans'],t['rows']):
                assert abs(x.sum(1)-1).max()<1e-9 and x.min()>=-1e-12
                assert (x[~e.candidate_mask]==0).all()
                pm=policy_metrics(e,x,tg)
                for key in ('welfare','hhi','max_share','min_norm_entropy'):
                    assert abs(pm[key]-row['planned'][key])<1e-10
                if t['method'] in ('conic','certified'):assert residuals(e,x,tg).max()<1e-8
                if t['method']=='certified':
                    c=certificate(e,x,tg,t['N']);assert c['valid']
                    assert abs(c['max_certified_excess']-row['safety']['certificate']['max_certified_excess'])<1e-10
                    assert row['score']>=row['safety']['segment_score']-1e-10
                    lower=row['safety']['uniform_envelope_lower_bound']
                    if lower is not None:assert row['score']>=lower-1e-9
                    # Failed optional refinement retains the already-certified plan.
                    certified+=1
                checked+=1
        assert len(data['calibration'])==40
        for r in data['calibration']:
            assert r['repetitions']==2000
            assert 0<=r['failures']<=r['repetitions']
            replications+=r['repetitions']
        first=min(testseeds);window=10 if dataset=='synthetic' else 1
        t=next(t for t in data['test'] if t['seed']==first and t['method']=='certified')
        saved=next(r for r in data['calibration'] if r['method']=='certified' and r['window']==window)
        a=np.load(RESULTS/t['plans']);e=Environment(a['q'],a['mask'],a['utility'])
        again=frozen_test(e,a['plans'][window-1],Targets(**t['targets']),t['N'],2000,seed=saved['seed'])
        assert again['failures']==saved['failures'] and again['by_constraint']==saved['by_constraint']
        assert abs(again['one_sided_95_upper']-saved['one_sided_95_upper'])<1e-12
    # Entire adaptive certified trajectory, not just algebra on saved margins.
    actual=run_trial('synthetic',20260910,'certified')
    saved=json.loads((RESULTS/'unified_feedback_synthetic.json').read_text())
    expected=next(t for t in saved['test'] if t['seed']==20260910 and t['method']=='certified')
    for a,b in zip(actual['rows'],expected['rows']):
        assert abs(a['score']-b['score'])<1e-8
        assert abs(a['pooled']['welfare']-b['pooled']['welfare'])<1e-8
    print(f'PASS: uniform envelope, zero-support fallback, FW equivalence, disjoint training-only tuning; {checked} policies ({certified} certified), {replications} frozen replications; full certified-trajectory rerun.')


if __name__=='__main__':main()
