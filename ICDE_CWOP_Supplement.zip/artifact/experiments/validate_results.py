"""Recompute every saved static/artist policy metric; optionally rerun a feedback seed."""
import argparse
import json
import numpy as np
from legacy_controller import Environment,Targets,policy_metrics
from evaluation import ROOT,RESULTS

def compare(a,b,tol=1e-9):
    for k in a:
        assert abs(a[k]-b[k])<=tol,(k,a[k],b[k])

def main(rerun):
    static=json.loads((RESULTS/'static.json').read_text())
    for r in static['instances']:
        z=np.load(RESULTS/f"static_{r['seed']}.npz",allow_pickle=False)
        env=Environment(z['request_prob'],z['candidate_mask'],z['utility'])
        target=Targets(2/72,.04,.65*np.log(30)) if r['stress'] else Targets(.055,.08,.65*np.log(18))
        for name,p in r['policies'].items():
            compare(policy_metrics(env,z[name],target),p['metrics'])
            np.testing.assert_allclose(z[name].sum(1),1.,atol=1e-10)
        compare(policy_metrics(env,z['oracle'],target),r['oracle']['metrics'])
        assert 0<=r['oracle']['certified_gap']<2.2e-5
        assert r['policies']['joint_repaired']['metrics']['max_violation']<=1e-10
    real=json.loads((RESULTS/'lastfm.json').read_text())
    for r in real['instances']:
        z=np.load(RESULTS/f"lastfm_{r['seed']}.npz",allow_pickle=False)
        env=Environment(z['request_prob'],z['candidate_mask'],z['utility'])
        target=Targets(**r['targets'])
        for name in ('raw','repaired'):
            compare(policy_metrics(env,z[name],target),r[name])
        compare(policy_metrics(env,z['oracle'],target),r['oracle']['metrics'])
        assert 0<=r['oracle']['certified_gap']<8.01e-5
        assert r['repaired']['max_violation']<=1e-10
        assert r['pd']['dual_bound']>r['pd']['witness']['dual_l1_upper']
    feedback=json.loads((RESULTS/'feedback.json').read_text())
    assert len(feedback['trials'])==50
    assert len({(r['seed'],r['method']) for r in feedback['trials']})==50
    for r in feedback['trials']:
        assert len(r['rows'])==20
        for v in r['rows']:
            for kind in ('planned','empirical','pooled'):
                m=v[kind]
                assert -1e-10<=m['welfare']<=1+1e-10 and 1/36-1e-10<=m['hhi']<=1+1e-10
                assert 0<=m['min_norm_entropy']<=1+1e-10
                expected=max(0,m['hhi']-.055,m['max_share']-.08,(.65-m['min_norm_entropy'])*np.log(18))
                assert abs(m['max_violation']-expected)<1e-10
            if r['method'] in ('cwop','cwop_safe','oracle'):
                assert v['planned']['max_violation']<=1e-10
    if rerun:
        from run_feedback import trial
        original=next(r for r in feedback['trials'] if r['seed']==20260910 and r['method']=='cwop_safe')
        new=trial(20260910,'cwop_safe',pd_iterations=10000)
        for a,b in zip(original['rows'],new['rows']):
            for kind in ('planned','empirical','pooled'):
                compare(a[kind],b[kind],1e-9)
        print('Full feedback seed reproduced.')
    print('PASS: all saved policy metrics, reference gaps, dual bounds, and feedback residuals.')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--rerun-feedback',action='store_true')
    main(p.parse_args().rerun_feedback)
