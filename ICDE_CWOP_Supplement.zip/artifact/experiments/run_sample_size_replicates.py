"""Repeat the fixed-score sample-size construction on the five saved base graphs.

Error bars describe between-graph variability, not conditional serving risk.
Original refined_curves.json and all existing results are kept unchanged.
"""
import hashlib
import json
import platform
import time
import numpy as np
from legacy_controller import Environment, Targets, policy_metrics
from evaluation import RESULTS, Oracle, uniform, residuals, save_json
from plan_safety import margins, witness_cost, optimized_certificate, certificate

SEEDS=list(range(20260722,20260727))
SIZES=[5082,10000,12338,20000,50000,100000,200000]
TARGET=Targets(.055,.08,.65*np.log(18))
METHODS=['common','per_type','policy_specific']


def run():
    trials=[]
    output=RESULTS/'sample_size_replicates.json'
    for seed in SEEDS:
        source=RESULTS/f'static_{seed}.npz'
        with np.load(source) as a:
            env=Environment(a['request_prob'],a['candidate_mask'],a['utility'])
        x0=uniform(env)
        base,details=Oracle(env,TARGET).solve()
        w0=policy_metrics(env,x0,TARGET)['welfare']
        wref=details['metrics']['welfare']
        policies={'request_prob':env.request_prob,'candidate_mask':env.candidate_mask,
                  'utility':env.utility,'reference':base}
        rows=[]
        for N in SIZES:
            m=margins(env,x0,N,policy_specific=False,cap=TARGET.cap)
            budget=witness_cost(env,TARGET,m)
            targets={
                'common':Targets(TARGET.hhi-m['hhi'],TARGET.cap-max(m['cap']),TARGET.entropy+max(m['entropy'])),
                'per_type':Targets(TARGET.hhi-m['hhi'],TARGET.cap-max(m['cap']),TARGET.entropy+np.array(m['entropy']))}
            row={'N':N,'theta':budget['theta'],'methods':{}}
            for method,tight in targets.items():
                if residuals(env,x0,tight).max()>=-1e-8:
                    row['methods'][method]={'available':False,'reason':'No strict uniform witness for this construction.'}
                    continue
                x,di=Oracle(env,tight).solve()
                assert residuals(env,x,tight).max()<=1e-8
                policies[f'{method}_{N}']=x
                score=di['metrics']['welfare']
                row['methods'][method]={'available':True,'score':score,'Q':(score-w0)/(wref-w0),
                    'solver_status':di['status'],'max_tightened_residual':float(residuals(env,x,tight).max())}
            x,di=optimized_certificate(env,TARGET,N,base=base)
            if x is None:
                row['methods']['policy_specific']={'available':False,'reason':'No checked policy-specific construction.'}
            else:
                cert=certificate(env,x,TARGET,N)
                assert cert['valid']
                policies[f'policy_specific_{N}']=x
                score=policy_metrics(env,x,TARGET)['welfare']
                row['methods']['policy_specific']={'available':True,'score':score,'Q':(score-w0)/(wref-w0),
                    'max_certified_excess':cert['max_certified_excess'],
                    'refinement_attempts':di.get('refinement_attempts',[])}
            rows.append(row)
            print(f'seed={seed} N={N} available='+','.join(k for k,v in row['methods'].items() if v['available']),flush=True)
        filename=f'sample_size_replicates_{seed}.npz'
        np.savez_compressed(RESULTS/filename,**policies)
        trials.append({'seed':seed,'source_file':source.name,
            'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
            'policies':filename,'witness_score':w0,'reference_score':wref,'rows':rows})
        save_json(output,{'status':'in_progress','trials':trials})
    summary=[]
    for i,N in enumerate(SIZES):
        theta=np.array([t['rows'][i]['theta'] for t in trials])
        row={'N':N,'theta':{'n':len(theta),'mean':float(theta.mean()),'sd':float(theta.std(ddof=1))},'methods':{}}
        for method in METHODS:
            values=[t['rows'][i]['methods'][method]['Q'] for t in trials if t['rows'][i]['methods'][method]['available']]
            complete=len(values)==len(SEEDS)
            row['methods'][method]={'n':len(values),'plotted':complete,
                'mean':float(np.mean(values)) if complete else None,
                'sd':float(np.std(values,ddof=1)) if complete else None}
        summary.append(row)
    save_json(output,{'status':'complete','protocol':{
        'seeds':SEEDS,'N':SIZES,'reference_window':20000,'windows':20,'delta':.05,
        'targets':{'hhi':.055,'cap':.08,'entropy':float(TARGET.entropy)},
        'error_bars':'Sample standard deviation across five independently generated, saved synthetic graphs (ddof=1).',
        'normalization':'Q is normalized by each graph\u2019s own witness-to-conic score gap before aggregation.',
        'missing_points':'Q is plotted only when the construction is available on all five graphs; unavailable is not globally infeasible.',
        'scope':'Between-graph variability in fixed-score constructions; not Monte Carlo serving-risk confidence intervals.',
        'python':platform.python_version(),'numpy':np.__version__},'trials':trials,'summary':summary})
    print('Saved five-graph sample-size results and mean +/- one sample SD.',flush=True)


if __name__=='__main__':
    run()
