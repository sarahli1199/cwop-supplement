"""Independently replay new public-feed/PG trials and check analytic margins."""
from pathlib import Path
import argparse
import json
import hashlib
import numpy as np
from summarize_margin_budgets import independent_margins


def entropy(x):
    return -np.sum(x*np.log(np.maximum(x, 1e-300)), axis=1)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--results',type=Path,required=True)
    p.add_argument('--inputs',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--dataset',choices=['synthetic','lastfm','kuairand'])
    a=p.parse_args(); report={'status':'PASS','datasets':{}}
    # Independent central differences for all logit coordinates, with active
    # concentration, share, and entropy penalties on a small heterogeneous graph.
    from joint_policy_gradient import objective_gradient
    from legacy_controller import Targets
    rng=np.random.default_rng(57);users,creators,degree=5,9,6
    edges=np.array([rng.choice(creators,degree,replace=False) for _ in range(users)])
    qtest=np.full(users,1/users);scores=rng.normal(size=(users,degree))
    logits=rng.normal(size=(users,degree));target=Targets(.13,.17,.95*np.log(degree))
    _,gradient,_=objective_gradient(logits,scores,qtest,edges,creators,target,3.)
    errors=[]
    for u in range(users):
        for c in range(degree):
            perturb=np.zeros_like(logits);perturb[u,c]=1e-6
            plus=objective_gradient(logits+perturb,scores,qtest,edges,creators,target,3.)[0]
            minus=objective_gradient(logits-perturb,scores,qtest,edges,creators,target,3.)[0]
            errors.append(abs((plus-minus)/2e-6-gradient[u,c]))
    assert max(errors)<1e-7
    report['policy_gradient_finite_difference_error']=max(errors)
    user_sets=[]
    for seed in [20261110,20261111,20261120,20261121,20261122]:
        arr=np.load(a.inputs/f'kuairand_{seed}.npz',allow_pickle=False)
        user_sets.append(set(arr['public_user_ids'].tolist()))
    assert len(set.union(*user_sets))==sum(map(len,user_sets))==640
    for dataset in ([a.dataset] if a.dataset else ['synthetic','lastfm','kuairand']):
        path=a.results/f'reviewer_{dataset}.json';data=json.loads(path.read_text())
        train_seeds=set(t['seed'] for t in data['training'])
        test_seeds=set(t['seed'] for t in data['test'])
        assert train_seeds.isdisjoint(test_seeds)
        for method,selected in data['selection'].items():
            options=[]
            for parameter in sorted({t['parameter'] for t in data['training'] if t['method']==method}):
                trials=[t for t in data['training'] if t['method']==method and t['parameter']==parameter]
                assert len(trials)==2
                rows=[r for t in trials for r in t['rows']]
                options.append((parameter,np.mean([r['empirical']['max_violation']>1e-6 for r in rows]),
                    np.mean([r['normalized_excess'] for r in rows]),
                    np.mean([t['rows'][-1]['pooled']['welfare'] for t in trials])))
            feasible=[c for c in options if c[1]<=.05]
            best=max(feasible,key=lambda c:c[3]) if feasible else min(options,key=lambda c:(c[1],c[2],-c[3]))
            assert best[0]==selected
        seen=set(); windows=0; certified=0; max_difference=0.
        for t in data['test']:
            key=(t['method'],t['seed']);assert key not in seen;seen.add(key)
            arr=np.load(a.results/t['plans'],allow_pickle=False)
            q,mask,plans=arr['q'],arr['mask'],arr['plans'];utility=np.where(mask,arr['utility'],0)
            k=mask.sum(1);N=t['N'];target=t['targets'];U,C=mask.shape
            assert len(plans)==len(t['rows'])==20
            if dataset=='kuairand':
                source=a.inputs/t['provenance']['file']
                assert hashlib.sha256(source.read_bytes()).hexdigest()==t['provenance']['sha256']
            f=np.ones(C);affinity=mask.astype(float);exposure=np.zeros_like(utility)
            for j,(x,row) in enumerate(zip(plans,t['rows'])):
                np.testing.assert_allclose(x.sum(1),1,atol=1e-12)
                assert np.all(x>=0) and np.all(x[~mask]==0)
                score=utility+.15*np.log(f/f.mean())+.1*np.log(np.maximum(affinity/(affinity.sum(1)/k)[:,None],1e-300))
                score_value=float(np.sum(q[:,None]*x*score))
                np.testing.assert_allclose(score_value,row['score'],rtol=1e-10,atol=1e-11)
                if row['safety'] is not None:
                    mh,mc,mu,counts=independent_margins(q,mask,x,N)
                    rho=q@x; excess=max(rho@rho+mh-target['hhi'],
                        max(rho+mc-target['cap']),max(target['entropy']+mu-entropy(x)))
                    assert excess<=1e-10,(dataset,key,j,excess)
                    stored=row['safety']['certificate']
                    for v,z in [(mh,stored['hhi']),(mc,stored['cap']),(mu,stored['entropy'])]:
                        np.testing.assert_allclose(v,z,rtol=1e-10,atol=1e-12)
                    certified+=1
                rng=np.random.default_rng(np.random.SeedSequence([t['seed'],j,92203]))
                sizes=rng.multinomial(N,q);counts=np.zeros_like(utility);hits=np.zeros_like(utility)
                for u in range(U):
                    ix=np.flatnonzero(mask[u]);probs=x[u,ix]/x[u,ix].sum()
                    counts[u,ix]=rng.multinomial(sizes[u],probs)
                    hits[u,ix]=rng.binomial(counts[u,ix].astype(int),utility[u,ix])
                exposure+=counts;f+=hits.sum(0);affinity+=hits
                rho=counts.sum(0)/N;H=entropy(counts/sizes[:,None])
                vals={'hhi':float(rho@rho),'max_share':float(rho.max()),
                      'min_norm_entropy':float(np.min(H/np.log(k))),
                      'welfare':float(np.sum(counts*utility)/N),
                      'max_violation':float(max(0.,rho@rho-target['hhi'],rho.max()-target['cap'],target['entropy']-H.min()))}
                for field,value in vals.items():
                    np.testing.assert_allclose(value,row['empirical'][field],rtol=1e-9,atol=1e-11)
                    max_difference=max(max_difference,abs(value-row['empirical'][field]))
                pooled=float(np.sum(exposure*utility)/exposure.sum())
                np.testing.assert_allclose(pooled,row['pooled']['welfare'],rtol=1e-10,atol=1e-11)
                windows+=1
        expected=(10 if dataset=='synthetic' else 6 if dataset=='lastfm' else 27)
        assert len(data['test'])==expected,(dataset,len(data['test']))
        report['datasets'][dataset]=dict(trials=len(seen),replayed_windows=windows,
            checked_certificates=certified,maximum_metric_difference=max_difference,
            training_selection_verified=True,source_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))


if __name__=='__main__':main()
