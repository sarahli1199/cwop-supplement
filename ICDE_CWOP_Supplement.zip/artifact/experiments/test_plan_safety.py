"""Algebra, independent probability calculations, and output-certificate checks."""
import json
import numpy as np
from scipy.stats import binom,norm
from evaluation import RESULTS,uniform,residuals
from legacy_controller import make_environment,Targets,Environment
from plan_safety import certificate,frozen_test

def main():
    rng=np.random.default_rng(9031)
    for _ in range(100):
        p=rng.dirichlet(np.ones(8));phat=rng.multinomial(100,p)/100
        H=lambda a: -np.sum(a*np.log(np.maximum(a,1e-300)))
        kl=np.sum(phat*np.log(np.maximum(phat,1e-300)/p))
        assert abs(H(p)-H(phat)-(phat-p)@np.log(p)-kl)<1e-12
        rho=rng.dirichlet(np.ones(12));hat=rng.multinomial(100,rho)/100;e=hat-rho
        assert abs(hat@hat-rho@rho-2*rho@e-e@e)<1e-12
    # CLT prediction, including the lattice correction, checked against exact binomial.
    kappa=.08;N=1000000
    for z in (0.,1.,2.):
        p=kappa-z*np.sqrt(kappa*(1-kappa)/N)
        tail=binom.sf(int(N*kappa),N,p)
        assert abs(tail-norm.sf(z))<.002
    # Frozen categorical test agrees with binomial cap sampling in a two-item model.
    env=Environment(np.ones(1),np.ones((1,2),bool),np.ones((1,2)))
    x=np.array([[.6,.4]]);target=Targets(1.,.6,0.)
    got=frozen_test(env,x,target,1000,repetitions=10000,seed=114)
    expected=binom.sf(600,1000,.6)+binom.cdf(399,1000,.6)
    assert abs(got['rate']-expected)<.02
    checked=0
    for dataset in ('synthetic','lastfm'):
        path=RESULTS/f'refined_feedback_{dataset}.json'
        if not path.exists():continue
        data=json.loads(path.read_text())
        for t in data['trials']:
            a=np.load(RESULTS/t['plans']);env=Environment(a['q'],a['mask'],a['utility'])
            if dataset=='synthetic':target=Targets(.055,.08,.65*np.log(18))
            else:
                rho=env.request_prob@uniform(env)
                target=Targets(1.5*(rho@rho),1.5*rho.max(),.65*np.log(64))
            for x,row in zip(a['plans'],t['rows']):
                assert np.max(np.abs(x.sum(1)-1))<1e-10
                assert residuals(env,x,target).max()<1e-8
                if t['method']=='conic_certified':
                    cert=certificate(env,x,target,t['N'])
                    assert cert['valid']
                    assert abs(cert['max_certified_excess']-row['safety']['certificate']['max_certified_excess'])<1e-10
                checked+=1
    print(f'PASS: entropy and HHI identities; exact binomial CLT check; multinomial simulator; {checked} saved policies')

if __name__=='__main__':main()
