"""Validate added review results against trial-level outputs, without rerunning them."""
import json
import numpy as np
from evaluation import RESULTS
from run_review_experiments import violation
from review_margins import tightened
from legacy_controller import make_environment

def read(name):
    return json.loads((RESULTS/name).read_text())

def main():
    baseline=read('review_baselines.json')['trials']
    margin=read('review_margins.json')['trials']
    original=read('feedback.json')['trials']
    diagnostic=read('review_same_state.json')['trials']
    tuning=read('review_tuning.json')
    assert len(baseline)==115 and len(margin)==40 and len(diagnostic)==5
    assert len(tuning['trials'])==46
    assert len({(t['seed'],t['method'],t['parameter']) for t in baseline})==115
    for trial in baseline+margin+diagnostic:
        assert trial['seed'] in range(20260910,20260915)
        assert len(trial['rows'])==20
        for row in trial['rows']:
            for kind in ('planned','empirical','pooled'):
                m=row[kind]
                assert -1e-9<=m['welfare']<=1+1e-9 and 1/36-1e-9<=m['hhi']<=1+1e-9
                residual=max(0,m['hhi']-.055,m['max_share']-.08,
                             (.65-m['min_norm_entropy'])*np.log(18))
                assert abs(residual-m['max_violation'])<1e-10
    for method,param in tuning['selection'].items():
        choices=[]
        for p in sorted({t['parameter'] for t in tuning['trials'] if t['method']==method}):
            tr=[t for t in tuning['trials'] if t['method']==method and t['parameter']==p]
            assert {t['seed'] for t in tr}=={20260901,20260902}
            rate=np.mean([violation(r) for t in tr for r in t['rows']])
            utility=np.mean([t['rows'][-1]['pooled']['welfare'] for t in tr])
            choices.append((p,rate,utility))
        eligible=[c for c in choices if c[1]<=.05]
        best=max(eligible,key=lambda c:c[2]) if eligible else min(choices,key=lambda c:(c[1],-c[2]))
        assert best[0]==param
    for trial in margin:
        env=make_environment(trial['seed'])
        if 'certified' in trial['method']:
            target,cert=tightened(env,50000)
            assert trial['requests']==50000 and cert==trial['certificate']
            hhi,cap,entropy=target.hhi,target.cap,target.entropy
        else:
            t=trial['parameter']
            hhi,cap,entropy=.055-.005*t,.08-.01*t,(.65+.07*t)*np.log(18)
        for row in trial['rows']:
            m=row['planned']
            assert max(m['hhi']-hhi,m['max_share']-cap,
                       entropy-m['min_norm_entropy']*np.log(18))<=1e-9
            assert row['safety_cost_budget']['sufficient_feasibility']
        if 'certified' in trial['method'] or trial['parameter']==1.:
            assert not any(violation(r) for r in trial['rows'])
    for trial in diagnostic:
        previous=next(t for t in original if t['seed']==trial['seed'] and t['method']=='cwop')
        for new,old in zip(trial['rows'],previous['rows']):
            for kind in ('planned','empirical','pooled'):
                for key,value in old[kind].items():
                    np.testing.assert_allclose(new[kind][key],value,rtol=0,atol=1e-9)
            assert new['same_state_oracle_gap']>=-1e-8
    gaps=[r['same_state_oracle_gap'] for t in diagnostic for r in t['rows']]
    reported=read('review_summary.json')
    np.testing.assert_allclose(np.mean(gaps),reported['same_state_gap']['mean'],atol=1e-12)
    assert read('review_bounds.json')['minimum_uniform_witness_requests']==12338
    print('PASS: 115 baseline, 40 margin and 5 diagnostic trials; training-only selection; tightened planned feasibility; identical frozen-state CWOP trajectories.')

if __name__=='__main__':
    main()
