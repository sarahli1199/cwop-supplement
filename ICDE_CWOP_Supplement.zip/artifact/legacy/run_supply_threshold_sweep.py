#!/usr/bin/env python3
"""Parallel finite-horizon supply-side threshold sweep with Wilson intervals."""

from __future__ import annotations

import argparse
import csv
import math
import multiprocessing as mp
import os
import sys
import time
from pathlib import Path

# The core simulator is shipped beside this script; no Downloads dependency.


def parse_list(value: str, cast):
    return [cast(part.strip()) for part in value.split(",") if part.strip()]


def mean_sd(values: list[float]) -> tuple[float, float]:
    mean = sum(values) / len(values)
    if len(values) == 1:
        return mean, 0.0
    variance = sum((value - mean) ** 2 for value in values) / (len(values) - 1)
    return mean, math.sqrt(variance)


def wilson(successes: int, n: int, z: float = 1.959963984540054) -> tuple[float, float]:
    p = successes / n
    denominator = 1.0 + z * z / n
    center = (p + z * z / (2.0 * n)) / denominator
    half = z * math.sqrt(p * (1.0 - p) / n + z * z / (4.0 * n * n)) / denominator
    return center - half, center + half


def simulate_task(task: tuple[float, float, float, int, int, float, int]) -> dict:
    beta, tau, q, creators, steps, lam, seed = task
    from two_state_threshold_simulation import simulate_two_state

    return simulate_two_state(
        beta=beta,
        lam=lam,
        tau=tau,
        q=q,
        mode="proportional",
        creators=creators,
        steps=steps,
        seed=seed,
    )


def main() -> None:
    project = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=project / "data/supply_threshold_sweep.csv")
    parser.add_argument("--beta", type=float, default=1.35)
    parser.add_argument("--tau", type=float, default=1.0)
    parser.add_argument("--q", type=float, default=0.2)
    parser.add_argument("--creators", type=int, default=500)
    parser.add_argument("--steps", default="50000,200000,1000000")
    parser.add_argument("--lambda-ratios", default="0,0.1,0.2,0.3,0.4,0.5,0.65,0.8,1")
    parser.add_argument("--seeds", type=int, default=60)
    parser.add_argument("--seed-offset", type=int, default=2026072100)
    parser.add_argument("--workers", type=int, default=max(1, min(8, os.cpu_count() or 1)))
    args = parser.parse_args()

    steps_list = parse_list(args.steps, int)
    ratios = parse_list(args.lambda_ratios, float)
    lambda_star = args.tau * (args.beta - 1.0)
    rows: list[dict[str, float | int]] = []
    started = time.time()

    context = mp.get_context("spawn")
    with context.Pool(processes=args.workers) as pool:
        for steps in steps_list:
            for ratio in ratios:
                lam = ratio * lambda_star
                tasks = [
                    (args.beta, args.tau, args.q, args.creators, steps, lam, args.seed_offset + seed)
                    for seed in range(args.seeds)
                ]
                run_rows = pool.map(simulate_task, tasks)
                hhi_mean, hhi_sd = mean_sd([float(row["hhi"]) for row in run_rows])
                top1_mean, top1_sd = mean_sd([float(row["top1_share"]) for row in run_rows])
                gini_mean, gini_sd = mean_sd([float(row["gini"]) for row in run_rows])
                ratio_mean, ratio_sd = mean_sd(
                    [float(row["global_pop_exposure_ratio"]) for row in run_rows]
                )
                collapse03 = sum(bool(row["collapsed_top1_03"]) for row in run_rows)
                collapse05 = sum(bool(row["collapsed_top1_05"]) for row in run_rows)
                collapse07 = sum(bool(row["collapsed_top1_07"]) for row in run_rows)
                ci05 = wilson(collapse05, args.seeds)
                rows.append(
                    {
                        "beta": args.beta,
                        "tau": args.tau,
                        "q": args.q,
                        "lambda_star": lambda_star,
                        "lambda": lam,
                        "lambda_over_star": ratio,
                        "beta_eff_asym": args.beta - lam / args.tau,
                        "creators": args.creators,
                        "steps": steps,
                        "allocations_per_creator": steps / args.creators,
                        "seeds": args.seeds,
                        "hhi_mean": hhi_mean,
                        "hhi_sd": hhi_sd,
                        "top1_mean": top1_mean,
                        "top1_sd": top1_sd,
                        "gini_mean": gini_mean,
                        "gini_sd": gini_sd,
                        "collapse_count_top1_03": collapse03,
                        "collapse_fraction_top1_03": collapse03 / args.seeds,
                        "collapse_count_top1_05": collapse05,
                        "collapse_fraction_top1_05": collapse05 / args.seeds,
                        "collapse_top1_05_wilson_low": ci05[0],
                        "collapse_top1_05_wilson_high": ci05[1],
                        "collapse_count_top1_07": collapse07,
                        "collapse_fraction_top1_07": collapse07 / args.seeds,
                        "global_pop_exposure_ratio_mean": ratio_mean,
                        "global_pop_exposure_ratio_sd": ratio_sd,
                    }
                )
                print(
                    f"supply T={steps:,} lambda/lambda*={ratio:.2f}: "
                    f"collapse={collapse05/args.seeds:.3f} "
                    f"CI=[{ci05[0]:.3f},{ci05[1]:.3f}] "
                    f"elapsed={time.time()-started:.1f}s",
                    flush=True,
                )

    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print(f"wrote {args.out}")


if __name__ == "__main__":
    main()
