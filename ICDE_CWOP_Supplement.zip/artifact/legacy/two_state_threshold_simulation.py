import argparse
import csv
import json
import math
import os
import random
import time
from collections import defaultdict


class Fenwick:
    def __init__(self, values):
        self.n = len(values)
        self.bit = [0.0] * (self.n + 1)
        for i, value in enumerate(values):
            self.add(i, value)

    def add(self, index, delta):
        i = index + 1
        while i <= self.n:
            self.bit[i] += delta
            i += i & -i

    def total(self):
        return self.prefix_sum(self.n - 1)

    def prefix_sum(self, index):
        i = index + 1
        out = 0.0
        while i > 0:
            out += self.bit[i]
            i -= i & -i
        return out

    def find_prefix(self, target):
        idx = 0
        bit_mask = 1 << (self.n.bit_length() - 1)
        while bit_mask:
            nxt = idx + bit_mask
            if nxt <= self.n and self.bit[nxt] < target:
                target -= self.bit[nxt]
                idx = nxt
            bit_mask >>= 1
        return min(idx, self.n - 1)


def gini(values):
    x = sorted(float(v) for v in values)
    total = sum(x)
    n = len(x)
    if n == 0 or total <= 0:
        return None
    weighted = sum((i + 1) * v for i, v in enumerate(x))
    return (2.0 * weighted / (n * total)) - ((n + 1.0) / n)


def simulate_two_state(beta, lam, tau, q, mode, creators, steps, seed, pop_sigma=1.0, floor=1e-300):
    """Two-state reinforced process.

    exposure[c] is the fast flow being allocated and penalized.
    popularity[c] is the slow stock driving attachment.

    Selection uses
        w_c = popularity_c^beta * exposure_c^(-lambda/tau).

    In proportional mode, popularity increases by one with probability q after a
    creator is served. In static mode, popularity is fixed heterogeneous quality.
    """
    rng = random.Random(seed)
    exposure = [1.0] * creators
    if mode == "static":
        popularity = [math.exp(rng.gauss(0.0, pop_sigma)) for _ in range(creators)]
    elif mode == "proportional":
        popularity = [1.0] * creators
    else:
        raise ValueError(f"Unknown mode: {mode}")

    exp_exponent = -lam / tau

    def weight(i):
        return max(floor, (popularity[i] ** beta) * (exposure[i] ** exp_exponent))

    weights = [weight(i) for i in range(creators)]
    tree = Fenwick(weights)
    conversions = 0

    for _ in range(steps):
        draw = rng.random() * tree.total()
        idx = tree.find_prefix(draw)
        old_weight = weights[idx]
        exposure[idx] += 1.0
        if mode == "proportional" and rng.random() < q:
            popularity[idx] += 1.0
            conversions += 1
        new_weight = weight(idx)
        weights[idx] = new_weight
        tree.add(idx, new_weight - old_weight)

    total_exposure = sum(exposure)
    shares = [x / total_exposure for x in exposure]
    hhi = sum(s * s for s in shares)
    top1 = max(shares)
    entropy = -sum(s * math.log(s) for s in shares if s > 0)
    global_pop_exposure_ratio = sum(popularity) / total_exposure
    active_ratios = [popularity[i] / exposure[i] for i in range(creators) if exposure[i] >= 10.0]
    active_ratio_mean = sum(active_ratios) / len(active_ratios) if active_ratios else None

    return {
        "hhi": hhi,
        "top1_share": top1,
        "entropy": entropy,
        "gini": gini(shares),
        "eff_creators": 1.0 / hhi if hhi > 0 else None,
        "global_pop_exposure_ratio": global_pop_exposure_ratio,
        "active_pop_exposure_ratio": active_ratio_mean,
        "active_ratio_n": len(active_ratios),
        "conversions": conversions,
        "collapsed_hhi_025": hhi >= 0.25,
        "collapsed_top1_03": top1 >= 0.3,
        "collapsed_top1_05": top1 >= 0.5,
        "collapsed_top1_07": top1 >= 0.7,
    }


def lambda_grid(beta, tau, preset):
    lam_star = tau * (beta - 1.0)
    if beta <= 1.0:
        return [0.0, 0.05 * tau, 0.15 * tau, 0.30 * tau, 0.60 * tau]
    if preset == "paper":
        ratios = [0.0, 0.25, 0.50, 0.75, 0.90, 0.97, 1.00, 1.03, 1.10, 1.25, 1.50, 2.00]
    else:
        ratios = [0.0, 0.50, 0.90, 1.00, 1.10, 1.50, 2.00]
    return [max(0.0, lam_star * r) for r in ratios]


def summarize(values):
    vals = [v for v in values if v is not None]
    n = len(vals)
    if n == 0:
        return None, None
    mean = sum(vals) / n
    if n == 1:
        return mean, 0.0
    var = sum((v - mean) ** 2 for v in vals) / (n - 1)
    return mean, math.sqrt(var)


def run_sweep(args):
    rows = []
    start = time.time()
    total_runs = 0
    for mode in args.modes:
        q_values = args.qs if mode == "proportional" else [1.0]
        for q in q_values:
            for beta in args.betas:
                for tau in args.taus:
                    for lam in lambda_grid(beta, tau, args.preset):
                        run_rows = []
                        for seed in range(args.seeds):
                            run_rows.append(
                                simulate_two_state(
                                    beta=beta,
                                    lam=lam,
                                    tau=tau,
                                    q=q,
                                    mode=mode,
                                    creators=args.creators,
                                    steps=args.steps,
                                    seed=args.seed_offset + seed,
                                    pop_sigma=args.pop_sigma,
                                )
                            )
                            total_runs += 1
                        hhi_mean, hhi_sd = summarize([r["hhi"] for r in run_rows])
                        top1_mean, top1_sd = summarize([r["top1_share"] for r in run_rows])
                        entropy_mean, entropy_sd = summarize([r["entropy"] for r in run_rows])
                        gini_mean, gini_sd = summarize([r["gini"] for r in run_rows])
                        global_ratio_mean, global_ratio_sd = summarize(
                            [r["global_pop_exposure_ratio"] for r in run_rows]
                        )
                        active_ratio_mean, active_ratio_sd = summarize(
                            [r["active_pop_exposure_ratio"] for r in run_rows]
                        )
                        beta_eff_asym = beta - lam / tau
                        rows.append(
                            {
                                "mode": mode,
                                "q": q,
                                "beta": beta,
                                "tau": tau,
                                "lambda": lam,
                                "lambda_star": tau * (beta - 1.0),
                                "lambda_over_star": (lam / (tau * (beta - 1.0))) if beta > 1 else "",
                                "beta_eff_asym": beta_eff_asym,
                                "creators": args.creators,
                                "steps": args.steps,
                                "seeds": args.seeds,
                                "hhi_mean": hhi_mean,
                                "hhi_sd": hhi_sd,
                                "top1_mean": top1_mean,
                                "top1_sd": top1_sd,
                                "entropy_mean": entropy_mean,
                                "entropy_sd": entropy_sd,
                                "gini_mean": gini_mean,
                                "gini_sd": gini_sd,
                                "global_pop_exposure_ratio_mean": global_ratio_mean,
                                "global_pop_exposure_ratio_sd": global_ratio_sd,
                                "active_pop_exposure_ratio_mean": active_ratio_mean,
                                "active_pop_exposure_ratio_sd": active_ratio_sd,
                                "collapse_fraction_hhi_025": sum(r["collapsed_hhi_025"] for r in run_rows)
                                / len(run_rows),
                                "collapse_fraction_top1_03": sum(r["collapsed_top1_03"] for r in run_rows)
                                / len(run_rows),
                                "collapse_fraction_top1_05": sum(r["collapsed_top1_05"] for r in run_rows)
                                / len(run_rows),
                                "collapse_fraction_top1_07": sum(r["collapsed_top1_07"] for r in run_rows)
                                / len(run_rows),
                            }
                        )
                        print(
                            json.dumps(
                                {
                                    "event": "sweep",
                                    "mode": mode,
                                    "q": q,
                                    "beta": beta,
                                    "tau": tau,
                                    "lambda": round(lam, 5),
                                    "beta_eff": round(beta_eff_asym, 5),
                                    "hhi_mean": round(hhi_mean, 5),
                                    "top1": round(top1_mean, 5),
                                    "collapse_top1_05": rows[-1]["collapse_fraction_top1_05"],
                                    "global_ratio": round(global_ratio_mean, 5),
                                    "runs": total_runs,
                                    "elapsed_sec": round(time.time() - start, 1),
                                }
                            ),
                            flush=True,
                        )
    return rows


def threshold_neighborhood(rows):
    grouped = defaultdict(list)
    for row in rows:
        grouped[(row["mode"], row["q"], row["beta"], row["tau"])].append(row)
    out = []
    for (mode, q, beta, tau), group in sorted(grouped.items(), key=lambda item: str(item[0])):
        group = sorted(group, key=lambda r: r["lambda"])
        star = tau * (beta - 1.0)
        below = [r for r in group if star > 0 and r["lambda"] < star]
        above = [r for r in group if r["lambda"] >= star]
        below_row = max(below, key=lambda r: r["lambda"]) if below else None
        above_row = min(above, key=lambda r: r["lambda"]) if above else None
        if star <= 0 and group:
            above_row = min(group, key=lambda r: abs(r["lambda"]))
        out.append(
            {
                "mode": mode,
                "q": q,
                "beta": beta,
                "tau": tau,
                "lambda_star": star,
                "lambda_below": below_row["lambda"] if below_row else None,
                "beta_eff_below": below_row["beta_eff_asym"] if below_row else None,
                "hhi_below": below_row["hhi_mean"] if below_row else None,
                "top1_below": below_row["top1_mean"] if below_row else None,
                "collapse_below": below_row["collapse_fraction_top1_05"] if below_row else None,
                "lambda_at_or_above": above_row["lambda"] if above_row else None,
                "beta_eff_at_or_above": above_row["beta_eff_asym"] if above_row else None,
                "hhi_at_or_above": above_row["hhi_mean"] if above_row else None,
                "top1_at_or_above": above_row["top1_mean"] if above_row else None,
                "collapse_at_or_above": above_row["collapse_fraction_top1_05"] if above_row else None,
            }
        )
    return out


def write_csv(path, rows):
    if not rows:
        return
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def plot_outputs(out_dir, rows):
    os.environ.setdefault("MPLCONFIGDIR", os.path.join(out_dir, "mplconfig"))
    os.makedirs(os.environ["MPLCONFIGDIR"], exist_ok=True)
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    for tau in sorted({r["tau"] for r in rows if r["mode"] == "proportional"}):
        for q in sorted({r["q"] for r in rows if r["mode"] == "proportional" and r["tau"] == tau}):
            fig, ax = plt.subplots(figsize=(7.0, 4.5))
            subset = [r for r in rows if r["mode"] == "proportional" and r["tau"] == tau and r["q"] == q]
            for beta in sorted({r["beta"] for r in subset}):
                group = sorted([r for r in subset if r["beta"] == beta], key=lambda r: r["lambda"])
                ax.plot(
                    [g["lambda"] for g in group],
                    [g["collapse_fraction_top1_05"] for g in group],
                    marker="o",
                    label=f"beta={beta:g}",
                )
                if beta > 1:
                    ax.axvline(tau * (beta - 1.0), linestyle="--", linewidth=0.8, alpha=0.45)
            ax.set_title(f"Two-State Collapse Fraction (q={q:g}, tau={tau:g})")
            ax.set_xlabel("lambda")
            ax.set_ylabel("fraction with top-1 share >= 0.5")
            ax.set_ylim(-0.03, 1.03)
            ax.grid(alpha=0.25)
            ax.legend()
            fig.tight_layout()
            fig.savefig(os.path.join(out_dir, f"twostate_collapse_q_{q:g}_tau_{tau:g}.png"), dpi=200)
            plt.close(fig)

    fig, ax = plt.subplots(figsize=(7.0, 4.5))
    for q in sorted({r["q"] for r in rows if r["mode"] == "proportional"}):
        group = sorted([r for r in rows if r["mode"] == "proportional" and r["q"] == q], key=lambda r: r["beta_eff_asym"])
        ax.scatter(
            [g["beta_eff_asym"] for g in group],
            [g["global_pop_exposure_ratio_mean"] for g in group],
            alpha=0.75,
            label=f"q={q:g}",
        )
        ax.axhline(q, linestyle=":", linewidth=0.8, alpha=0.5)
    ax.set_title("State Locking: Global Popularity/Exposure Ratio")
    ax.set_xlabel("asymptotic beta_eff = beta - lambda/tau")
    ax.set_ylabel("sum(popularity) / sum(exposure)")
    ax.grid(alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, "twostate_locking_global.png"), dpi=200)
    plt.close(fig)

    if any(r["mode"] == "static" for r in rows):
        for tau in sorted({r["tau"] for r in rows if r["mode"] == "static"}):
            fig, ax = plt.subplots(figsize=(7.0, 4.5))
            subset = [r for r in rows if r["mode"] == "static" and r["tau"] == tau]
            for beta in sorted({r["beta"] for r in subset}):
                group = sorted([r for r in subset if r["beta"] == beta], key=lambda r: r["lambda"])
                ax.plot([g["lambda"] for g in group], [g["hhi_mean"] for g in group], marker="s", label=f"beta={beta:g}")
            ax.set_title(f"Static-Popularity Contrast (tau={tau:g})")
            ax.set_xlabel("lambda")
            ax.set_ylabel("mean exposure HHI")
            ax.grid(alpha=0.25)
            ax.legend()
            fig.tight_layout()
            fig.savefig(os.path.join(out_dir, f"twostate_static_tau_{tau:g}.png"), dpi=200)
            plt.close(fig)


def write_markdown(path, args, rows, neighborhood):
    with open(path, "w", encoding="utf-8") as f:
        f.write("# Two-State Threshold Simulation\n\n")
        f.write("This simulation separates popularity from exposure. Popularity is the slow stock driving attachment; exposure is the fast flow penalized by log-share shaping.\n\n")
        f.write("Selection weight: `w_c = popularity_c^beta * exposure_c^(-lambda/tau)`.\n\n")
        f.write("## Configuration\n")
        for key in ["preset", "modes", "qs", "betas", "taus", "creators", "steps", "seeds", "pop_sigma"]:
            f.write(f"- `{key}`: `{getattr(args, key)}`\n")
        f.write("- RNG: Python `random.Random`, deterministic by integer seed.\n")
        f.write("- Collapse indicators: top-1 share >= 0.3/0.5/0.7 and HHI >= 0.25 are all saved in CSV.\n\n")
        f.write("## Threshold Neighborhood\n")
        f.write("| mode | q | beta | tau | lambda* | lambda below | beta_eff below | HHI below | top1 below | collapse below | lambda at/above | beta_eff at/above | HHI at/above | top1 at/above | collapse at/above |\n")
        f.write("|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|\n")

        def fmt(value, digits=4):
            return "" if value is None else f"{value:.{digits}f}"

        for row in neighborhood:
            f.write(
                f"| {row['mode']} | {row['q']:.3g} | {row['beta']:.3f} | {row['tau']:.3f} | "
                f"{fmt(row['lambda_star'])} | {fmt(row['lambda_below'])} | {fmt(row['beta_eff_below'])} | "
                f"{fmt(row['hhi_below'])} | {fmt(row['top1_below'])} | {fmt(row['collapse_below'])} | "
                f"{fmt(row['lambda_at_or_above'])} | {fmt(row['beta_eff_at_or_above'])} | "
                f"{fmt(row['hhi_at_or_above'])} | {fmt(row['top1_at_or_above'])} | {fmt(row['collapse_at_or_above'])} |\n"
            )
        f.write("\n## Interpretation Notes\n")
        f.write("- In proportional mode, the global popularity/exposure ratio should approach q as T grows.\n")
        f.write("- Small q delays finite-time collapse even when the asymptotic exponent is above 1.\n")
        f.write("- Static mode is a contrast: popularity is fixed quality, so exposure-driven runaway should be suppressed.\n")


def parse_float_list(value):
    return [float(v.strip()) for v in value.split(",") if v.strip()]


def parse_str_list(value):
    return [v.strip() for v in value.split(",") if v.strip()]


def apply_preset(args):
    if args.preset == "paper":
        args.creators = args.creators or 500
        args.steps = args.steps or 200_000
        args.seeds = args.seeds or 20
        args.betas = args.betas or [0.835, 1.10, 1.35, 1.60]
        args.taus = args.taus or [0.5, 1.0]
        args.qs = args.qs or [1.0, 0.3, 0.1]
        args.modes = args.modes or ["proportional", "static"]
    else:
        args.creators = args.creators or 200
        args.steps = args.steps or 50_000
        args.seeds = args.seeds or 8
        args.betas = args.betas or [0.835, 1.35]
        args.taus = args.taus or [1.0]
        args.qs = args.qs or [1.0, 0.2]
        args.modes = args.modes or ["proportional", "static"]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--preset", choices=["smoke", "paper"], default="smoke")
    parser.add_argument("--out-dir", default="two_state_experiments")
    parser.add_argument("--creators", type=int)
    parser.add_argument("--steps", type=int)
    parser.add_argument("--seeds", type=int)
    parser.add_argument("--betas", type=parse_float_list)
    parser.add_argument("--taus", type=parse_float_list)
    parser.add_argument("--qs", type=parse_float_list)
    parser.add_argument("--modes", type=parse_str_list)
    parser.add_argument("--pop-sigma", type=float, default=1.0, dest="pop_sigma")
    parser.add_argument("--seed-offset", type=int, default=0)
    args = parser.parse_args()
    apply_preset(args)

    os.makedirs(args.out_dir, exist_ok=True)
    rows = run_sweep(args)
    neighborhood = threshold_neighborhood(rows)
    write_csv(os.path.join(args.out_dir, "two_state_sweep.csv"), rows)
    write_csv(os.path.join(args.out_dir, "two_state_neighborhood.csv"), neighborhood)
    plot_outputs(args.out_dir, rows)
    write_markdown(os.path.join(args.out_dir, "two_state_report.md"), args, rows, neighborhood)
    print(json.dumps({"event": "done", "out_dir": args.out_dir}))


if __name__ == "__main__":
    main()
