#!/usr/bin/env python3
"""Run the controlled demand-side entropy recovery sweep used in Figure 5.

The supply experiment has K=500 creators at T={50k, 200k, 1M}.  The demand
experiment has M=50 creator options and matches the normalized horizon T/K, giving
T={5k, 20k, 100k}.  Both use the same two-state reinforced process and the
same beta, tau, q, lambda/lambda* grid, so the panels compare equivalent
allocations per option rather than unequal maturity.
"""

from __future__ import annotations

import argparse
import csv
import math
import multiprocessing as mp
import os
import sys
import time
from pathlib import Path

# The core simulator is shipped beside this script; no Downloads dependency.


def parse_list(value: str, cast):
    return [cast(part.strip()) for part in value.split(",") if part.strip()]


def mean_sd(values: list[float]) -> tuple[float, float]:
    mean = sum(values) / len(values)
    if len(values) == 1:
        return mean, 0.0
    variance = sum((value - mean) ** 2 for value in values) / (len(values) - 1)
    return mean, math.sqrt(variance)


def simulate_task(task: tuple[float, float, float, int, int, float, int]) -> dict:
    beta, tau, q, topics, steps, lam, seed = task
    from two_state_threshold_simulation import simulate_two_state

    return simulate_two_state(
        beta=beta,
        lam=lam,
        tau=tau,
        q=q,
        mode="proportional",
        creators=topics,
        steps=steps,
        seed=seed,
    )


def run_condition_grid(
    pool,
    beta: float,
    tau: float,
    q: float,
    topics: int,
    steps_list: list[int],
    lambdas_and_ratios: list[tuple[float, float | str]],
    seeds: int,
    seed_offset: int,
    started: float,
) -> list[dict[str, float | int | str]]:
    rows: list[dict[str, float | int | str]] = []
    lambda_star = tau * (beta - 1.0)
    for steps in steps_list:
        for lam, ratio in lambdas_and_ratios:
            tasks = [
                (beta, tau, q, topics, steps, lam, seed_offset + seed)
                for seed in range(seeds)
            ]
            run_rows = pool.map(simulate_task, tasks)
            normalized_entropy = [row["entropy"] / math.log(topics) for row in run_rows]
            entropy_mean, entropy_sd = mean_sd(normalized_entropy)
            hhi_mean, hhi_sd = mean_sd([row["hhi"] for row in run_rows])
            low_entropy_count = sum(value <= 0.5 for value in normalized_entropy)
            rows.append(
                {
                    "beta": beta,
                    "tau": tau,
                    "q": q,
                    "lambda_star": lambda_star,
                    "lambda": lam,
                    "lambda_over_star": ratio,
                    "topics": topics,
                    "steps": steps,
                    "allocations_per_option": steps / topics,
                    "seeds": seeds,
                    "normalized_entropy_mean": entropy_mean,
                    "normalized_entropy_sd": entropy_sd,
                    "hhi_mean": hhi_mean,
                    "hhi_sd": hhi_sd,
                    "low_entropy_count": low_entropy_count,
                    "low_entropy_fraction": low_entropy_count / seeds,
                }
            )
            print(
                f"demand beta={beta:.2f} T={steps} lambda={lam:.4f}: "
                f"H/Hmax={entropy_mean:.4f}, low-H={low_entropy_count/seeds:.3f}, "
                f"elapsed={time.time() - started:.1f}s",
                flush=True,
            )
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--beta", type=float, default=1.35)
    parser.add_argument("--tau", type=float, default=1.0)
    parser.add_argument("--q", type=float, default=0.2)
    parser.add_argument("--topics", type=int, default=50)
    parser.add_argument("--steps", default="5000,20000,100000")
    parser.add_argument("--lambda-ratios", default="0,0.1,0.2,0.3,0.4,0.5,0.65,0.8,1")
    parser.add_argument("--seeds", type=int, default=60)
    parser.add_argument("--seed-offset", type=int, default=20260721)
    parser.add_argument("--workers", type=int, default=max(1, min(8, os.cpu_count() or 1)))
    parser.add_argument("--linear-out", type=Path)
    parser.add_argument("--linear-steps", type=int, default=100000)
    parser.add_argument("--linear-lambdas", default="0,0.05")
    parser.add_argument("--linear-seeds", type=int, default=100)
    args = parser.parse_args()

    steps_list = parse_list(args.steps, int)
    ratios = parse_list(args.lambda_ratios, float)
    lambda_star = args.tau * (args.beta - 1.0)
    started = time.time()
    context = mp.get_context("spawn")
    with context.Pool(processes=args.workers) as pool:
        rows = run_condition_grid(
            pool,
            args.beta,
            args.tau,
            args.q,
            args.topics,
            steps_list,
            [(ratio * lambda_star, ratio) for ratio in ratios],
            args.seeds,
            args.seed_offset,
            started,
        )

        if args.linear_out:
            linear_lambdas = parse_list(args.linear_lambdas, float)
            linear_rows = run_condition_grid(
                pool,
                1.0,
                args.tau,
                args.q,
                args.topics,
                [args.linear_steps],
                [(lam, "boundary" if lam == 0 else "positive") for lam in linear_lambdas],
                args.linear_seeds,
                args.seed_offset + 10_000,
                started,
            )
            args.linear_out.parent.mkdir(parents=True, exist_ok=True)
            with args.linear_out.open("w", encoding="utf-8", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=list(linear_rows[0].keys()))
                writer.writeheader()
                writer.writerows(linear_rows)
            print(f"wrote {args.linear_out}")

    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    print(f"wrote {args.out}")


if __name__ == "__main__":
    main()
