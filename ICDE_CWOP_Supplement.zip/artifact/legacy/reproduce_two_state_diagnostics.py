#!/usr/bin/env python3
"""Rerun the exact two-state diagnostic conditions cited in the manuscript."""

from __future__ import annotations

import argparse
import json
import multiprocessing as mp
import sys
from pathlib import Path





def one(task: tuple[float, float, float, str, int]) -> dict:
    beta, lam, q, mode, seed = task
    from two_state_threshold_simulation import simulate_two_state

    return simulate_two_state(
        beta=beta,
        lam=lam,
        tau=1.0,
        q=q,
        mode=mode,
        creators=500,
        steps=200_000,
        seed=seed,
    )


def summary(rows: list[dict]) -> dict[str, float]:
    return {
        "hhi_mean": sum(float(row["hhi"]) for row in rows) / len(rows),
        "top1_mean": sum(float(row["top1_share"]) for row in rows) / len(rows),
        "collapse_fraction_top1_05": sum(bool(row["collapsed_top1_05"]) for row in rows)
        / len(rows),
    }


def main() -> None:
    project = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser()
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument(
        "--out", type=Path, default=project / "legacy/data/two_state_diagnostics_rerun.json"
    )
    args = parser.parse_args()

    conditions: list[tuple[str, float, float, float, str, int]] = [
        ("target_q1", 1.35, 0.0, 1.0, "proportional", 30),
        ("target_q02", 1.35, 0.0, 0.2, "proportional", 30),
        ("target_static", 1.35, 0.0, 1.0, "static", 30),
    ]
    for q in (1.0, 0.2):
        for lam in (0.0, 0.05, 0.15, 0.30, 0.60):
            conditions.append((f"linear_q{q:g}_lambda{lam:g}", 1.0, lam, q, "proportional", 50))

    output: dict[str, object] = {}
    with mp.get_context("spawn").Pool(args.workers) as pool:
        for name, beta, lam, q, mode, seeds in conditions:
            tasks = [(beta, lam, q, mode, seed) for seed in range(seeds)]
            output[name] = {
                "configuration": {
                    "beta": beta,
                    "lambda": lam,
                    "tau": 1.0,
                    "q": q,
                    "mode": mode,
                    "creators": 500,
                    "steps": 200_000,
                    "seeds": seeds,
                    "seed_offset": 0,
                },
                **summary(pool.map(one, tasks)),
            }

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
