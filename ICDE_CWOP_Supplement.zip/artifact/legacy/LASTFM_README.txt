HetRec 2011 Last.fm usage notice

Excerpt from the upstream README. Dataset statistics and example records are
omitted from this code-only release.

------- 
License
-------

   The users' names and other personal information in Last.fm are not provided in the dataset.

   The data contained in hetrec2011-lastfm-2k.zip is made available for non-commercial use.
   
   Those interested in using the data in a commercial context should contact Last.fm staff:
   http://www.lastfm.com/about/contact

----------------
Acknowledgements
----------------

   This work was supported by the Spanish Ministry of Science and Innovation (TIN2008-06566-C04-02), 
   and the Regional Government of Madrid (S2009TIC-1542).

----------
References
----------

   When using this dataset you should cite:
      - Last.fm website, http://www.lastfm.com

   You may also cite HetRec'11 workshop as follows:

   @inproceedings{Cantador:RecSys2011,
      author = {Cantador, Iv\'{a}n and Brusilovsky, Peter and Kuflik, Tsvi},
      title = {2nd Workshop on Information Heterogeneity and Fusion in Recommender Systems (HetRec 2011)},
      booktitle = {Proceedings of the 5th ACM conference on Recommender systems},
      series = {RecSys 2011},
      year = {2011},
      location = {Chicago, IL, USA},
      publisher = {ACM},
      address = {New York, NY, USA},
      keywords = {information heterogeneity, information integration, recommender systems},
   } 

-------
Credits
-------

   This dataset was built by Ignacio Fern�ndez-Tob�as with the collaboration of Iv�n Cantador and Alejandro Bellog�n, 
   members of the Information Retrieval group at Universidad Autonoma de Madrid (http://ir.ii.uam.es)

-------   
Contact
-------

   Iv�n Cantador, ivan [dot] cantador [at] uam [dot] es
