"""Validate locally regenerated experiment outputs and record the outcomes."""
from pathlib import Path
import argparse
import hashlib
import importlib.metadata
import json
import os
import platform
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('OMP_NUM_THREADS', '1')
os.environ.setdefault('MPLCONFIGDIR', '/tmp/cwop-icde-matplotlib')
parser = argparse.ArgumentParser()
parser.add_argument('--recomputed', action='store_true', help='Validate locally generated outputs; original result files are not bundled.')
args = parser.parse_args()
required = ['static.json', 'lastfm.json', 'feedback.json', 'review_summary.json',
            'refined_feedback_synthetic.json', 'refined_feedback_lastfm.json',
            'unified_feedback_synthetic.json', 'unified_feedback_lastfm.json',
            'sample_size_replicates.json']
missing = [n for n in required if not (ROOT/'results'/n).exists()]
if missing:
    parser.error('No saved data are bundled. Run the experiments first; missing: '+', '.join(missing))
manifest_path = ROOT/'INPUT_SHA256.json'
if args.recomputed:
    files = [p for folder in ['results', 'legacy/data'] for p in (ROOT/folder).rglob('*')
             if p.is_file() and p.suffix in {'.json', '.csv', '.npz'}]
    manifest = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
    manifest_path.write_text(json.dumps(manifest, indent=2)+'\n')
elif manifest_path.exists():
    manifest = json.loads(manifest_path.read_text())
else:
    parser.error('Use --recomputed to validate your locally generated outputs.')
OUT = ROOT / 'verification'
OUT.mkdir(exist_ok=True)
for name, digest in manifest.items():
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == digest, name
checks = [
    ['experiments/test_evaluation.py'],
    ['experiments/test_review_margins.py'],
    ['experiments/test_plot_readability.py'],
    ['experiments/test_plan_safety.py'],
    ['experiments/validate_results.py'],
    ['experiments/validate_review.py'],
    ['experiments/validate_refinement.py'],
    ['experiments/validate_sample_size_replicates.py'],
    ['experiments/replay_exposure_outcomes.py', '--artifact', '.'],
    ['experiments/validate_unified.py'],
]
report = {
    'python': platform.python_version(),
    'platform': platform.system(), 'architecture': platform.machine(),
    'packages': {p: importlib.metadata.version(p) for p in
                 ['numpy','scipy','cvxpy','clarabel','scs','matplotlib']},
    'input_files_hash_checked': len(manifest),
    'locally_recomputed_inputs': args.recomputed,
    'original_output_identity_verified': False,
    'scope': 'Saved-result checks, unit tests, all matched-window draw replays, '
             'selected frozen-policy resampling, and one complete certified '
             'synthetic trajectory rerun. The entire experiment grid '
             'is not rerun by this validation command.',
    'checks': []
}
for args in checks:
    name = Path(args[0]).stem
    print('RUN', name, flush=True)
    started = time.monotonic()
    run = subprocess.run([sys.executable]+args, stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT, text=True)
    # Keep the record portable if a diagnostic contains its working directory.
    output = run.stdout.replace(str(ROOT), '<artifact>')
    (OUT/(name+'.log')).write_text(output)
    report['checks'].append({'command': 'python '+ ' '.join(args),
        'exit_code': run.returncode, 'seconds': round(time.monotonic()-started,2),
        'log': 'verification/'+name+'.log'})
    report['status'] = 'PASS' if all(c['exit_code']==0 for c in report['checks']) else 'FAIL'
    (OUT/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(report['checks'][-1], flush=True)
    if run.returncode:
        print(output[-5000:],flush=True)
        sys.exit(run.returncode)
changed=[name for name,digest in manifest.items()
         if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=digest]
report['files_changed_during_validation']=changed
# NumPy ZIP container timestamps may change on the intentional trajectory rerun;
# individual arrays are compared to the preserved baseline by the release builder.
(OUT/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS: all checks on locally generated results.',flush=True)
