CWOP - supplementary submission

Contents
  ICDE_CWOP_Supplement.pdf  Supporting document
  document/                Complete LaTeX source
  artifact/                Experiment code, tests, dependencies, and instructions
  MANIFEST_SHA256.json      SHA-256 checksums of delivered files

No datasets, saved numerical results, model or policy arrays, run logs, or
verification-output records are bundled. No empty folders are included.
Numerical results, result tables, and result plots are also removed from the
supporting document and its source assets; theory and protocols remain.
The computational artifact is code only; its README explains how to generate
synthetic inputs and obtain the public Last.fm and KuaiRand inputs separately before rerunning.
No company data, empirical results, internal column names, or source schemas are
bundled in this supplement. The main paper reports verified relative platform-audit
findings; this document provides the protocol. The authorized company author
affiliation remains.

The main submission is separate, with 12 body pages and references beginning on
page 13. It has no appendix. M-prefixed references point to the main paper and
S-prefixed references point to this supplement.

To edit in Overleaf, upload document/, select ICDE_CWOP_Supplement.tex as the main
file, and use XeLaTeX. BibTeX is handled automatically. The unmodified IEEEtran
class is the one supplied with the conference template.

Reviewer-requested extension: public KuaiRand creator-exposure evaluation and a
Singh--Joachims-style joint policy-gradient comparator, with an explicitly labeled
known-score adaptation. Existing numerical results remain intact. General-slate
analytical details moved to the supplement; no empirical results or data are
bundled there. Raw company records and internal schemas remain excluded. The main paper alone
contains the verified relative platform-audit summaries.
